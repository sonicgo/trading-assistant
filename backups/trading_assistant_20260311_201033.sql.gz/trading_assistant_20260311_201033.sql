--
-- PostgreSQL database dump
--

\restrict 2hIoYGKvwoBzRACeEl11HRTBaSu7mts26umvteS3A6NPGHRnPlU8EvsqxrSQg5q

-- Dumped from database version 16.12
-- Dumped by pg_dump version 16.12

-- Started on 2026-03-11 20:10:33 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 6 (class 2615 OID 16385)
-- Name: ta; Type: SCHEMA; Schema: -; Owner: ta_app
--

CREATE SCHEMA ta;


ALTER SCHEMA ta OWNER TO ta_app;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 218 (class 1259 OID 16415)
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: ta_app
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO ta_app;

--
-- TOC entry 228 (class 1259 OID 18481)
-- Name: alerts; Type: TABLE; Schema: public; Owner: ta_app
--

CREATE TABLE public.alerts (
    alert_id uuid NOT NULL,
    portfolio_id uuid NOT NULL,
    listing_id uuid,
    severity character varying NOT NULL,
    rule_code character varying NOT NULL,
    title text NOT NULL,
    message text,
    details jsonb,
    created_at timestamp with time zone DEFAULT now(),
    resolved_at timestamp with time zone
);


ALTER TABLE public.alerts OWNER TO ta_app;

--
-- TOC entry 241 (class 1259 OID 26478)
-- Name: audit_events; Type: TABLE; Schema: public; Owner: ta_app
--

CREATE TABLE public.audit_events (
    audit_event_id uuid DEFAULT gen_random_uuid() NOT NULL,
    portfolio_id uuid,
    actor_user_id uuid,
    event_type character varying NOT NULL,
    entity_type character varying NOT NULL,
    entity_id uuid NOT NULL,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    summary text NOT NULL,
    details jsonb,
    correlation_id character varying
);


ALTER TABLE public.audit_events OWNER TO ta_app;

--
-- TOC entry 234 (class 1259 OID 26326)
-- Name: cash_snapshots; Type: TABLE; Schema: public; Owner: ta_app
--

CREATE TABLE public.cash_snapshots (
    portfolio_id uuid NOT NULL,
    balance_gbp numeric(28,10) DEFAULT '0'::numeric NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_entry_id uuid,
    version_no numeric(20,0) DEFAULT '0'::numeric NOT NULL
);


ALTER TABLE public.cash_snapshots OWNER TO ta_app;

--
-- TOC entry 238 (class 1259 OID 26411)
-- Name: execution_logs; Type: TABLE; Schema: public; Owner: ta_app
--

CREATE TABLE public.execution_logs (
    execution_log_id uuid DEFAULT gen_random_uuid() NOT NULL,
    job_name character varying NOT NULL,
    status character varying NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    error_message text,
    meta jsonb
);


ALTER TABLE public.execution_logs OWNER TO ta_app;

--
-- TOC entry 230 (class 1259 OID 18512)
-- Name: freeze_states; Type: TABLE; Schema: public; Owner: ta_app
--

CREATE TABLE public.freeze_states (
    freeze_id uuid NOT NULL,
    portfolio_id uuid NOT NULL,
    is_frozen boolean NOT NULL,
    reason_alert_id uuid,
    created_at timestamp with time zone DEFAULT now(),
    cleared_at timestamp with time zone,
    cleared_by_user_id uuid
);


ALTER TABLE public.freeze_states OWNER TO ta_app;

--
-- TOC entry 222 (class 1259 OID 18394)
-- Name: fx_rates; Type: TABLE; Schema: public; Owner: ta_app
--

CREATE TABLE public.fx_rates (
    fx_rate_id uuid NOT NULL,
    base_ccy character varying(3) NOT NULL,
    quote_ccy character varying(3) NOT NULL,
    as_of timestamp with time zone NOT NULL,
    rate numeric(28,10) NOT NULL,
    source_id character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.fx_rates OWNER TO ta_app;

--
-- TOC entry 235 (class 1259 OID 26344)
-- Name: holding_snapshots; Type: TABLE; Schema: public; Owner: ta_app
--

CREATE TABLE public.holding_snapshots (
    portfolio_id uuid NOT NULL,
    listing_id uuid NOT NULL,
    quantity numeric(28,10) DEFAULT '0'::numeric NOT NULL,
    book_cost_gbp numeric(28,10) DEFAULT '0'::numeric NOT NULL,
    avg_cost_gbp numeric(28,10) DEFAULT '0'::numeric NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_entry_id uuid,
    version_no numeric(20,0) DEFAULT '0'::numeric NOT NULL,
    CONSTRAINT ck_holding_snapshot_cost_consistency CHECK ((((quantity = (0)::numeric) AND (book_cost_gbp = (0)::numeric) AND (avg_cost_gbp = (0)::numeric)) OR (quantity > (0)::numeric))),
    CONSTRAINT ck_holding_snapshot_quantity_non_negative CHECK ((quantity >= (0)::numeric))
);


ALTER TABLE public.holding_snapshots OWNER TO ta_app;

--
-- TOC entry 220 (class 1259 OID 18378)
-- Name: instrument; Type: TABLE; Schema: public; Owner: ta_app
--

CREATE TABLE public.instrument (
    instrument_id uuid NOT NULL,
    isin character varying(12) NOT NULL,
    instrument_type character varying NOT NULL,
    name character varying,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.instrument OWNER TO ta_app;

--
-- TOC entry 232 (class 1259 OID 26270)
-- Name: ledger_batches; Type: TABLE; Schema: public; Owner: ta_app
--

CREATE TABLE public.ledger_batches (
    batch_id uuid DEFAULT gen_random_uuid() NOT NULL,
    portfolio_id uuid NOT NULL,
    submitted_by_user_id uuid NOT NULL,
    source character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    note text,
    meta jsonb,
    idempotency_key character varying
);


ALTER TABLE public.ledger_batches OWNER TO ta_app;

--
-- TOC entry 233 (class 1259 OID 26291)
-- Name: ledger_entries; Type: TABLE; Schema: public; Owner: ta_app
--

CREATE TABLE public.ledger_entries (
    entry_id uuid DEFAULT gen_random_uuid() NOT NULL,
    batch_id uuid NOT NULL,
    portfolio_id uuid NOT NULL,
    entry_kind character varying NOT NULL,
    effective_at timestamp with time zone NOT NULL,
    listing_id uuid,
    quantity_delta numeric(28,10),
    net_cash_delta_gbp numeric(28,10) NOT NULL,
    fee_gbp numeric(28,10),
    book_cost_delta_gbp numeric(28,10),
    reversal_of_entry_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    note text,
    meta jsonb,
    CONSTRAINT ck_ledger_entry_fee_non_negative CHECK (((fee_gbp IS NULL) OR (fee_gbp >= (0)::numeric))),
    CONSTRAINT ck_ledger_entry_kind CHECK (((entry_kind)::text = ANY ((ARRAY['CONTRIBUTION'::character varying, 'BUY'::character varying, 'SELL'::character varying, 'ADJUSTMENT'::character varying, 'REVERSAL'::character varying])::text[])))
);


ALTER TABLE public.ledger_entries OWNER TO ta_app;

--
-- TOC entry 224 (class 1259 OID 18417)
-- Name: listing; Type: TABLE; Schema: public; Owner: ta_app
--

CREATE TABLE public.listing (
    listing_id uuid NOT NULL,
    instrument_id uuid NOT NULL,
    ticker character varying NOT NULL,
    exchange character varying NOT NULL,
    trading_currency character varying(3) NOT NULL,
    quote_scale character varying NOT NULL,
    is_primary boolean,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.listing OWNER TO ta_app;

--
-- TOC entry 237 (class 1259 OID 26390)
-- Name: notification_configs; Type: TABLE; Schema: public; Owner: ta_app
--

CREATE TABLE public.notification_configs (
    notification_config_id uuid DEFAULT gen_random_uuid() NOT NULL,
    portfolio_id uuid NOT NULL,
    apprise_url text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.notification_configs OWNER TO ta_app;

--
-- TOC entry 225 (class 1259 OID 18430)
-- Name: notifications; Type: TABLE; Schema: public; Owner: ta_app
--

CREATE TABLE public.notifications (
    notification_id uuid NOT NULL,
    owner_user_id uuid NOT NULL,
    severity character varying NOT NULL,
    title text NOT NULL,
    body text,
    created_at timestamp with time zone DEFAULT now(),
    read_at timestamp with time zone,
    meta jsonb
);


ALTER TABLE public.notifications OWNER TO ta_app;

--
-- TOC entry 223 (class 1259 OID 18404)
-- Name: portfolio; Type: TABLE; Schema: public; Owner: ta_app
--

CREATE TABLE public.portfolio (
    portfolio_id uuid NOT NULL,
    owner_user_id uuid NOT NULL,
    name character varying NOT NULL,
    broker character varying NOT NULL,
    base_currency character varying(3) NOT NULL,
    tax_treatment character varying NOT NULL,
    is_enabled boolean,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.portfolio OWNER TO ta_app;

--
-- TOC entry 226 (class 1259 OID 18443)
-- Name: portfolio_constituent; Type: TABLE; Schema: public; Owner: ta_app
--

CREATE TABLE public.portfolio_constituent (
    portfolio_id uuid NOT NULL,
    listing_id uuid NOT NULL,
    sleeve_code character varying NOT NULL,
    is_monitored boolean,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.portfolio_constituent OWNER TO ta_app;

--
-- TOC entry 236 (class 1259 OID 26371)
-- Name: portfolio_policy_allocations; Type: TABLE; Schema: public; Owner: ta_app
--

CREATE TABLE public.portfolio_policy_allocations (
    portfolio_policy_allocation_id uuid NOT NULL,
    portfolio_id uuid NOT NULL,
    listing_id uuid NOT NULL,
    ticker character varying NOT NULL,
    sleeve_code character varying NOT NULL,
    policy_role character varying NOT NULL,
    target_weight_pct numeric(18,8),
    priority_rank integer,
    policy_hash character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.portfolio_policy_allocations OWNER TO ta_app;

--
-- TOC entry 227 (class 1259 OID 18466)
-- Name: price_points; Type: TABLE; Schema: public; Owner: ta_app
--

CREATE TABLE public.price_points (
    price_point_id uuid NOT NULL,
    listing_id uuid NOT NULL,
    as_of timestamp with time zone NOT NULL,
    price numeric(28,10) NOT NULL,
    currency character varying(3),
    is_close boolean NOT NULL,
    source_id character varying NOT NULL,
    raw jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.price_points OWNER TO ta_app;

--
-- TOC entry 239 (class 1259 OID 26424)
-- Name: recommendation_batches; Type: TABLE; Schema: public; Owner: ta_app
--

CREATE TABLE public.recommendation_batches (
    recommendation_batch_id uuid DEFAULT gen_random_uuid() NOT NULL,
    portfolio_id uuid NOT NULL,
    status character varying DEFAULT 'PENDING'::character varying NOT NULL,
    generated_at timestamp with time zone DEFAULT now() NOT NULL,
    executed_at timestamp with time zone,
    ignored_at timestamp with time zone,
    closed_by_user_id uuid,
    execution_summary jsonb,
    run_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.recommendation_batches OWNER TO ta_app;

--
-- TOC entry 240 (class 1259 OID 26452)
-- Name: recommendation_lines; Type: TABLE; Schema: public; Owner: ta_app
--

CREATE TABLE public.recommendation_lines (
    recommendation_line_id uuid DEFAULT gen_random_uuid() NOT NULL,
    recommendation_batch_id uuid NOT NULL,
    listing_id uuid NOT NULL,
    action character varying NOT NULL,
    proposed_quantity numeric(28,10) NOT NULL,
    proposed_price_gbp numeric(28,10) NOT NULL,
    proposed_value_gbp numeric(28,10) NOT NULL,
    proposed_fee_gbp numeric(28,10) DEFAULT '0'::numeric NOT NULL,
    status character varying DEFAULT 'PROPOSED'::character varying NOT NULL,
    executed_quantity numeric(28,10),
    executed_price_gbp numeric(28,10),
    executed_value_gbp numeric(28,10),
    executed_fee_gbp numeric(28,10),
    ledger_entry_id uuid,
    execution_note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.recommendation_lines OWNER TO ta_app;

--
-- TOC entry 231 (class 1259 OID 18533)
-- Name: run_input_snapshots; Type: TABLE; Schema: public; Owner: ta_app
--

CREATE TABLE public.run_input_snapshots (
    run_id uuid NOT NULL,
    input_json jsonb NOT NULL,
    input_hash character varying,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.run_input_snapshots OWNER TO ta_app;

--
-- TOC entry 221 (class 1259 OID 18387)
-- Name: sleeves; Type: TABLE; Schema: public; Owner: ta_app
--

CREATE TABLE public.sleeves (
    sleeve_code character varying NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.sleeves OWNER TO ta_app;

--
-- TOC entry 229 (class 1259 OID 18499)
-- Name: task_runs; Type: TABLE; Schema: public; Owner: ta_app
--

CREATE TABLE public.task_runs (
    run_id uuid NOT NULL,
    job_id uuid NOT NULL,
    task_kind character varying NOT NULL,
    portfolio_id uuid,
    status character varying NOT NULL,
    started_at timestamp with time zone DEFAULT now(),
    ended_at timestamp with time zone,
    summary jsonb
);


ALTER TABLE public.task_runs OWNER TO ta_app;

--
-- TOC entry 219 (class 1259 OID 18369)
-- Name: user; Type: TABLE; Schema: public; Owner: ta_app
--

CREATE TABLE public."user" (
    user_id uuid NOT NULL,
    email character varying NOT NULL,
    password_hash character varying NOT NULL,
    is_enabled boolean,
    is_bootstrap_admin boolean,
    created_at timestamp with time zone DEFAULT now(),
    last_login_at timestamp with time zone
);


ALTER TABLE public."user" OWNER TO ta_app;

--
-- TOC entry 217 (class 1259 OID 16397)
-- Name: portfolios; Type: TABLE; Schema: ta; Owner: ta_app
--

CREATE TABLE ta.portfolios (
    portfolio_id uuid NOT NULL,
    owner_user_id uuid,
    name text NOT NULL,
    base_currency character(3) DEFAULT 'GBP'::bpchar,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE ta.portfolios OWNER TO ta_app;

--
-- TOC entry 216 (class 1259 OID 16386)
-- Name: users; Type: TABLE; Schema: ta; Owner: ta_app
--

CREATE TABLE ta.users (
    user_id uuid NOT NULL,
    email text NOT NULL,
    is_enabled boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE ta.users OWNER TO ta_app;

--
-- TOC entry 3676 (class 0 OID 16415)
-- Dependencies: 218
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: ta_app
--

COPY public.alembic_version (version_num) FROM stdin;
d0e5f123f6a7
\.


--
-- TOC entry 3686 (class 0 OID 18481)
-- Dependencies: 228
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: ta_app
--

COPY public.alerts (alert_id, portfolio_id, listing_id, severity, rule_code, title, message, details, created_at, resolved_at) FROM stdin;
1b85bf76-1ec7-425b-a15b-e795a7f60323	a9136ac7-2cd4-43db-be99-f4fb545b5ec1	\N	CRITICAL	DQ_STALE_CLOSE	Stale	Stale	\N	2026-02-28 00:42:35.729377+00	\N
8ecce376-a9a9-4425-8b40-20583c993c10	11443291-4e86-4a9c-9ea4-c9f7040ae16e	88535377-562e-4c57-86af-3113c6acf175	CRITICAL	DQ_CCY_MISMATCH	Currency Mismatch: ISFA	Provider reported currency 'USD' but listing 'ISFA' trades in 'GBP'.	{"ticker": "ISFA", "listing_id": "88535377-562e-4c57-86af-3113c6acf175", "provider_currency": "USD", "listing_trading_currency": "GBP"}	2026-03-11 09:56:16.712798+00	\N
\.


--
-- TOC entry 3699 (class 0 OID 26478)
-- Dependencies: 241
-- Data for Name: audit_events; Type: TABLE DATA; Schema: public; Owner: ta_app
--

COPY public.audit_events (audit_event_id, portfolio_id, actor_user_id, event_type, entity_type, entity_id, occurred_at, summary, details, correlation_id) FROM stdin;
5fc2cfbe-91c0-4e2c-bc6c-4acf05e4c00f	5bb022ad-ced5-438c-8eac-9c306fbdf77c	aa4e1960-7d43-46b6-ae8d-b184cdb470bd	RECOMMENDATION_EXECUTED	RECOMMENDATION_BATCH	2d214464-ee82-4bb1-b780-6a42af7c5b9d	2026-03-11 19:17:48.302884+00	Executed recommendation batch with 1 lines	{"batch_id": "2d214464-ee82-4bb1-b780-6a42af7c5b9d", "correlation_id": null, "lines_executed": 1, "ledger_batch_id": "8d8c1173-3d05-48b2-8c19-e8a8dbbd5b11", "total_cash_impact": "-1005.0000000000"}	\N
a5bc9302-ac1c-4976-a160-2a800b76ef70	b87f27e6-b395-4604-b8f3-8c7967ef2583	286a21d8-bda0-45dc-aaf1-40da26b918e4	RECOMMENDATION_EXECUTED	RECOMMENDATION_BATCH	60a039f2-8d6d-4ce1-868b-d82c9a49ceb7	2026-03-11 19:17:48.346956+00	Executed recommendation batch with 1 lines	{"batch_id": "60a039f2-8d6d-4ce1-868b-d82c9a49ceb7", "correlation_id": null, "lines_executed": 1, "ledger_batch_id": "7915c416-8379-4b43-aaab-941b948dc656", "total_cash_impact": "-1005.0000000000"}	\N
ab710876-3c8a-4f8e-81c5-cc2a0cf201f9	f215e7c6-9ca2-477d-8576-103a9dbdbb5b	0842f730-0598-4271-93d5-6766297f29b1	RECOMMENDATION_EXECUTED	RECOMMENDATION_BATCH	82b3c0bb-df5b-48e1-9335-13be89ef0559	2026-03-11 19:17:48.381056+00	Executed recommendation batch with 1 lines	{"batch_id": "82b3c0bb-df5b-48e1-9335-13be89ef0559", "correlation_id": null, "lines_executed": 1, "ledger_batch_id": "10587a54-c7f1-42fa-b690-3ece0796c693", "total_cash_impact": "-528.0000000000"}	\N
8308df3b-d6cf-4649-9348-4a53ea7d66bb	aed673d6-c6d4-4d43-a8e2-b07340d8ad41	1420911d-1722-4d2f-a969-6343dbfb6d1a	RECOMMENDATION_EXECUTED	RECOMMENDATION_BATCH	d5b8d681-efee-4303-b5d7-6ad325a5ef8b	2026-03-11 19:17:48.419847+00	Executed recommendation batch with 1 lines	{"batch_id": "d5b8d681-efee-4303-b5d7-6ad325a5ef8b", "correlation_id": null, "lines_executed": 1, "ledger_batch_id": "7c868f57-db7a-4ccf-adc2-4aeaae3d6fb4", "total_cash_impact": "-1005.0000000000"}	\N
cf9dae59-ec4b-498e-9e37-49cadb593cb1	fbbd734d-8613-4c2d-902c-40826950aa55	bb694a18-6764-46e4-9179-5e4abed2e56c	RECOMMENDATION_EXECUTED	RECOMMENDATION_BATCH	21277236-2a86-4561-ab04-6aa6a9579c92	2026-03-11 19:17:48.465161+00	Executed recommendation batch with 1 lines	{"batch_id": "21277236-2a86-4561-ab04-6aa6a9579c92", "correlation_id": null, "lines_executed": 1, "ledger_batch_id": "154a38eb-bf8a-495b-9572-75196fa7e951", "total_cash_impact": "-1005.0000000000"}	\N
593f2acf-ae7a-4429-b8fa-0f6d69674d19	7fb0b5ce-109d-4337-92a8-2195afef1bff	26f38a7d-33c8-4aa7-b67e-8c3cc0a73d34	RECOMMENDATION_IGNORED	RECOMMENDATION_BATCH	99aa2655-4f35-4fb5-86f6-4e31f06d5332	2026-03-11 19:17:48.521506+00	Ignored recommendation batch: Market conditions changed	{"reason": "Market conditions changed", "batch_id": "99aa2655-4f35-4fb5-86f6-4e31f06d5332", "lines_ignored": 1, "correlation_id": null}	\N
79eb25ac-14b8-4db9-952c-25d42dc4bd7b	9b4870ec-6f2d-4d93-9a3e-dc5d730b7327	617d97e3-47de-4f17-a9b4-36a0c79cb98f	RECOMMENDATION_IGNORED	RECOMMENDATION_BATCH	cecee63f-f85e-4cd3-8d41-2db2b2e00934	2026-03-11 19:17:48.549919+00	Ignored recommendation batch: Deferred to next month	{"reason": "Deferred to next month", "batch_id": "cecee63f-f85e-4cd3-8d41-2db2b2e00934", "lines_ignored": 1, "correlation_id": null}	\N
a286bef8-9dd8-4266-97e7-f61d17e79055	c7966280-fb24-4816-ac89-8f57d94252ae	2d5b130b-0af0-4add-a686-030d576ca9d2	RECOMMENDATION_IGNORED	RECOMMENDATION_BATCH	bddc1b16-bfe4-48f0-838d-c1a6be8b9931	2026-03-11 19:17:48.578192+00	Ignored recommendation batch: Testing ignore	{"reason": "Testing ignore", "batch_id": "bddc1b16-bfe4-48f0-838d-c1a6be8b9931", "lines_ignored": 1, "correlation_id": null}	\N
eaafc5cc-a6bb-4f8b-84d2-107645cd73de	0af60105-8d65-46ba-9e1b-0a432690ed3b	15589ed0-c73f-476a-9e00-d383b1e29033	RECOMMENDATION_IGNORED	RECOMMENDATION_BATCH	27a16e3a-9c18-410b-a584-717dff91ca98	2026-03-11 19:17:48.611753+00	Ignored recommendation batch	{"reason": null, "batch_id": "27a16e3a-9c18-410b-a584-717dff91ca98", "lines_ignored": 1, "correlation_id": null}	\N
b973cc28-26a3-45b0-8ec7-5cfce731f1e6	91797da6-97ee-4762-a110-772aedf0f225	74883a77-453c-47db-bbb9-ead741b63dad	RECOMMENDATION_EXECUTED	RECOMMENDATION_BATCH	a6ad2470-0283-4327-8660-3a67d38ba888	2026-03-11 19:17:48.64696+00	Executed recommendation batch with 1 lines	{"batch_id": "a6ad2470-0283-4327-8660-3a67d38ba888", "correlation_id": null, "lines_executed": 1, "ledger_batch_id": "6056aaa4-bfb0-44d3-80a7-acec763262a5", "total_cash_impact": "-1005.0000000000"}	\N
b6458465-862d-45d0-8463-6453d8823010	442751d4-2ed9-4874-a474-4ca686ce88c5	18f8a6d4-7795-4380-9ebf-6ba112d8f799	RECOMMENDATION_EXECUTED	RECOMMENDATION_BATCH	be4adaf9-c48d-43c6-918c-a49ac6d06607	2026-03-11 19:17:56.390491+00	Executed recommendation batch with 1 lines	{"batch_id": "be4adaf9-c48d-43c6-918c-a49ac6d06607", "correlation_id": null, "lines_executed": 1, "ledger_batch_id": "82a8f598-f95f-482d-bc03-a6c7cd8960db", "total_cash_impact": "-1005.0000000000"}	\N
9dce4e2c-b3db-459c-b427-987fa359557b	4176c31c-6f31-4f4b-b9d9-273a24ed87d4	d35f101b-7748-4535-b571-43a0e0e274d1	RECOMMENDATION_EXECUTED	RECOMMENDATION_BATCH	9444313c-6c5d-4c0c-b2a1-e846c97e30cc	2026-03-11 19:17:56.429093+00	Executed recommendation batch with 1 lines	{"batch_id": "9444313c-6c5d-4c0c-b2a1-e846c97e30cc", "correlation_id": null, "lines_executed": 1, "ledger_batch_id": "47ad61ff-28d0-45ba-903b-d4ae3fd26ede", "total_cash_impact": "-1005.0000000000"}	\N
67a0a383-2896-4e2b-9223-213499ae5447	ac3876c8-859f-4cbd-aebf-59248d4e9e42	3cca1d39-faa3-4a3d-9a6a-25302a708b28	RECOMMENDATION_EXECUTED	RECOMMENDATION_BATCH	c86bbff6-32c6-406d-9092-3dce49af9ec2	2026-03-11 19:17:56.472097+00	Executed recommendation batch with 1 lines	{"batch_id": "c86bbff6-32c6-406d-9092-3dce49af9ec2", "correlation_id": null, "lines_executed": 1, "ledger_batch_id": "fd87adbd-6be2-494b-a63c-32b778b613aa", "total_cash_impact": "-528.0000000000"}	\N
458d50e5-62b0-4b6b-affd-59b325faee8c	5643df5b-1190-410a-8613-fe281ed78219	319b1561-136d-4601-a951-26d74f7a14ac	RECOMMENDATION_EXECUTED	RECOMMENDATION_BATCH	44493dfb-9139-4bca-a0b5-3b28461b9961	2026-03-11 19:17:56.518204+00	Executed recommendation batch with 1 lines	{"batch_id": "44493dfb-9139-4bca-a0b5-3b28461b9961", "correlation_id": null, "lines_executed": 1, "ledger_batch_id": "908a3f8f-c04d-47e7-bdf8-acfe91d01da7", "total_cash_impact": "-1005.0000000000"}	\N
359065af-162a-4bb3-819a-a6e52edb6ede	48eb442a-9521-4d87-a013-fae87f350831	ea2b69fc-f81a-4a08-bef2-943e826a5b81	RECOMMENDATION_EXECUTED	RECOMMENDATION_BATCH	2e729c0d-a28c-490b-a739-fd9642942543	2026-03-11 19:17:56.560965+00	Executed recommendation batch with 1 lines	{"batch_id": "2e729c0d-a28c-490b-a739-fd9642942543", "correlation_id": null, "lines_executed": 1, "ledger_batch_id": "a9f86105-cdd5-4fd8-9381-6319a0a66575", "total_cash_impact": "-1005.0000000000"}	\N
81a34458-29a4-41f8-b1a0-7173da5108b6	1672e066-3d21-42a3-aa25-9e55e83afd53	90060e1e-dd0b-4800-b269-6443db2fcc4a	RECOMMENDATION_IGNORED	RECOMMENDATION_BATCH	7f25f489-614a-48f4-a5f3-02da9053ffbe	2026-03-11 19:17:56.619799+00	Ignored recommendation batch: Market conditions changed	{"reason": "Market conditions changed", "batch_id": "7f25f489-614a-48f4-a5f3-02da9053ffbe", "lines_ignored": 1, "correlation_id": null}	\N
9af3531b-b58d-4690-8f04-c2ce8487a744	61af205c-fd68-4a54-8115-7c8cf5346c22	4bfbb8a0-d061-4c0d-88d3-965a3075226f	RECOMMENDATION_IGNORED	RECOMMENDATION_BATCH	dff7a2d7-4737-43ae-9ce7-c5be26dc6bcc	2026-03-11 19:17:56.655417+00	Ignored recommendation batch: Deferred to next month	{"reason": "Deferred to next month", "batch_id": "dff7a2d7-4737-43ae-9ce7-c5be26dc6bcc", "lines_ignored": 1, "correlation_id": null}	\N
63edcb46-8a06-46fb-a582-f7d1e7092b81	f7239388-dbeb-4814-a3d8-266a389f9684	4c88a3a8-6115-4cb5-a7f2-ea357fc60567	RECOMMENDATION_IGNORED	RECOMMENDATION_BATCH	ba387719-5e48-49f6-b525-56302be3b829	2026-03-11 19:17:56.690505+00	Ignored recommendation batch: Testing ignore	{"reason": "Testing ignore", "batch_id": "ba387719-5e48-49f6-b525-56302be3b829", "lines_ignored": 1, "correlation_id": null}	\N
1339196e-8f63-4a55-b417-ca6717416e32	0ea34e7a-7f36-4075-bc18-6d57a70dd200	b9cd736b-7715-41a1-8627-9cd7a458c6cf	RECOMMENDATION_IGNORED	RECOMMENDATION_BATCH	e11a5e94-ee8b-49e3-b82e-726764e3194d	2026-03-11 19:17:56.730484+00	Ignored recommendation batch	{"reason": null, "batch_id": "e11a5e94-ee8b-49e3-b82e-726764e3194d", "lines_ignored": 1, "correlation_id": null}	\N
d9b86de3-fb8a-4a0c-9e0e-c155d611e4dd	ad7e990c-4832-498b-a1c8-ce99cc20c609	e4050dcc-060b-4ef8-aa5e-e3f1c6a976b7	RECOMMENDATION_EXECUTED	RECOMMENDATION_BATCH	99f3937f-6ea3-474d-b895-3d19ee20f269	2026-03-11 19:17:56.779682+00	Executed recommendation batch with 1 lines	{"batch_id": "99f3937f-6ea3-474d-b895-3d19ee20f269", "correlation_id": null, "lines_executed": 1, "ledger_batch_id": "ef6b92dd-180e-4fde-a615-685954e197f2", "total_cash_impact": "-1005.0000000000"}	\N
\.


--
-- TOC entry 3692 (class 0 OID 26326)
-- Dependencies: 234
-- Data for Name: cash_snapshots; Type: TABLE DATA; Schema: public; Owner: ta_app
--

COPY public.cash_snapshots (portfolio_id, balance_gbp, updated_at, last_entry_id, version_no) FROM stdin;
e5fa701e-6756-4a03-ac4f-052407357964	1000.0000000000	2026-03-10 20:30:52.109995+00	5278d9e5-af40-4e9c-b7a4-6fbbc75cc243	1
ab138600-660c-45e9-b493-e77304994189	250.0000000000	2026-03-11 12:00:00+00	\N	1
236a92b2-c836-4d1f-9de0-db72ebfb4060	250.0000000000	2026-03-11 12:00:00+00	\N	1
bc0599c2-8237-4c77-a790-25ae1a82d167	250.0000000000	2026-03-11 12:00:00+00	\N	1
7cac4b10-da63-4987-bfb4-97096834da03	250.0000000000	2026-03-11 12:00:00+00	\N	1
ce01de34-afad-4263-927a-242136e9c35c	250.0000000000	2026-03-11 12:00:00+00	\N	1
ea02c07f-f850-4338-8443-5e1a294fef63	250.0000000000	2026-03-11 12:00:00+00	\N	1
84ae3a73-9fb5-4ef7-b7fd-8cf42a4b784a	250.0000000000	2026-03-11 12:00:00+00	\N	1
ec44019e-fb66-4dbe-a9c6-cc0a98904723	250.0000000000	2026-03-11 12:00:00+00	\N	1
543893c3-b8b5-4cc9-9c94-20cbcb019cb6	250.0000000000	2026-03-11 12:00:00+00	\N	1
5ad7b426-a154-4154-bdf2-0f7b8dcb6aad	250.0000000000	2026-03-11 12:00:00+00	\N	1
f66550c0-77db-4a8e-99ea-531219da8660	250.0000000000	2026-03-11 12:00:00+00	\N	1
5cab396c-3c49-426b-8f4a-71e04f26e8c8	250.0000000000	2026-03-11 12:00:00+00	\N	1
259792b1-c894-403a-b988-06ca5af3c2c5	250.0000000000	2026-03-11 12:00:00+00	\N	1
a03981eb-5cc2-4483-85c4-c2b284a6dfae	250.0000000000	2026-03-11 12:00:00+00	\N	1
6a0db12e-51d9-45b7-8905-77059fd448db	250.0000000000	2026-03-11 12:00:00+00	\N	1
a05c52ad-02fe-49c9-aae3-326eab43299a	250.0000000000	2026-03-11 12:00:00+00	\N	1
4ec95e47-148d-4e8a-853c-a6fab32f873c	250.0000000000	2026-03-11 12:00:00+00	\N	1
335990e2-b794-4049-b8b1-80b917284039	250.0000000000	2026-03-11 12:00:00+00	\N	1
527ba4f9-7b40-4ab0-8629-9d5fc7b341f0	250.0000000000	2026-03-11 12:00:00+00	\N	1
b7ff47bd-d423-46bd-833e-3ccfd03e6069	250.0000000000	2026-03-11 12:00:00+00	\N	1
f562d51c-79bd-4e05-ae8c-7478b494d740	250.0000000000	2026-03-11 12:00:00+00	\N	1
8f28a33d-94b8-43d8-bc95-26167611cda8	250.0000000000	2026-03-11 12:00:00+00	\N	1
53680ec9-db2d-462a-b930-a8e2d9f30dfc	250.0000000000	2026-03-11 12:00:00+00	\N	1
f80e196d-6218-4f8c-a211-894e298418af	250.0000000000	2026-03-11 12:00:00+00	\N	1
a023d249-926d-476e-8538-9d7a59f0cf97	250.0000000000	2026-03-11 12:00:00+00	\N	1
6d0579fe-3d73-484b-843c-ec30733e270c	250.0000000000	2026-03-11 12:00:00+00	\N	1
0332f290-ab02-4ed8-beac-30292d85c959	250.0000000000	2026-03-11 12:00:00+00	\N	1
7aab19f6-ce72-493b-9f44-8b35338401e8	250.0000000000	2026-03-11 12:00:00+00	\N	1
484bb1bf-e98d-4d59-9591-dd236d9acf79	250.0000000000	2026-03-11 12:00:00+00	\N	1
0953691a-0c74-4f2c-bd2d-c7123d2d847a	250.0000000000	2026-03-11 12:00:00+00	\N	1
57d17ec3-dff1-4566-98fe-66870d390834	250.0000000000	2026-03-11 12:00:00+00	\N	1
03dc8184-7957-4423-a49f-d597b6060511	250.0000000000	2026-03-11 12:00:00+00	\N	1
cf3465de-eb7d-4a8e-a6b5-6588919bb632	250.0000000000	2026-03-11 12:00:00+00	\N	1
5c2367af-893f-473d-8a09-3cddac469689	250.0000000000	2026-03-11 12:00:00+00	\N	1
ee2c0dd8-ead5-42ed-9e7e-5a2bb38ce91e	250.0000000000	2026-03-11 12:00:00+00	\N	1
5bb022ad-ced5-438c-8eac-9c306fbdf77c	-1005.0000000000	2026-03-11 19:17:48.288929+00	dcf898b3-e35e-4bad-8c12-ac2a0722653f	1
b87f27e6-b395-4604-b8f3-8c7967ef2583	-1005.0000000000	2026-03-11 19:17:48.343451+00	61907652-3698-4713-ada5-0346fdc9c0f7	1
f215e7c6-9ca2-477d-8576-103a9dbdbb5b	-528.0000000000	2026-03-11 19:17:48.37721+00	6863ffd6-fd85-4710-a834-22b1c483a18a	1
aed673d6-c6d4-4d43-a8e2-b07340d8ad41	-1005.0000000000	2026-03-11 19:17:48.414109+00	729da3df-200d-48d2-93ac-9d71934a6e03	1
fbbd734d-8613-4c2d-902c-40826950aa55	-1005.0000000000	2026-03-11 19:17:48.461441+00	560e79e8-eef0-4975-b8de-64f07a15d736	1
91797da6-97ee-4762-a110-772aedf0f225	-1005.0000000000	2026-03-11 19:17:48.64327+00	746f496b-ef34-4957-9e44-f60ef7c9c2cd	1
c8dd35af-2322-480c-ad23-1218b017b6c4	250.0000000000	2026-03-11 12:00:00+00	\N	1
41694260-5bc3-4c21-a896-2f8c05a5061c	250.0000000000	2026-03-11 12:00:00+00	\N	1
65a5083e-27e1-4213-b6fc-b956991d4aa8	250.0000000000	2026-03-11 12:00:00+00	\N	1
7badea17-cfb5-4fb5-a613-333c7f79b06c	250.0000000000	2026-03-11 12:00:00+00	\N	1
c712bacf-99af-4ace-ace5-3659b98f6ade	250.0000000000	2026-03-11 12:00:00+00	\N	1
442751d4-2ed9-4874-a474-4ca686ce88c5	-1005.0000000000	2026-03-11 19:17:56.383272+00	c2a5a70c-679f-45c1-bc25-5fd202a4b67e	1
4176c31c-6f31-4f4b-b9d9-273a24ed87d4	-1005.0000000000	2026-03-11 19:17:56.423735+00	185c81dc-ad03-4f21-888a-76b163d9d7d7	1
ac3876c8-859f-4cbd-aebf-59248d4e9e42	-528.0000000000	2026-03-11 19:17:56.466054+00	27003e76-bf2c-4cab-919c-5437e723d335	1
5643df5b-1190-410a-8613-fe281ed78219	-1005.0000000000	2026-03-11 19:17:56.512033+00	6d515285-1f46-4e49-8291-155fc1cb7764	1
48eb442a-9521-4d87-a013-fae87f350831	-1005.0000000000	2026-03-11 19:17:56.557422+00	68f85e57-a6f0-43fe-9416-21fc40606705	1
ad7e990c-4832-498b-a1c8-ce99cc20c609	-1005.0000000000	2026-03-11 19:17:56.772864+00	a5f7c4e6-40ed-41d1-8d1e-6fb76d1a9b8e	1
0dbb642d-ce67-4752-b6e3-6242d8c69d72	507.6800000000	2026-03-11 19:44:20.930472+00	6237aac0-172b-4b69-9d86-df2e78ce6cc1	2
\.


--
-- TOC entry 3696 (class 0 OID 26411)
-- Dependencies: 238
-- Data for Name: execution_logs; Type: TABLE DATA; Schema: public; Owner: ta_app
--

COPY public.execution_logs (execution_log_id, job_name, status, started_at, completed_at, error_message, meta) FROM stdin;
e0255160-9b16-4a05-a4bf-679d2dac3be3	test_job	SUCCESS	2026-03-11 19:17:57.011958+00	2026-03-11 19:17:57.01196+00	\N	{"rows_deleted": 100, "retention_days": 30}
\.


--
-- TOC entry 3688 (class 0 OID 18512)
-- Dependencies: 230
-- Data for Name: freeze_states; Type: TABLE DATA; Schema: public; Owner: ta_app
--

COPY public.freeze_states (freeze_id, portfolio_id, is_frozen, reason_alert_id, created_at, cleared_at, cleared_by_user_id) FROM stdin;
cc7c9c06-42e8-4171-9a7e-c57366caa0e9	a9136ac7-2cd4-43db-be99-f4fb545b5ec1	t	1b85bf76-1ec7-425b-a15b-e795a7f60323	2026-02-28 00:42:35.735709+00	2026-02-28 00:42:35.740489+00	501270c9-28bd-47e5-aaad-329f27096366
ca1c08ca-84b1-4858-b42e-ba463d25f6bf	a9136ac7-2cd4-43db-be99-f4fb545b5ec1	t	\N	2026-02-28 00:42:35.743601+00	\N	\N
c3ed3b76-4cd3-4b6d-843e-45b9431656f8	11443291-4e86-4a9c-9ea4-c9f7040ae16e	t	8ecce376-a9a9-4425-8b40-20583c993c10	2026-03-11 09:56:16.717617+00	\N	\N
\.


--
-- TOC entry 3680 (class 0 OID 18394)
-- Dependencies: 222
-- Data for Name: fx_rates; Type: TABLE DATA; Schema: public; Owner: ta_app
--

COPY public.fx_rates (fx_rate_id, base_ccy, quote_ccy, as_of, rate, source_id, created_at) FROM stdin;
\.


--
-- TOC entry 3693 (class 0 OID 26344)
-- Dependencies: 235
-- Data for Name: holding_snapshots; Type: TABLE DATA; Schema: public; Owner: ta_app
--

COPY public.holding_snapshots (portfolio_id, listing_id, quantity, book_cost_gbp, avg_cost_gbp, updated_at, last_entry_id, version_no) FROM stdin;
0dbb642d-ce67-4752-b6e3-6242d8c69d72	8f574494-d8c0-4ce7-979a-1c058718e609	330.0000000000	2387.9300000000	7.2361515152	2026-03-11 11:16:55.046461+00	306437e4-dc89-4fd0-bd04-8bdb136dc6fd	1
0dbb642d-ce67-4752-b6e3-6242d8c69d72	427a4690-316c-462d-add9-199e0c71de0d	25.0000000000	1200.4600000000	48.0184000000	2026-03-11 11:16:55.047018+00	48e83646-3b3b-49dc-bcf6-26b06af24ed5	1
0dbb642d-ce67-4752-b6e3-6242d8c69d72	2775a081-069b-4fa0-a7d9-a52353320dab	13.0000000000	15895.9300000000	1222.7638461538	2026-03-11 11:16:55.04756+00	7d8bafa5-5e93-4439-9342-9680df906d30	1
0dbb642d-ce67-4752-b6e3-6242d8c69d72	44c9f233-ded8-44e5-8dda-f467827fe671	425.0000000000	2400.9800000000	5.6493647059	2026-03-11 11:16:55.048054+00	b554b2ae-2c2b-4e9c-8c77-62492e92ff10	1
0dbb642d-ce67-4752-b6e3-6242d8c69d72	1bc182b8-7410-4026-9d64-c628a13c4836	25.0000000000	1111.5600000000	44.4624000000	2026-03-11 11:16:55.048631+00	bd40940f-7173-423d-9b9f-2004bc47b10c	1
0dbb642d-ce67-4752-b6e3-6242d8c69d72	59976aac-caa6-4e73-b57b-2483c47d5c56	500.0000000000	4923.1000000000	9.8462000000	2026-03-11 11:16:55.049156+00	c5aa7408-3b9c-4d8c-8007-c403ba5dc6f9	1
ab138600-660c-45e9-b493-e77304994189	1c918015-04cd-4bd4-aa2f-4480a02e6947	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
236a92b2-c836-4d1f-9de0-db72ebfb4060	bb678d70-3ece-4993-a5b6-e8e46fb8839f	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
bc0599c2-8237-4c77-a790-25ae1a82d167	3539aef7-0437-4e3f-b37f-80dda26cc9d7	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
7cac4b10-da63-4987-bfb4-97096834da03	a7842a56-dc37-454c-9c3a-107952ee261c	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
ce01de34-afad-4263-927a-242136e9c35c	f6cd2b7c-2f02-43ac-9b94-9e6749f9c4fc	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
ea02c07f-f850-4338-8443-5e1a294fef63	596b1610-f65a-415e-8656-2c5a352ff2ad	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
84ae3a73-9fb5-4ef7-b7fd-8cf42a4b784a	d9dd3f6e-ce4d-4a18-b8ca-a822969dc063	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
ec44019e-fb66-4dbe-a9c6-cc0a98904723	dcff1c03-4fc0-4559-b200-6c605e1d1c92	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
543893c3-b8b5-4cc9-9c94-20cbcb019cb6	5d90d841-aef2-42b7-ad7c-5bad03ab7ea6	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
5ad7b426-a154-4154-bdf2-0f7b8dcb6aad	899de085-b827-439f-bfa1-c3636ee086c3	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
f66550c0-77db-4a8e-99ea-531219da8660	36af5a06-bc52-43fb-9ee4-6a4450a185a9	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
5cab396c-3c49-426b-8f4a-71e04f26e8c8	c2897d7d-1236-4406-9fbc-77aaf21561f5	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
259792b1-c894-403a-b988-06ca5af3c2c5	6902ae71-dfb5-4e25-be73-a15222bd6f14	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
a03981eb-5cc2-4483-85c4-c2b284a6dfae	25b9cd05-6def-48ce-9a48-6e585cc2d740	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
6a0db12e-51d9-45b7-8905-77059fd448db	4b2f562a-7984-4295-925d-80542e676925	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
a05c52ad-02fe-49c9-aae3-326eab43299a	48ac994e-6fee-43c7-b2b0-0bab8a296bb9	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
4ec95e47-148d-4e8a-853c-a6fab32f873c	68ef3f7c-c933-4c3c-8d10-04335cce4fdb	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
335990e2-b794-4049-b8b1-80b917284039	ce39ec61-2d85-4aae-b695-25c17093590b	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
527ba4f9-7b40-4ab0-8629-9d5fc7b341f0	a3756424-5fb7-4449-b3e0-5562f8bc8156	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
b7ff47bd-d423-46bd-833e-3ccfd03e6069	45460de0-0548-4f73-a70b-86c8f617b821	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
f562d51c-79bd-4e05-ae8c-7478b494d740	3c9b012a-34c2-4951-9438-7b93a32ecfc0	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
8f28a33d-94b8-43d8-bc95-26167611cda8	76e9c2df-0e54-4093-80dd-36a4de93cc4e	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
53680ec9-db2d-462a-b930-a8e2d9f30dfc	98475941-6ee0-404e-ba86-31a20ed1d91c	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
f80e196d-6218-4f8c-a211-894e298418af	497f93df-ca41-4977-8417-eee7e47ce21d	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
a023d249-926d-476e-8538-9d7a59f0cf97	ec93526b-d2dd-4c0b-ae46-9e4cf14a2163	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
6d0579fe-3d73-484b-843c-ec30733e270c	862a38b7-806e-4386-b73e-ea7dcd228863	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
0332f290-ab02-4ed8-beac-30292d85c959	9021c8ed-7543-43c5-b6ac-d59ad36ac5ae	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
7aab19f6-ce72-493b-9f44-8b35338401e8	5395a9dd-5279-4648-aba4-f95eb0d8fd4f	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
484bb1bf-e98d-4d59-9591-dd236d9acf79	2a82dbfc-f5c1-45d5-9694-796df3892432	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
0953691a-0c74-4f2c-bd2d-c7123d2d847a	971d0982-1019-44c0-a32a-3e01b7333ca3	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
57d17ec3-dff1-4566-98fe-66870d390834	4e29d977-39af-44cd-b533-dac0b92d70c4	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
03dc8184-7957-4423-a49f-d597b6060511	c1f931e3-af3c-424e-812b-98f01a5e2838	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
cf3465de-eb7d-4a8e-a6b5-6588919bb632	ab776410-be94-432c-be51-a6a771ba4b43	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
5c2367af-893f-473d-8a09-3cddac469689	05e5a45e-d599-4bb8-80a9-66f07244532d	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
ee2c0dd8-ead5-42ed-9e7e-5a2bb38ce91e	006db63e-62b0-462e-8d59-e75e1b7bacbb	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
5bb022ad-ced5-438c-8eac-9c306fbdf77c	c4a7f2e2-ec50-4e5f-8979-cb68132d7c40	100.0000000000	1000.0000000000	10.0000000000	2026-03-11 19:17:48.291388+00	dcf898b3-e35e-4bad-8c12-ac2a0722653f	1
b87f27e6-b395-4604-b8f3-8c7967ef2583	86b1126a-dee0-4462-a36e-36a189b0ebe8	100.0000000000	1000.0000000000	10.0000000000	2026-03-11 19:17:48.344086+00	61907652-3698-4713-ada5-0346fdc9c0f7	1
f215e7c6-9ca2-477d-8576-103a9dbdbb5b	d2e70ea0-a318-4841-b0bd-09d031c299c4	50.0000000000	525.0000000000	10.5000000000	2026-03-11 19:17:48.377856+00	6863ffd6-fd85-4710-a834-22b1c483a18a	1
aed673d6-c6d4-4d43-a8e2-b07340d8ad41	a06d5744-bc1c-45d4-b0aa-40b6d418ae24	100.0000000000	1000.0000000000	10.0000000000	2026-03-11 19:17:48.414752+00	729da3df-200d-48d2-93ac-9d71934a6e03	1
fbbd734d-8613-4c2d-902c-40826950aa55	00134054-20cc-4d4c-adb1-5ef072edd566	100.0000000000	1000.0000000000	10.0000000000	2026-03-11 19:17:48.46206+00	560e79e8-eef0-4975-b8de-64f07a15d736	1
91797da6-97ee-4762-a110-772aedf0f225	b6f17b59-241b-4b6f-9bb5-7319310a0649	100.0000000000	1000.0000000000	10.0000000000	2026-03-11 19:17:48.643907+00	746f496b-ef34-4957-9e44-f60ef7c9c2cd	1
c8dd35af-2322-480c-ad23-1218b017b6c4	d9cc5049-e2d5-45c6-9814-d914745fde4e	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
41694260-5bc3-4c21-a896-2f8c05a5061c	367dd67e-d09b-43e7-b8fd-1a12d511eb99	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
65a5083e-27e1-4213-b6fc-b956991d4aa8	e71e4cb1-19ca-4bcd-9fe2-dfe30620d927	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
7badea17-cfb5-4fb5-a613-333c7f79b06c	6f112061-1c1e-48be-8eed-339f20b2dd84	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
c712bacf-99af-4ace-ace5-3659b98f6ade	c25c7532-d987-4b00-9330-16d0e3bd0d63	10.0000000000	1000.0000000000	100.0000000000	2026-03-11 12:00:00+00	\N	1
442751d4-2ed9-4874-a474-4ca686ce88c5	9b93e41a-88ca-49c4-9382-808f327eb605	100.0000000000	1000.0000000000	10.0000000000	2026-03-11 19:17:56.384389+00	c2a5a70c-679f-45c1-bc25-5fd202a4b67e	1
4176c31c-6f31-4f4b-b9d9-273a24ed87d4	aec7239d-f20a-4eca-9c77-fa4ec1184c3d	100.0000000000	1000.0000000000	10.0000000000	2026-03-11 19:17:56.424428+00	185c81dc-ad03-4f21-888a-76b163d9d7d7	1
ac3876c8-859f-4cbd-aebf-59248d4e9e42	005274d7-7dfc-422b-bc07-be64beca35cc	50.0000000000	525.0000000000	10.5000000000	2026-03-11 19:17:56.467158+00	27003e76-bf2c-4cab-919c-5437e723d335	1
5643df5b-1190-410a-8613-fe281ed78219	fc7cd6eb-a2b5-4ded-9c1e-ebae590f8159	100.0000000000	1000.0000000000	10.0000000000	2026-03-11 19:17:56.513276+00	6d515285-1f46-4e49-8291-155fc1cb7764	1
48eb442a-9521-4d87-a013-fae87f350831	48480b7a-d4b7-4105-aeea-1adb045fda27	100.0000000000	1000.0000000000	10.0000000000	2026-03-11 19:17:56.55807+00	68f85e57-a6f0-43fe-9416-21fc40606705	1
ad7e990c-4832-498b-a1c8-ce99cc20c609	d93da6f3-3331-45de-86ae-1f7dfc26fe9d	100.0000000000	1000.0000000000	10.0000000000	2026-03-11 19:17:56.774342+00	a5f7c4e6-40ed-41d1-8d1e-6fb76d1a9b8e	1
0dbb642d-ce67-4752-b6e3-6242d8c69d72	d18e6625-f801-4b20-b29a-531c5a54015f	143.0000000000	18072.3600000000	126.3801398601	2026-03-11 19:44:20.931701+00	6237aac0-172b-4b69-9d86-df2e78ce6cc1	2
\.


--
-- TOC entry 3678 (class 0 OID 18378)
-- Dependencies: 220
-- Data for Name: instrument; Type: TABLE DATA; Schema: public; Owner: ta_app
--

COPY public.instrument (instrument_id, isin, instrument_type, name, created_at) FROM stdin;
56ec3160-c3e8-4c1c-8a05-4210f6cb319a	GB73B734A20A	ETF	Test ETF	2026-03-11 12:25:08.037736+00
cc3db158-d1a3-4f6f-86e8-824e4c850b3d	GB71E8BF4F6D	ETF	Test ETF	2026-03-11 12:25:08.321201+00
bfba1f2c-d4a4-4c15-bc43-e93de3f23638	GBD730D38823	ETF	Test ETF	2026-02-28 01:03:22.35848+00
22519799-5f0d-4a05-a7dd-1afbc8285908	GB6CAD28BA70	ETF	Test ETF	2026-02-28 01:03:22.384551+00
ca9f154a-1a26-4793-b2c4-9b663fbe401f	GB4402457F22	ETF	Test ETF	2026-03-11 12:25:08.587204+00
0ac1938f-c07c-49e3-a19e-203dd4db48c3	GBFF082C20FA	ETF	Test ETF	2026-03-11 12:25:08.799438+00
d7ed03dd-c62e-4d3f-9aca-bbdaf4e6cea6	GB6EA4DA3361	ETF	Test ETF	2026-03-11 12:25:09.017366+00
8c95cb9e-9594-4bd7-a940-552bf8a17758	GBB6F61079EF	ETF	Test ETF	2026-03-11 12:25:32.358426+00
fe3d763d-3210-4987-a10c-a3e082bc83f9	GB72E6991097	ETF	Test ETF	2026-03-11 12:25:32.428508+00
22c5de2a-9488-47c3-9028-e20e38eff987	GB5AD3D0C6CE	ETF	Test ETF	2026-03-11 12:25:32.486455+00
9b3680ec-49a8-4f03-a650-234b5fbcf5b9	GB1869B6BBBF	ETF	Test ETF	2026-03-11 12:25:32.512489+00
cadd1dbc-9918-4f61-b896-d255ac8dab6b	GB37F1736A44	ETF	Test ETF	2026-03-11 12:25:32.562614+00
a93c0bf3-2a6b-4d0a-b834-08ec83898212	GB36E506A024	ETF	Test ETF	2026-03-11 12:25:45.482804+00
b3ab30ad-a5b3-4022-ba6a-8ad6eaa25ee5	GB4C32DB0392	ETF	Test ETF	2026-03-11 12:25:45.545667+00
79770533-2304-427e-aa06-ce09c3aba17a	GBEB2FB96076	ETF	Test ETF	2026-03-11 12:25:45.609719+00
5e979a45-d55e-4082-9675-fb8a1f611ac3	GBC66D688A92	ETF	Test ETF	2026-03-11 12:25:45.637839+00
da9c265c-2e46-41bc-bc6b-dc910f46d641	GB4479DF3489	ETF	Test ETF	2026-03-11 12:25:45.669639+00
9cfc2ea4-b812-489e-a713-4b552495577a	GB77A3CC003F	ETF	Test ETF	2026-03-11 12:27:45.83411+00
a86da4d8-0281-4117-ba54-4cc42030abd9	GB1ED61E5746	ETF	Test ETF	2026-03-11 12:27:45.883021+00
cbfebd82-b1f8-47c7-a777-4e78038859a2	GBD384FC4C27	ETF	Test ETF	2026-02-28 01:05:09.388393+00
37ff0031-91e7-4ba9-b3cd-5e5bff297d56	GBB5A9ACDFA5	ETF	Test ETF	2026-02-28 01:05:09.421988+00
704c6327-3fa0-4cb7-af5d-f374c57ba571	GB1168BC51DC	ETF	Test ETF	2026-03-11 12:27:45.936907+00
dc67697e-1b92-4b85-a5a1-2c4d5ec12a2f	GBA9E4DF14D7	ETF	Test ETF	2026-03-11 12:27:45.961083+00
a831d7f9-2003-49e2-9625-ba84e9f3e0fe	GBC8D3ED277C	ETF	Test ETF	2026-03-11 12:27:45.986843+00
b8e431b3-f5e6-46a1-9f7c-c31a490c6d24	GBB1BF3A1D0B	ETF	Test ETF	2026-03-11 12:43:01.946814+00
b14e43c6-4e2b-4950-b13c-dbbbe9110d77	GBFD06D3EE23	ETF	Test ETF	2026-03-11 12:43:02.008031+00
15cf5bff-6c0a-427e-80f5-87753884e4d5	GBFACB8A0346	ETF	Test ETF	2026-03-11 12:43:02.072858+00
6c660f6d-59f4-4081-b1c1-f4c425db436a	GBFBBDEFB33F	ETF	Test ETF	2026-03-11 12:43:02.104765+00
ef132c6e-b254-4ca8-8cc6-34ebea4cd202	GB9F10347A4E	ETF	Test ETF	2026-03-11 12:43:02.138971+00
d99c908d-bcac-4bd4-a869-054ba2f41a7b	GB3571E06344	ETF	Test ETF	2026-03-11 13:21:30.069251+00
9a38ff1f-77ce-45be-a1da-b0f03e6d83d6	GB5E9162C232	ETF	Test ETF	2026-03-11 13:21:30.127653+00
4feed1fb-a5eb-42a4-b312-fe45e5652523	GB7D37FB57EA	ETF	Test ETF	2026-03-11 13:21:30.181817+00
37e6057c-e346-4ee0-805a-15715ffa8713	GB047D1C9001	ETF	Test ETF	2026-03-11 13:21:30.205589+00
cb998f81-dfd0-4620-b436-05b92dd4290a	GBB1A5FD0A45	ETF	Test ETF	2026-03-11 13:21:30.233593+00
02442434-024d-4dd1-a383-edd4d7fcd60a	GB00B1F5HF48	ETF	iShares Core FTSE 100 UCITS ETF	2026-03-09 18:29:50.877519+00
4b11d2a2-2340-4bab-971b-054181f98a69	GB0073082132	ETF	iShares Core FTSE 100 UCITS ETF (Smoke Test 73082132)	2026-03-09 18:48:56.393942+00
d9ea682a-37a4-439f-8f12-7cfd3e369343	GB0010009854	ETF	iShares Core FTSE 100 UCITS ETF (Smoke Test 10009854)	2026-03-09 19:11:15.464475+00
f9aab776-c8be-43cf-ad78-7636a2bd07d4	GB0010025790	ETF	iShares Core FTSE 100 UCITS ETF (Smoke Test 10025790)	2026-03-09 19:11:34.528454+00
57e84c7e-f14b-481a-b136-02fe746b3b2f	GB0010008718	ETF	iShares Core FTSE 100 UCITS ETF (Smoke Test 10008718)	2026-03-09 19:28:51.381576+00
fef09030-2070-49fb-b3d2-71f4b994f98d	GB0010022190	ETF	iShares Core FTSE 100 UCITS ETF (Smoke Test 10022190)	2026-03-09 19:29:26.814694+00
8167bac8-bd84-4a46-b208-b5f9894415b4	GB0010020244	ETF	iShares Core FTSE 100 UCITS ETF (Smoke Test 10020244)	2026-03-09 19:43:16.600994+00
81a6ec26-063b-45c3-82cb-5efd8c9e9049	GB0010032499	ETF	iShares Core FTSE 100 UCITS ETF (Smoke Test 10032499)	2026-03-09 19:47:46.505981+00
01722dd7-f83c-4176-b81d-1fca13655cf4	GB0010001083	ETF	iShares Core FTSE 100 UCITS ETF (Smoke Test 10001083)	2026-03-09 19:48:58.935709+00
653805c2-c198-4494-94d4-fae2a5f49ba7	GB0010009407	ETF	iShares Core FTSE 100 UCITS ETF (Smoke Test 10009407)	2026-03-09 19:57:02.710268+00
e1bf9c2a-1f87-4220-9b5a-b1836ee6c1b4	GB0010000733	ETF	iShares Core FTSE 100 UCITS ETF (Smoke Test 10000733)	2026-03-09 22:40:04.376038+00
ff4aff31-232d-4023-91ab-147f32f7036f	GB0010010360	ETF	iShares Core FTSE 100 UCITS ETF (Smoke Test 10010360)	2026-03-09 22:51:50.74591+00
2f8161a9-6124-4507-a28d-fbfc587c8f66	GB0010018103	ETF	iShares Core FTSE 100 UCITS ETF (Smoke Test 10018103)	2026-03-09 22:53:33.844698+00
221e2848-c2d3-4dda-9c80-bdf2b7d39b7e	GBFD427C1F19	ETF	Test ETF	2026-03-11 18:53:37.792854+00
023b4e1f-698e-4ae3-a7da-cc447ca87ba9	GB4977DF43D2	ETF	Test ETF	2026-03-11 18:53:37.822873+00
79804e1e-717c-4f9c-bac1-e37cc952553f	GB11259B9051	ETF	Test ETF	2026-03-11 10:14:14.836324+00
cf73431b-f9e7-4ec6-9d05-ec9e9b888768	GBCE795C24C9	ETF	Test ETF	2026-03-11 10:14:14.864555+00
7b6d5061-0268-4550-a9d7-babe8624bd52	GB70818B0E37	ETF	Test ETF	2026-03-11 18:53:38.069153+00
f1962843-e341-48f9-ba36-cba28cb4d383	GB60B1A550B7	ETF	Test ETF	2026-03-11 18:53:38.110797+00
04b04b0b-60df-4d9a-9a28-ea5b3c87f26f	GB38D1534CEB	ETF	Test ETF	2026-03-11 18:53:38.164814+00
f0c4fa37-1605-456f-88ba-476621dc6c5f	GB34A05281E3	ETF	Test ETF	2026-03-11 18:53:38.192659+00
55525140-f1a5-44e1-a779-fac97dbab1dd	GBF150F25523	ETF	Test ETF	2026-03-11 18:53:38.220759+00
fde4cdd6-722e-4349-a077-01eec38ae861	GBFAA62C47F8	ETF	Test ETF	2026-03-11 18:53:38.440794+00
1bcaf757-8e2e-4f6b-ac9f-0ba81656328d	IE00BCRY6557	ETF	iShares Core MSCI Pacific ex-Japan UCITS ETF	2026-03-11 10:24:19.236426+00
6aa36524-4846-435e-aae0-d8fdcb63d753	IE00B4MCH366	ETF	iShares MSCI World Information Technology UCITS ETF	2026-03-11 10:24:19.236426+00
1b55f32e-8459-45e0-8c88-e1dca643bbf3	IE00BYX5K108	ETF	iShares Core MSCI World UCITS ETF USD (Acc)	2026-03-11 10:24:19.236426+00
143e124c-d01e-4d3b-95a3-be85b2973afb	IE00B3VWN518	ETF	iShares UK Gilts 0-5yr UCITS ETF	2026-03-11 10:24:19.236426+00
892de618-d5df-4e8f-b703-2fa9fd778ead	IE00BK5BQT80	ETF	Vanguard FTSE All-World UCITS ETF	2026-03-11 10:24:19.236426+00
9aef7e9b-fcae-4d94-bf47-bd7b2c78acdf	IE00BGPK9703	ETF	Xtrackers MSCI World ESG UCITS ETF	2026-03-11 10:24:19.236426+00
6f903f0a-e820-48f9-8643-e604d995cb60	IE00BJYHR264	ETF	Xtrackers MSCI World Health Care UCITS ETF	2026-03-11 10:24:19.236426+00
629162cb-dfe7-4c3a-a9d2-bb183e0d43dd	GB4993CED047	ETF	Test ETF	2026-03-11 10:53:45.394868+00
99d5e89c-dee1-44fa-bbe0-95b7235931cb	GBBA21965960	ETF	Test ETF	2026-03-11 10:53:45.420449+00
76c80c32-e5db-4665-bc05-2006544bd8ef	GBEFB66615DD	ETF	Test ETF	2026-03-11 19:09:48.782406+00
589edd05-633b-49b6-9a63-112870c8bc21	GB2BEDF62AFB	ETF	Test ETF	2026-03-11 19:09:48.808761+00
93d07120-90f9-4430-892f-5ceee5a6f7ec	GB7015D921F6	ETF	Test ETF	2026-03-11 10:53:45.866512+00
5ae9400b-efa7-4a2c-9a16-91de327399bd	GB4D7E7B4376	ETF	Test ETF	2026-03-11 19:09:49.042834+00
23c16662-4b72-47ad-a641-3b8d4b11bd2d	GB801EAF1C1F	ETF	Test ETF	2026-03-11 19:09:49.08259+00
2d5379fc-7d8b-4e21-b136-1cd1ff591256	GB596EDF74E0	ETF	Test ETF	2026-03-11 19:09:49.132494+00
dff747d9-6aaf-420d-868e-ce5f19e5a8f0	GBFA7E471FA8	ETF	Test ETF	2026-03-11 19:09:49.154504+00
1cb13037-7463-45e5-b5c8-4719bec699ab	GBAE87722614	ETF	Test ETF	2026-03-11 19:09:49.17886+00
0ae17620-9615-4c26-a7de-be25ae15b82e	GB2B44755C6A	ETF	Test ETF	2026-03-11 19:17:00.291702+00
e7697674-0f8a-40e6-bb6a-cc648ee48f0f	GB0A34D6FC4D	ETF	Test ETF	2026-03-11 19:17:48.242372+00
328b07d3-97ee-44a8-aefa-e8f3f7ef665c	GB9CAAE0724E	ETF	Test ETF	2026-03-11 19:17:48.324096+00
ea8c3f81-d5ce-4549-b667-c81eb388e522	GBA516897082	ETF	Test ETF	2026-03-11 19:17:48.360209+00
bcda43bd-1780-4015-b877-d04db9c9230f	GB9DD4041A42	ETF	Test ETF	2026-03-11 19:17:48.39204+00
1451f908-b187-4768-bcb3-1bb4a92b0001	GB5261978F75	ETF	Test ETF	2026-03-11 19:17:48.43849+00
cc45f751-fe65-4339-af94-880a6bcd189b	GBF4A95E28A1	ETF	Test ETF	2026-03-11 19:17:48.478389+00
729b1826-2ae3-4515-953d-436a91d9b7ff	GBF5F6EC2003	ETF	Test ETF	2026-03-11 19:17:48.5041+00
06be3c1b-14dd-4439-8d14-9cc2ec0cb15f	GB3741A01F06	ETF	Test ETF	2026-03-11 19:17:48.53203+00
8322abee-aabd-4dbe-8090-f2d93e54b8c8	GB83A7C7311F	ETF	Test ETF	2026-03-11 19:17:48.560751+00
f9aa210a-c11e-441a-a43e-a9a53bac575c	GB9BB9A9909A	ETF	Test ETF	2026-03-11 19:17:48.592364+00
329a43f2-27c3-418a-8c4f-9e1e0803b6d6	GB3FCE0AF0C2	ETF	Test ETF	2026-03-11 19:17:48.62608+00
85a48f7d-3c03-44f1-b151-d573f50b5633	GB2212E380B9	ETF	Test ETF	2026-03-11 19:17:55.880366+00
b20d9b40-7e90-4e23-94ab-922aa8068a90	GB9DDEFAC904	ETF	Test ETF	2026-03-11 19:17:55.908482+00
c3a1f36b-ee14-48f6-93f3-7cb57693945f	GB2093231544	ETF	Test ETF	2026-03-11 19:17:56.174228+00
e3f52eba-d3d5-415c-8d4a-99f849dddc4b	GBB27A08B6AD	ETF	Test ETF	2026-03-11 19:17:56.206528+00
5157bd6f-ebef-45a3-bcb6-4a71d92b1eab	GBA035F6A0AB	ETF	Test ETF	2026-03-11 19:17:56.268425+00
eb919e5a-01ad-4ad3-b3c8-303bea7864eb	GB5D613FF8B6	ETF	Test ETF	2026-03-11 19:17:56.298326+00
d8a739e0-edb8-4e12-b482-be448ff497a5	GB9A82C4CF72	ETF	Test ETF	2026-03-11 19:17:56.330307+00
5df0ff50-f84e-4f7e-aeac-20fe3610e537	GBA9348867CA	ETF	Test ETF	2026-03-11 19:17:56.356353+00
381b41a1-1913-4730-a4e7-2e3c96bdd79a	GBB7FD83874F	ETF	Test ETF	2026-03-11 19:17:56.404165+00
11cc4c74-1d98-4ce4-a823-6cefa9fa9632	GBACB79BBBD5	ETF	Test ETF	2026-03-11 19:17:56.440165+00
538286db-bcf6-40e0-9ada-497c471f1ce2	GB4E1C42E9D1	ETF	Test ETF	2026-03-11 19:17:56.486376+00
a87b5503-f063-44e6-8d09-d61f2f81b1a0	GB24097C2FC5	ETF	Test ETF	2026-03-11 19:17:56.536262+00
1aae73cf-2875-4c01-8523-f0f6e117a7b1	GB28F9286F7D	ETF	Test ETF	2026-03-11 19:17:56.576395+00
d9b6aa74-67c3-4a86-ae92-599c231fdc5d	GBEEF693E7B8	ETF	Test ETF	2026-03-11 19:17:56.606131+00
b8d85ae0-8b09-42c9-82f8-a2344e17687f	GB09E9D83481	ETF	Test ETF	2026-03-11 19:17:56.63034+00
dd2ff887-6331-4ae7-a14f-2434cf3ac246	GBBE8DC4F3EE	ETF	Test ETF	2026-03-11 19:17:56.668376+00
26327a2e-4e70-4af1-a36f-aca8371df82b	GB2B888B140F	ETF	Test ETF	2026-03-11 19:17:56.704355+00
05c7d60d-d4e4-42b3-8b7c-457930c58571	GB1AA529CDB0	ETF	Test ETF	2026-03-11 19:17:56.746441+00
944070a5-488e-48c1-a6a7-7468c6819ba0	GBBA1831FBED	ETF	Test ETF	2026-03-11 19:17:57.096181+00
\.


--
-- TOC entry 3690 (class 0 OID 26270)
-- Dependencies: 232
-- Data for Name: ledger_batches; Type: TABLE DATA; Schema: public; Owner: ta_app
--

COPY public.ledger_batches (batch_id, portfolio_id, submitted_by_user_id, source, created_at, note, meta, idempotency_key) FROM stdin;
f3816707-95ea-486c-af0d-a28d1eb120be	e5fa701e-6756-4a03-ac4f-052407357964	05c894d8-502e-4e36-be45-fee805b83e9a	UI	2026-03-10 20:30:52.100802+00	\N	null	\N
cac3f46b-b84a-4400-bac6-8c069e75b439	0dbb642d-ce67-4752-b6e3-6242d8c69d72	05c894d8-502e-4e36-be45-fee805b83e9a	CSV_IMPORT	2026-03-11 11:16:55.021739+00	CSV Import: positions_gbp_v1	{"plan_hash": "1dea24dc78a5414d", "csv_profile": "positions_gbp_v1", "source_file_sha256": "6677d45bf76190c2bc0b184de196d9e10ee7450f8d8216c453c0962000b8525e"}	\N
8d8c1173-3d05-48b2-8c19-e8a8dbbd5b11	5bb022ad-ced5-438c-8eac-9c306fbdf77c	aa4e1960-7d43-46b6-ae8d-b184cdb470bd	UI	2026-03-11 19:17:48.276427+00	Execution of recommendation batch 2d214464-ee82-4bb1-b780-6a42af7c5b9d	null	\N
7915c416-8379-4b43-aaab-941b948dc656	b87f27e6-b395-4604-b8f3-8c7967ef2583	286a21d8-bda0-45dc-aaf1-40da26b918e4	UI	2026-03-11 19:17:48.340203+00	Execution of recommendation batch 60a039f2-8d6d-4ce1-868b-d82c9a49ceb7	null	\N
10587a54-c7f1-42fa-b690-3ece0796c693	f215e7c6-9ca2-477d-8576-103a9dbdbb5b	0842f730-0598-4271-93d5-6766297f29b1	UI	2026-03-11 19:17:48.374166+00	Execution of recommendation batch 82b3c0bb-df5b-48e1-9335-13be89ef0559	null	\N
7c868f57-db7a-4ccf-adc2-4aeaae3d6fb4	aed673d6-c6d4-4d43-a8e2-b07340d8ad41	1420911d-1722-4d2f-a969-6343dbfb6d1a	UI	2026-03-11 19:17:48.410417+00	Execution of recommendation batch d5b8d681-efee-4303-b5d7-6ad325a5ef8b	null	\N
154a38eb-bf8a-495b-9572-75196fa7e951	fbbd734d-8613-4c2d-902c-40826950aa55	bb694a18-6764-46e4-9179-5e4abed2e56c	UI	2026-03-11 19:17:48.45814+00	Execution of recommendation batch 21277236-2a86-4561-ab04-6aa6a9579c92	null	\N
6056aaa4-bfb0-44d3-80a7-acec763262a5	91797da6-97ee-4762-a110-772aedf0f225	74883a77-453c-47db-bbb9-ead741b63dad	UI	2026-03-11 19:17:48.640049+00	Execution of recommendation batch a6ad2470-0283-4327-8660-3a67d38ba888	null	\N
82a8f598-f95f-482d-bc03-a6c7cd8960db	442751d4-2ed9-4874-a474-4ca686ce88c5	18f8a6d4-7795-4380-9ebf-6ba112d8f799	UI	2026-03-11 19:17:56.374266+00	Execution of recommendation batch be4adaf9-c48d-43c6-918c-a49ac6d06607	null	\N
47ad61ff-28d0-45ba-903b-d4ae3fd26ede	4176c31c-6f31-4f4b-b9d9-273a24ed87d4	d35f101b-7748-4535-b571-43a0e0e274d1	UI	2026-03-11 19:17:56.420253+00	Execution of recommendation batch 9444313c-6c5d-4c0c-b2a1-e846c97e30cc	null	\N
fd87adbd-6be2-494b-a63c-32b778b613aa	ac3876c8-859f-4cbd-aebf-59248d4e9e42	3cca1d39-faa3-4a3d-9a6a-25302a708b28	UI	2026-03-11 19:17:56.460495+00	Execution of recommendation batch c86bbff6-32c6-406d-9092-3dce49af9ec2	null	\N
908a3f8f-c04d-47e7-bdf8-acfe91d01da7	5643df5b-1190-410a-8613-fe281ed78219	319b1561-136d-4601-a951-26d74f7a14ac	UI	2026-03-11 19:17:56.506383+00	Execution of recommendation batch 44493dfb-9139-4bca-a0b5-3b28461b9961	null	\N
a9f86105-cdd5-4fd8-9381-6319a0a66575	48eb442a-9521-4d87-a013-fae87f350831	ea2b69fc-f81a-4a08-bef2-943e826a5b81	UI	2026-03-11 19:17:56.55412+00	Execution of recommendation batch 2e729c0d-a28c-490b-a739-fd9642942543	null	\N
ef6b92dd-180e-4fde-a615-685954e197f2	ad7e990c-4832-498b-a1c8-ce99cc20c609	e4050dcc-060b-4ef8-aa5e-e3f1c6a976b7	UI	2026-03-11 19:17:56.768137+00	Execution of recommendation batch 99f3937f-6ea3-474d-b895-3d19ee20f269	null	\N
5653d08d-f8f0-48db-be4e-cb4888dea272	0dbb642d-ce67-4752-b6e3-6242d8c69d72	05c894d8-502e-4e36-be45-fee805b83e9a	UI	2026-03-11 19:44:20.924918+00	\N	null	\N
\.


--
-- TOC entry 3691 (class 0 OID 26291)
-- Dependencies: 233
-- Data for Name: ledger_entries; Type: TABLE DATA; Schema: public; Owner: ta_app
--

COPY public.ledger_entries (entry_id, batch_id, portfolio_id, entry_kind, effective_at, listing_id, quantity_delta, net_cash_delta_gbp, fee_gbp, book_cost_delta_gbp, reversal_of_entry_id, created_at, note, meta) FROM stdin;
5278d9e5-af40-4e9c-b7a4-6fbbc75cc243	f3816707-95ea-486c-af0d-a28d1eb120be	e5fa701e-6756-4a03-ac4f-052407357964	CONTRIBUTION	2024-01-01 00:00:00+00	\N	\N	1000.0000000000	\N	\N	\N	2026-03-10 20:30:52.100802+00	\N	null
7d8bafa5-5e93-4439-9342-9680df906d30	cac3f46b-b84a-4400-bac6-8c069e75b439	0dbb642d-ce67-4752-b6e3-6242d8c69d72	BUY	2026-03-11 10:06:00+00	2775a081-069b-4fa0-a7d9-a52353320dab	13.0000000000	-15895.9300000000	0.0000000000	15895.9300000000	\N	2026-03-11 11:16:55.021739+00	Import BUY for CSH2	null
c5aa7408-3b9c-4d8c-8007-c403ba5dc6f9	cac3f46b-b84a-4400-bac6-8c069e75b439	0dbb642d-ce67-4752-b6e3-6242d8c69d72	BUY	2026-03-11 10:06:00+00	59976aac-caa6-4e73-b57b-2483c47d5c56	500.0000000000	-4923.1000000000	0.0000000000	4923.1000000000	\N	2026-03-11 11:16:55.021739+00	Import BUY for SEMI	null
306437e4-dc89-4fd0-bd04-8bdb136dc6fd	cac3f46b-b84a-4400-bac6-8c069e75b439	0dbb642d-ce67-4752-b6e3-6242d8c69d72	BUY	2026-03-11 10:06:00+00	8f574494-d8c0-4ce7-979a-1c058718e609	330.0000000000	-2387.9300000000	0.0000000000	2387.9300000000	\N	2026-03-11 11:16:55.021739+00	Import BUY for WLDS	null
b554b2ae-2c2b-4e9c-8c77-62492e92ff10	cac3f46b-b84a-4400-bac6-8c069e75b439	0dbb642d-ce67-4752-b6e3-6242d8c69d72	BUY	2026-03-11 10:06:00+00	44c9f233-ded8-44e5-8dda-f467827fe671	425.0000000000	-2400.9800000000	0.0000000000	2400.9800000000	\N	2026-03-11 11:16:55.021739+00	Import BUY for IGL5	null
23d93a6e-031d-4fca-aa25-6213f1f157ab	cac3f46b-b84a-4400-bac6-8c069e75b439	0dbb642d-ce67-4752-b6e3-6242d8c69d72	BUY	2026-03-11 10:06:00+00	d18e6625-f801-4b20-b29a-531c5a54015f	140.0000000000	-17942.3600000000	0.0000000000	17942.3600000000	\N	2026-03-11 11:16:55.021739+00	Import BUY for VWRP	null
48e83646-3b3b-49dc-bcf6-26b06af24ed5	cac3f46b-b84a-4400-bac6-8c069e75b439	0dbb642d-ce67-4752-b6e3-6242d8c69d72	BUY	2026-03-11 10:06:00+00	427a4690-316c-462d-add9-199e0c71de0d	25.0000000000	-1200.4600000000	0.0000000000	1200.4600000000	\N	2026-03-11 11:16:55.021739+00	Import BUY for XWES	null
bd40940f-7173-423d-9b9f-2004bc47b10c	cac3f46b-b84a-4400-bac6-8c069e75b439	0dbb642d-ce67-4752-b6e3-6242d8c69d72	BUY	2026-03-11 10:06:00+00	1bc182b8-7410-4026-9d64-c628a13c4836	25.0000000000	-1111.5600000000	0.0000000000	1111.5600000000	\N	2026-03-11 11:16:55.021739+00	Import BUY for XWHS	null
7e7b18a3-18fe-4007-8384-a4d2405f6205	cac3f46b-b84a-4400-bac6-8c069e75b439	0dbb642d-ce67-4752-b6e3-6242d8c69d72	CONTRIBUTION	2026-03-11 10:06:00+00	\N	\N	46500.0000000000	\N	\N	\N	2026-03-11 11:16:55.021739+00	Cash reconciliation - top up	null
dcf898b3-e35e-4bad-8c12-ac2a0722653f	8d8c1173-3d05-48b2-8c19-e8a8dbbd5b11	5bb022ad-ced5-438c-8eac-9c306fbdf77c	BUY	2026-03-11 19:17:48.283022+00	c4a7f2e2-ec50-4e5f-8979-cb68132d7c40	100.0000000000	-1005.0000000000	5.0000000000	\N	\N	2026-03-11 19:17:48.276427+00	Executed from recommendation 2d214464-ee82-4bb1-b780-6a42af7c5b9d	null
61907652-3698-4713-ada5-0346fdc9c0f7	7915c416-8379-4b43-aaab-941b948dc656	b87f27e6-b395-4604-b8f3-8c7967ef2583	BUY	2026-03-11 19:17:48.342059+00	86b1126a-dee0-4462-a36e-36a189b0ebe8	100.0000000000	-1005.0000000000	5.0000000000	\N	\N	2026-03-11 19:17:48.340203+00	Executed from recommendation 60a039f2-8d6d-4ce1-868b-d82c9a49ceb7	null
6863ffd6-fd85-4710-a834-22b1c483a18a	10587a54-c7f1-42fa-b690-3ece0796c693	f215e7c6-9ca2-477d-8576-103a9dbdbb5b	BUY	2026-03-11 19:17:48.375887+00	d2e70ea0-a318-4841-b0bd-09d031c299c4	50.0000000000	-528.0000000000	3.0000000000	\N	\N	2026-03-11 19:17:48.374166+00	Test execution note	null
729da3df-200d-48d2-93ac-9d71934a6e03	7c868f57-db7a-4ccf-adc2-4aeaae3d6fb4	aed673d6-c6d4-4d43-a8e2-b07340d8ad41	BUY	2026-03-11 19:17:48.412681+00	a06d5744-bc1c-45d4-b0aa-40b6d418ae24	100.0000000000	-1005.0000000000	5.0000000000	\N	\N	2026-03-11 19:17:48.410417+00	Executed from recommendation d5b8d681-efee-4303-b5d7-6ad325a5ef8b	null
560e79e8-eef0-4975-b8de-64f07a15d736	154a38eb-bf8a-495b-9572-75196fa7e951	fbbd734d-8613-4c2d-902c-40826950aa55	BUY	2026-03-11 19:17:48.459951+00	00134054-20cc-4d4c-adb1-5ef072edd566	100.0000000000	-1005.0000000000	5.0000000000	\N	\N	2026-03-11 19:17:48.45814+00	Executed from recommendation 21277236-2a86-4561-ab04-6aa6a9579c92	null
746f496b-ef34-4957-9e44-f60ef7c9c2cd	6056aaa4-bfb0-44d3-80a7-acec763262a5	91797da6-97ee-4762-a110-772aedf0f225	BUY	2026-03-11 19:17:48.641846+00	b6f17b59-241b-4b6f-9bb5-7319310a0649	100.0000000000	-1005.0000000000	5.0000000000	\N	\N	2026-03-11 19:17:48.640049+00	Executed from recommendation a6ad2470-0283-4327-8660-3a67d38ba888	null
c2a5a70c-679f-45c1-bc25-5fd202a4b67e	82a8f598-f95f-482d-bc03-a6c7cd8960db	442751d4-2ed9-4874-a474-4ca686ce88c5	BUY	2026-03-11 19:17:56.379808+00	9b93e41a-88ca-49c4-9382-808f327eb605	100.0000000000	-1005.0000000000	5.0000000000	\N	\N	2026-03-11 19:17:56.374266+00	Executed from recommendation be4adaf9-c48d-43c6-918c-a49ac6d06607	null
185c81dc-ad03-4f21-888a-76b163d9d7d7	47ad61ff-28d0-45ba-903b-d4ae3fd26ede	4176c31c-6f31-4f4b-b9d9-273a24ed87d4	BUY	2026-03-11 19:17:56.422261+00	aec7239d-f20a-4eca-9c77-fa4ec1184c3d	100.0000000000	-1005.0000000000	5.0000000000	\N	\N	2026-03-11 19:17:56.420253+00	Executed from recommendation 9444313c-6c5d-4c0c-b2a1-e846c97e30cc	null
27003e76-bf2c-4cab-919c-5437e723d335	fd87adbd-6be2-494b-a63c-32b778b613aa	ac3876c8-859f-4cbd-aebf-59248d4e9e42	BUY	2026-03-11 19:17:56.463742+00	005274d7-7dfc-422b-bc07-be64beca35cc	50.0000000000	-528.0000000000	3.0000000000	\N	\N	2026-03-11 19:17:56.460495+00	Test execution note	null
6d515285-1f46-4e49-8291-155fc1cb7764	908a3f8f-c04d-47e7-bdf8-acfe91d01da7	5643df5b-1190-410a-8613-fe281ed78219	BUY	2026-03-11 19:17:56.509623+00	fc7cd6eb-a2b5-4ded-9c1e-ebae590f8159	100.0000000000	-1005.0000000000	5.0000000000	\N	\N	2026-03-11 19:17:56.506383+00	Executed from recommendation 44493dfb-9139-4bca-a0b5-3b28461b9961	null
68f85e57-a6f0-43fe-9416-21fc40606705	a9f86105-cdd5-4fd8-9381-6319a0a66575	48eb442a-9521-4d87-a013-fae87f350831	BUY	2026-03-11 19:17:56.556059+00	48480b7a-d4b7-4105-aeea-1adb045fda27	100.0000000000	-1005.0000000000	5.0000000000	\N	\N	2026-03-11 19:17:56.55412+00	Executed from recommendation 2e729c0d-a28c-490b-a739-fd9642942543	null
a5f7c4e6-40ed-41d1-8d1e-6fb76d1a9b8e	ef6b92dd-180e-4fde-a615-685954e197f2	ad7e990c-4832-498b-a1c8-ce99cc20c609	BUY	2026-03-11 19:17:56.770062+00	d93da6f3-3331-45de-86ae-1f7dfc26fe9d	100.0000000000	-1005.0000000000	5.0000000000	\N	\N	2026-03-11 19:17:56.768137+00	Executed from recommendation 99f3937f-6ea3-474d-b895-3d19ee20f269	null
6237aac0-172b-4b69-9d86-df2e78ce6cc1	5653d08d-f8f0-48db-be4e-cb4888dea272	0dbb642d-ce67-4752-b6e3-6242d8c69d72	BUY	2026-03-11 19:43:00+00	d18e6625-f801-4b20-b29a-531c5a54015f	3.0000000000	-130.0000000000	\N	\N	\N	2026-03-11 19:44:20.924918+00	test run	null
\.


--
-- TOC entry 3682 (class 0 OID 18417)
-- Dependencies: 224
-- Data for Name: listing; Type: TABLE DATA; Schema: public; Owner: ta_app
--

COPY public.listing (listing_id, instrument_id, ticker, exchange, trading_currency, quote_scale, is_primary, created_at) FROM stdin;
ab23e017-eb59-4228-a2d6-234667a037b7	56ec3160-c3e8-4c1c-8a05-4210f6cb319a	TST5175	LSE	GBP	MINOR	t	2026-03-11 12:25:08.044808+00
8b29ed40-bcd5-4a40-926e-8ee7be584a9f	cc3db158-d1a3-4f6f-86e8-824e4c850b3d	TST8707	LSE	GBP	MINOR	t	2026-03-11 12:25:08.325273+00
eaaa7c97-fc67-4e1b-af3b-8e16ad1fcf1d	bfba1f2c-d4a4-4c15-bc43-e93de3f23638	TST201A	LSE	GBP	MINOR	t	2026-02-28 01:03:22.362495+00
2b488802-7e2e-4a36-9e23-d3da7bb09212	22519799-5f0d-4a05-a7dd-1afbc8285908	TST7A50	LSE	GBP	MINOR	t	2026-02-28 01:03:22.388496+00
ce8f5256-b2c8-473f-b1dc-10f6bf212893	ca9f154a-1a26-4793-b2c4-9b663fbe401f	TST9922	LSE	GBP	MINOR	t	2026-03-11 12:25:08.591193+00
5a32f6af-dbe2-40d9-8267-184e973a3330	0ac1938f-c07c-49e3-a19e-203dd4db48c3	TST2294	LSE	GBP	MINOR	t	2026-03-11 12:25:08.803443+00
936da442-bad3-4e06-8259-f9809b5913eb	d7ed03dd-c62e-4d3f-9aca-bbdaf4e6cea6	TSTA82F	LSE	GBP	MINOR	t	2026-03-11 12:25:09.02105+00
1c918015-04cd-4bd4-aa2f-4480a02e6947	8c95cb9e-9594-4bd7-a940-552bf8a17758	TSTD3B5	LSE	GBP	MINOR	t	2026-03-11 12:25:32.365844+00
bb678d70-3ece-4993-a5b6-e8e46fb8839f	fe3d763d-3210-4987-a10c-a3e082bc83f9	TST9BFA	LSE	GBP	MINOR	t	2026-03-11 12:25:32.432453+00
3539aef7-0437-4e3f-b37f-80dda26cc9d7	22c5de2a-9488-47c3-9028-e20e38eff987	TST2563	LSE	GBP	MINOR	t	2026-03-11 12:25:32.490455+00
a7842a56-dc37-454c-9c3a-107952ee261c	9b3680ec-49a8-4f03-a650-234b5fbcf5b9	TST5D9B	LSE	GBP	MINOR	t	2026-03-11 12:25:32.516589+00
f6cd2b7c-2f02-43ac-9b94-9e6749f9c4fc	cadd1dbc-9918-4f61-b896-d255ac8dab6b	TSTA99F	LSE	GBP	MINOR	t	2026-03-11 12:25:32.566576+00
596b1610-f65a-415e-8656-2c5a352ff2ad	a93c0bf3-2a6b-4d0a-b834-08ec83898212	TSTAC00	LSE	GBP	MINOR	t	2026-03-11 12:25:45.490689+00
d9dd3f6e-ce4d-4a18-b8ca-a822969dc063	b3ab30ad-a5b3-4022-ba6a-8ad6eaa25ee5	TST07D8	LSE	GBP	MINOR	t	2026-03-11 12:25:45.549822+00
dcff1c03-4fc0-4559-b200-6c605e1d1c92	79770533-2304-427e-aa06-ce09c3aba17a	TST9B0F	LSE	GBP	MINOR	t	2026-03-11 12:25:45.613875+00
5d90d841-aef2-42b7-ad7c-5bad03ab7ea6	5e979a45-d55e-4082-9675-fb8a1f611ac3	TST5AB6	LSE	GBP	MINOR	t	2026-03-11 12:25:45.641602+00
899de085-b827-439f-bfa1-c3636ee086c3	da9c265c-2e46-41bc-bc6b-dc910f46d641	TST9C85	LSE	GBP	MINOR	t	2026-03-11 12:25:45.673587+00
36af5a06-bc52-43fb-9ee4-6a4450a185a9	9cfc2ea4-b812-489e-a713-4b552495577a	TST5221	LSE	GBP	MINOR	t	2026-03-11 12:27:45.839562+00
c2897d7d-1236-4406-9fbc-77aaf21561f5	a86da4d8-0281-4117-ba54-4cc42030abd9	TST7B88	LSE	GBP	MINOR	t	2026-03-11 12:27:45.886859+00
3d6c55fb-d280-40cd-8eda-ac59742caaac	cbfebd82-b1f8-47c7-a777-4e78038859a2	TST1A47	LSE	GBP	MINOR	t	2026-02-28 01:05:09.392324+00
ed2ab589-0674-47c3-b3d3-98b208ec8dfd	37ff0031-91e7-4ba9-b3cd-5e5bff297d56	TST1BED	LSE	GBP	MINOR	t	2026-02-28 01:05:09.425879+00
6902ae71-dfb5-4e25-be73-a15222bd6f14	704c6327-3fa0-4cb7-af5d-f374c57ba571	TST4797	LSE	GBP	MINOR	t	2026-03-11 12:27:45.94096+00
25b9cd05-6def-48ce-9a48-6e585cc2d740	dc67697e-1b92-4b85-a5a1-2c4d5ec12a2f	TSTE559	LSE	GBP	MINOR	t	2026-03-11 12:27:45.965088+00
4b2f562a-7984-4295-925d-80542e676925	a831d7f9-2003-49e2-9625-ba84e9f3e0fe	TST9882	LSE	GBP	MINOR	t	2026-03-11 12:27:45.991101+00
48ac994e-6fee-43c7-b2b0-0bab8a296bb9	b8e431b3-f5e6-46a1-9f7c-c31a490c6d24	TST3F82	LSE	GBP	MINOR	t	2026-03-11 12:43:01.955802+00
68ef3f7c-c933-4c3c-8d10-04335cce4fdb	b14e43c6-4e2b-4950-b13c-dbbbe9110d77	TST08FC	LSE	GBP	MINOR	t	2026-03-11 12:43:02.01092+00
ce39ec61-2d85-4aae-b695-25c17093590b	15cf5bff-6c0a-427e-80f5-87753884e4d5	TST11F0	LSE	GBP	MINOR	t	2026-03-11 12:43:02.077117+00
a3756424-5fb7-4449-b3e0-5562f8bc8156	6c660f6d-59f4-4081-b1c1-f4c425db436a	TSTD704	LSE	GBP	MINOR	t	2026-03-11 12:43:02.108723+00
45460de0-0548-4f73-a70b-86c8f617b821	ef132c6e-b254-4ca8-8cc6-34ebea4cd202	TST28AA	LSE	GBP	MINOR	t	2026-03-11 12:43:02.142804+00
3c9b012a-34c2-4951-9438-7b93a32ecfc0	d99c908d-bcac-4bd4-a869-054ba2f41a7b	TST96C4	LSE	GBP	MINOR	t	2026-03-11 13:21:30.078465+00
76e9c2df-0e54-4093-80dd-36a4de93cc4e	9a38ff1f-77ce-45be-a1da-b0f03e6d83d6	TSTBDBC	LSE	GBP	MINOR	t	2026-03-11 13:21:30.131834+00
98475941-6ee0-404e-ba86-31a20ed1d91c	4feed1fb-a5eb-42a4-b312-fe45e5652523	TST01F0	LSE	GBP	MINOR	t	2026-03-11 13:21:30.185968+00
497f93df-ca41-4977-8417-eee7e47ce21d	37e6057c-e346-4ee0-805a-15715ffa8713	TST0B3A	LSE	GBP	MINOR	t	2026-03-11 13:21:30.20959+00
ec93526b-d2dd-4c0b-ae46-9e4cf14a2163	cb998f81-dfd0-4620-b436-05b92dd4290a	TSTD057	LSE	GBP	MINOR	t	2026-03-11 13:21:30.237634+00
88535377-562e-4c57-86af-3113c6acf175	02442434-024d-4dd1-a383-edd4d7fcd60a	ISFA	LSE	GBP	GBX	t	2026-03-09 18:29:50.89597+00
3f68fc52-2b2a-450d-a9f1-35953182f0bf	4b11d2a2-2340-4bab-971b-054181f98a69	ISFA_73082132	LSE	GBP	GBX	t	2026-03-09 18:48:56.412805+00
c45ba9ad-d86c-4c03-af24-2f7a3d2838af	4b11d2a2-2340-4bab-971b-054181f98a69	ISFA_73082132	LSE	GBP	GBX	t	2026-03-09 18:50:03.498359+00
866c545a-69e7-496b-b8a1-ebe684435d7e	d9ea682a-37a4-439f-8f12-7cfd3e369343	ISFA_10009854	LSE	GBP	GBX	t	2026-03-09 19:11:15.478562+00
3478c924-17e9-4ee6-b279-0a52e6c240e3	f9aab776-c8be-43cf-ad78-7636a2bd07d4	ISFA_10025790	LSE	GBP	GBX	t	2026-03-09 19:11:34.549505+00
d5e2cbdb-80fa-4c69-be09-0890e0922436	57e84c7e-f14b-481a-b136-02fe746b3b2f	ISFA_10008718	LSE	GBP	GBX	t	2026-03-09 19:28:51.399577+00
d4d321dd-4a54-49bf-856e-974153886506	fef09030-2070-49fb-b3d2-71f4b994f98d	ISFA_10022190	LSE	GBP	GBX	t	2026-03-09 19:29:26.833316+00
c28427b9-8315-4ede-8827-ee3cf6796fac	8167bac8-bd84-4a46-b208-b5f9894415b4	ISFA_10020244	LSE	GBP	GBX	t	2026-03-09 19:43:16.618853+00
1f7ef26a-acbf-4164-b0c3-ce0c28439dfe	81a6ec26-063b-45c3-82cb-5efd8c9e9049	ISFA_10032499	LSE	GBP	GBX	t	2026-03-09 19:47:46.523039+00
4fbbf0de-6b55-476e-b8cf-15e2e67525dd	01722dd7-f83c-4176-b81d-1fca13655cf4	ISFA_10001083	LSE	GBP	GBX	t	2026-03-09 19:48:58.955619+00
c3927a82-1029-4cdc-a114-50f0f298f57d	653805c2-c198-4494-94d4-fae2a5f49ba7	ISFA_10009407	LSE	GBP	GBX	t	2026-03-09 19:57:02.726342+00
1f4880c2-cdb8-4068-8f3d-0df11f4e07ed	e1bf9c2a-1f87-4220-9b5a-b1836ee6c1b4	ISFA_10000733	LSE	GBP	GBX	t	2026-03-09 22:40:04.391345+00
ce1530ec-4916-4b5d-9530-ef47e0bf8b8d	ff4aff31-232d-4023-91ab-147f32f7036f	ISFA_10010360	LSE	GBP	GBX	t	2026-03-09 22:51:50.763725+00
a9fb309f-bb1e-41c1-a9c9-808807038195	2f8161a9-6124-4507-a28d-fbfc587c8f66	ISFA_10018103	LSE	GBP	GBX	t	2026-03-09 22:53:33.860815+00
de5c4f78-0e81-426e-a26a-ee8200bac0ee	221e2848-c2d3-4dda-9c80-bdf2b7d39b7e	TST24FD	LSE	GBP	MINOR	t	2026-03-11 18:53:37.796779+00
cac8473e-4d3b-4c18-81ba-c5035470d95a	023b4e1f-698e-4ae3-a7da-cc447ca87ba9	TST289B	LSE	GBP	MINOR	t	2026-03-11 18:53:37.826921+00
c5e26f80-abe8-4751-b5ca-454f15d9a10e	79804e1e-717c-4f9c-bac1-e37cc952553f	TST5F84	LSE	GBP	MINOR	t	2026-03-11 10:14:14.840596+00
791fb965-1104-48fb-a1bd-43ad06a22740	cf73431b-f9e7-4ec6-9d05-ec9e9b888768	TST2EA2	LSE	GBP	MINOR	t	2026-03-11 10:14:14.868507+00
862a38b7-806e-4386-b73e-ea7dcd228863	7b6d5061-0268-4550-a9d7-babe8624bd52	TST661D	LSE	GBP	MINOR	t	2026-03-11 18:53:38.075236+00
9021c8ed-7543-43c5-b6ac-d59ad36ac5ae	f1962843-e341-48f9-ba36-cba28cb4d383	TSTEFC5	LSE	GBP	MINOR	t	2026-03-11 18:53:38.114941+00
5395a9dd-5279-4648-aba4-f95eb0d8fd4f	04b04b0b-60df-4d9a-9a28-ea5b3c87f26f	TST11B0	LSE	GBP	MINOR	t	2026-03-11 18:53:38.168953+00
2a82dbfc-f5c1-45d5-9694-796df3892432	f0c4fa37-1605-456f-88ba-476621dc6c5f	TST3D96	LSE	GBP	MINOR	t	2026-03-11 18:53:38.194795+00
971d0982-1019-44c0-a32a-3e01b7333ca3	55525140-f1a5-44e1-a779-fac97dbab1dd	TST0BA0	LSE	GBP	MINOR	t	2026-03-11 18:53:38.224867+00
2775a081-069b-4fa0-a7d9-a52353320dab	1bcaf757-8e2e-4f6b-ac9f-0ba81656328d	CSH2	LSE	GBP	GBX	t	2026-03-11 10:24:19.236426+00
59976aac-caa6-4e73-b57b-2483c47d5c56	6aa36524-4846-435e-aae0-d8fdcb63d753	SEMI	LSE	GBP	GBX	t	2026-03-11 10:24:19.236426+00
8f574494-d8c0-4ce7-979a-1c058718e609	1b55f32e-8459-45e0-8c88-e1dca643bbf3	WLDS	LSE	GBP	GBX	t	2026-03-11 10:24:19.236426+00
44c9f233-ded8-44e5-8dda-f467827fe671	143e124c-d01e-4d3b-95a3-be85b2973afb	IGL5	LSE	GBP	GBX	t	2026-03-11 10:24:19.236426+00
d18e6625-f801-4b20-b29a-531c5a54015f	892de618-d5df-4e8f-b703-2fa9fd778ead	VWRP	LSE	GBP	GBX	t	2026-03-11 10:24:19.236426+00
427a4690-316c-462d-add9-199e0c71de0d	9aef7e9b-fcae-4d94-bf47-bd7b2c78acdf	XWES	LSE	GBP	GBX	t	2026-03-11 10:24:19.236426+00
1bc182b8-7410-4026-9d64-c628a13c4836	6f903f0a-e820-48f9-8643-e604d995cb60	XWHS	LSE	GBP	GBX	t	2026-03-11 10:24:19.236426+00
1cc34621-62e1-4267-abab-844a9c30cc1c	fde4cdd6-722e-4349-a077-01eec38ae861	TST52BE	LSE	GBP	MINOR	t	2026-03-11 18:53:38.444999+00
3ed3b943-a168-4394-8819-5ecb74e9b1cf	629162cb-dfe7-4c3a-a9d2-bb183e0d43dd	TST33F5	LSE	GBP	MINOR	t	2026-03-11 10:53:45.398943+00
5037bbb2-ca6a-4147-8344-45a4a2a2725e	99d5e89c-dee1-44fa-bbe0-95b7235931cb	TST883C	LSE	GBP	MINOR	t	2026-03-11 10:53:45.424978+00
a8d85a07-f8a0-414f-83a1-0f331c18dd79	76c80c32-e5db-4665-bc05-2006544bd8ef	TSTAC2F	LSE	GBP	MINOR	t	2026-03-11 19:09:48.784624+00
ad71824d-f037-41b7-a0d1-4982d098efdb	589edd05-633b-49b6-9a63-112870c8bc21	TST19FB	LSE	GBP	MINOR	t	2026-03-11 19:09:48.812817+00
20888b63-80dd-457b-9839-612b2bdf0941	93d07120-90f9-4430-892f-5ceee5a6f7ec	TSTBCCD	LSE	GBP	MINOR	t	2026-03-11 10:53:45.868531+00
4e29d977-39af-44cd-b533-dac0b92d70c4	5ae9400b-efa7-4a2c-9a16-91de327399bd	TSTED0F	LSE	GBP	MINOR	t	2026-03-11 19:09:49.046708+00
c1f931e3-af3c-424e-812b-98f01a5e2838	23c16662-4b72-47ad-a641-3b8d4b11bd2d	TSTAFD2	LSE	GBP	MINOR	t	2026-03-11 19:09:49.086486+00
ab776410-be94-432c-be51-a6a771ba4b43	2d5379fc-7d8b-4e21-b136-1cd1ff591256	TST8EA3	LSE	GBP	MINOR	t	2026-03-11 19:09:49.136464+00
05e5a45e-d599-4bb8-80a9-66f07244532d	dff747d9-6aaf-420d-868e-ce5f19e5a8f0	TSTCAC2	LSE	GBP	MINOR	t	2026-03-11 19:09:49.156549+00
006db63e-62b0-462e-8d59-e75e1b7bacbb	1cb13037-7463-45e5-b5c8-4719bec699ab	TST7310	LSE	GBP	MINOR	t	2026-03-11 19:09:49.183192+00
b7afe429-366b-4867-bf1d-27db61e75a5e	0ae17620-9615-4c26-a7de-be25ae15b82e	TSTAB06	LSE	GBP	MINOR	t	2026-03-11 19:17:00.29873+00
c4a7f2e2-ec50-4e5f-8979-cb68132d7c40	e7697674-0f8a-40e6-bb6a-cc648ee48f0f	TST1464	LSE	GBP	MINOR	t	2026-03-11 19:17:48.251355+00
86b1126a-dee0-4462-a36e-36a189b0ebe8	328b07d3-97ee-44a8-aefa-e8f3f7ef665c	TSTD316	LSE	GBP	MINOR	t	2026-03-11 19:17:48.328242+00
d2e70ea0-a318-4841-b0bd-09d031c299c4	ea8c3f81-d5ce-4549-b667-c81eb388e522	TST8973	LSE	GBP	MINOR	t	2026-03-11 19:17:48.364145+00
a06d5744-bc1c-45d4-b0aa-40b6d418ae24	bcda43bd-1780-4015-b877-d04db9c9230f	TST7A67	LSE	GBP	MINOR	t	2026-03-11 19:17:48.394302+00
00134054-20cc-4d4c-adb1-5ef072edd566	1451f908-b187-4768-bcb3-1bb4a92b0001	TST9FFF	LSE	GBP	MINOR	t	2026-03-11 19:17:48.442351+00
c7873b37-3f77-4dae-b6fc-957142bfe184	cc45f751-fe65-4339-af94-880a6bcd189b	TST932E	LSE	GBP	MINOR	t	2026-03-11 19:17:48.482192+00
4553346d-9a15-47c4-8b16-8acb63d626eb	729b1826-2ae3-4515-953d-436a91d9b7ff	TST23FF	LSE	GBP	MINOR	t	2026-03-11 19:17:48.507194+00
a19cf7bc-0558-4461-a267-b6fee1a26365	06be3c1b-14dd-4439-8d14-9cc2ec0cb15f	TST7DFC	LSE	GBP	MINOR	t	2026-03-11 19:17:48.536237+00
0ae33f3b-3935-4718-80d3-102afea2950f	8322abee-aabd-4dbe-8090-f2d93e54b8c8	TST9C07	LSE	GBP	MINOR	t	2026-03-11 19:17:48.564288+00
9ed0f8bd-f6dd-479e-b00a-4775a4b7832c	f9aa210a-c11e-441a-a43e-a9a53bac575c	TST0AFB	LSE	GBP	MINOR	t	2026-03-11 19:17:48.596179+00
b6f17b59-241b-4b6f-9bb5-7319310a0649	329a43f2-27c3-418a-8c4f-9e1e0803b6d6	TST9CE1	LSE	GBP	MINOR	t	2026-03-11 19:17:48.630236+00
96716145-31b5-4fda-a73a-6f0cd6368c74	85a48f7d-3c03-44f1-b151-d573f50b5633	TST94A4	LSE	GBP	MINOR	t	2026-03-11 19:17:55.88419+00
1e9fe3b5-c5f3-45c1-bc7f-325b2f653b9d	b20d9b40-7e90-4e23-94ab-922aa8068a90	TST4325	LSE	GBP	MINOR	t	2026-03-11 19:17:55.912601+00
d9cc5049-e2d5-45c6-9814-d914745fde4e	c3a1f36b-ee14-48f6-93f3-7cb57693945f	TST4833	LSE	GBP	MINOR	t	2026-03-11 19:17:56.178324+00
367dd67e-d09b-43e7-b8fd-1a12d511eb99	e3f52eba-d3d5-415c-8d4a-99f849dddc4b	TST1D3A	LSE	GBP	MINOR	t	2026-03-11 19:17:56.210356+00
e71e4cb1-19ca-4bcd-9fe2-dfe30620d927	5157bd6f-ebef-45a3-bcb6-4a71d92b1eab	TSTE8E3	LSE	GBP	MINOR	t	2026-03-11 19:17:56.272517+00
6f112061-1c1e-48be-8eed-339f20b2dd84	eb919e5a-01ad-4ad3-b3c8-303bea7864eb	TST4BB1	LSE	GBP	MINOR	t	2026-03-11 19:17:56.302461+00
c25c7532-d987-4b00-9330-16d0e3bd0d63	d8a739e0-edb8-4e12-b482-be448ff497a5	TST3BC0	LSE	GBP	MINOR	t	2026-03-11 19:17:56.334367+00
9b93e41a-88ca-49c4-9382-808f327eb605	5df0ff50-f84e-4f7e-aeac-20fe3610e537	TSTA9BB	LSE	GBP	MINOR	t	2026-03-11 19:17:56.360327+00
aec7239d-f20a-4eca-9c77-fa4ec1184c3d	381b41a1-1913-4730-a4e7-2e3c96bdd79a	TST33AB	LSE	GBP	MINOR	t	2026-03-11 19:17:56.408585+00
005274d7-7dfc-422b-bc07-be64beca35cc	11cc4c74-1d98-4ce4-a823-6cefa9fa9632	TST0DD4	LSE	GBP	MINOR	t	2026-03-11 19:17:56.444204+00
fc7cd6eb-a2b5-4ded-9c1e-ebae590f8159	538286db-bcf6-40e0-9ada-497c471f1ce2	TST77BD	LSE	GBP	MINOR	t	2026-03-11 19:17:56.49046+00
48480b7a-d4b7-4105-aeea-1adb045fda27	a87b5503-f063-44e6-8d09-d61f2f81b1a0	TST9A63	LSE	GBP	MINOR	t	2026-03-11 19:17:56.540293+00
c3ad6f84-41b6-4f42-9b38-b60c7685a840	1aae73cf-2875-4c01-8523-f0f6e117a7b1	TSTD4F0	LSE	GBP	MINOR	t	2026-03-11 19:17:56.580465+00
e27a37b0-0800-48ae-b5e8-e49bc0647c37	d9b6aa74-67c3-4a86-ae92-599c231fdc5d	TST236A	LSE	GBP	MINOR	t	2026-03-11 19:17:56.60818+00
f0487728-4884-47f6-ac0d-20a48addb1c7	b8d85ae0-8b09-42c9-82f8-a2344e17687f	TST63C4	LSE	GBP	MINOR	t	2026-03-11 19:17:56.634585+00
1250ffcd-241e-43b5-ac73-84b7c238561f	dd2ff887-6331-4ae7-a14f-2434cf3ac246	TSTE9AE	LSE	GBP	MINOR	t	2026-03-11 19:17:56.672578+00
9e41de7e-17c9-4cd6-9029-be58779811d1	26327a2e-4e70-4af1-a36f-aca8371df82b	TSTA4D4	LSE	GBP	MINOR	t	2026-03-11 19:17:56.708505+00
d93da6f3-3331-45de-86ae-1f7dfc26fe9d	05c7d60d-d4e4-42b3-8b7c-457930c58571	TST8057	LSE	GBP	MINOR	t	2026-03-11 19:17:56.750485+00
0c671591-f725-4986-97d1-56cdd6af5241	944070a5-488e-48c1-a6a7-7468c6819ba0	TST5B1F	LSE	GBP	MINOR	t	2026-03-11 19:17:57.100558+00
\.


--
-- TOC entry 3695 (class 0 OID 26390)
-- Dependencies: 237
-- Data for Name: notification_configs; Type: TABLE DATA; Schema: public; Owner: ta_app
--

COPY public.notification_configs (notification_config_id, portfolio_id, apprise_url, is_active, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3683 (class 0 OID 18430)
-- Dependencies: 225
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: ta_app
--

COPY public.notifications (notification_id, owner_user_id, severity, title, body, created_at, read_at, meta) FROM stdin;
6900ba2b-975e-4a0c-9bde-4134c70d4425	05c894d8-502e-4e36-be45-fee805b83e9a	CRITICAL	Portfolio Frozen: Currency Mismatch: ISFA	Provider reported currency 'USD' but listing 'ISFA' trades in 'GBP'.	2026-03-11 09:56:16.7233+00	\N	{"run_id": "c0f1461a-7cf8-4f66-b735-c7f93702c323", "alert_id": "8ecce376-a9a9-4425-8b40-20583c993c10", "rule_code": "DQ_CCY_MISMATCH", "portfolio_id": "11443291-4e86-4a9c-9ea4-c9f7040ae16e"}
\.


--
-- TOC entry 3681 (class 0 OID 18404)
-- Dependencies: 223
-- Data for Name: portfolio; Type: TABLE DATA; Schema: public; Owner: ta_app
--

COPY public.portfolio (portfolio_id, owner_user_id, name, broker, base_currency, tax_treatment, is_enabled, created_at) FROM stdin;
a9136ac7-2cd4-43db-be99-f4fb545b5ec1	501270c9-28bd-47e5-aaad-329f27096366	Test	IB	GBP	UK_RESIDENT	t	2026-02-28 00:42:35.72371+00
ab138600-660c-45e9-b493-e77304994189	d0e75dfe-af89-45e2-bd7c-68aa041f4e30	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 12:25:32.369549+00
236a92b2-c836-4d1f-9de0-db72ebfb4060	01762b64-dd4a-448f-8305-e41c8c882947	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 12:25:32.43444+00
bc0599c2-8237-4c77-a790-25ae1a82d167	4b13ca50-31ae-484c-bc16-3eb9c02262d4	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 12:25:32.492433+00
7cac4b10-da63-4987-bfb4-97096834da03	c36e2855-ad1b-4e43-b5e6-ffec0a6daf3d	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 12:25:32.518431+00
ce01de34-afad-4263-927a-242136e9c35c	d982c71c-2a08-4855-a309-1157db359c67	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 12:25:32.568547+00
ea02c07f-f850-4338-8443-5e1a294fef63	2beaeb07-e3ff-4dcd-b93a-f67e5b9e4add	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 12:25:45.494176+00
84ae3a73-9fb5-4ef7-b7fd-8cf42a4b784a	c9d85c7f-d8e1-42ec-a7cf-1736eea278f3	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 12:25:45.551631+00
ec44019e-fb66-4dbe-a9c6-cc0a98904723	435adf4b-defe-4dd1-9be6-7169282c53a4	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 12:25:45.615715+00
543893c3-b8b5-4cc9-9c94-20cbcb019cb6	997a016a-b28b-4cbb-a992-5039a61f5f8c	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 12:25:45.64365+00
5ad7b426-a154-4154-bdf2-0f7b8dcb6aad	8b9ad148-a867-44ef-b41f-708d8cd35bae	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 12:25:45.675754+00
f66550c0-77db-4a8e-99ea-531219da8660	8a813388-0c62-4f17-aa1c-3b602e70092b	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 12:27:45.843312+00
5cab396c-3c49-426b-8f4a-71e04f26e8c8	3b7976b0-d52c-4cd3-8b98-e5d1ed0e94ea	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 12:27:45.888905+00
259792b1-c894-403a-b988-06ca5af3c2c5	fbc1e175-c1bc-40f4-bba6-71f9e99a3ebd	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 12:27:45.942724+00
a03981eb-5cc2-4483-85c4-c2b284a6dfae	9bd76d1b-3e07-4a2f-b936-b79861f5ba91	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 12:27:45.966822+00
6a0db12e-51d9-45b7-8905-77059fd448db	145ec58c-de7d-40f1-bcbc-b6060dc18040	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 12:27:45.992698+00
a05c52ad-02fe-49c9-aae3-326eab43299a	dd9c30f1-b6ad-4a0f-b8f3-8a0719abf03e	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 12:43:01.959541+00
4ec95e47-148d-4e8a-853c-a6fab32f873c	d65382bc-34fd-479b-b047-14bc22ae7335	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 12:43:02.012547+00
335990e2-b794-4049-b8b1-80b917284039	e9d70044-c427-4ef4-82a4-e721b416f78d	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 12:43:02.080842+00
527ba4f9-7b40-4ab0-8629-9d5fc7b341f0	45b4d902-920f-4a91-9744-7f2e1beb5252	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 12:43:02.110772+00
b7ff47bd-d423-46bd-833e-3ccfd03e6069	4247a152-86cc-4a78-a175-2e2f06030fdb	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 12:43:02.144556+00
f562d51c-79bd-4e05-ae8c-7478b494d740	10200d2b-8409-4d84-8a84-c1a4aafdfa39	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 13:21:30.081995+00
8f28a33d-94b8-43d8-bc95-26167611cda8	ebd906ba-147e-49c2-87fb-3b1b0a2e1bc4	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 13:21:30.133632+00
53680ec9-db2d-462a-b930-a8e2d9f30dfc	f2da46a6-3b53-4840-8d7a-ae1412b69ac3	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 13:21:30.187576+00
f80e196d-6218-4f8c-a211-894e298418af	f547834e-70cd-4fad-a15a-55ce979266ae	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 13:21:30.211598+00
a023d249-926d-476e-8538-9d7a59f0cf97	fe586e05-d38d-42d9-8df7-7cecb92e167d	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 13:21:30.239514+00
0dbb642d-ce67-4752-b6e3-6242d8c69d72	05c894d8-502e-4e36-be45-fee805b83e9a	SIPP	AJBell	GBP	SIPP	t	2026-03-09 17:10:32.359321+00
11443291-4e86-4a9c-9ea4-c9f7040ae16e	05c894d8-502e-4e36-be45-fee805b83e9a	Phase2 Smoke Test Portfolio 1773080990	Test Broker	GBP	ISA	t	2026-03-09 18:29:50.914685+00
bfd7a816-4df3-4f8f-a74a-33a3b2882170	05c894d8-502e-4e36-be45-fee805b83e9a	Phase2 Smoke Test Portfolio 1773082136_73082132	Test Broker	GBP	ISA	t	2026-03-09 18:48:56.433166+00
da0c605a-aed7-4228-800b-43184fd12d6f	05c894d8-502e-4e36-be45-fee805b83e9a	Phase2 Smoke Test Portfolio 1773082203_73082132	Test Broker	GBP	ISA	t	2026-03-09 18:50:03.515089+00
49f8a40e-9511-410f-8a25-61bf7e8c52e4	05c894d8-502e-4e36-be45-fee805b83e9a	Phase2 Smoke Test Portfolio 1773083475_10009854	Test Broker	GBP	ISA	t	2026-03-09 19:11:15.494081+00
3d86658c-3e03-4a9a-887a-257df689b7ce	05c894d8-502e-4e36-be45-fee805b83e9a	Phase2 Smoke Test Portfolio 1773083494_10025790	Test Broker	GBP	ISA	t	2026-03-09 19:11:34.572017+00
680276db-f023-4080-acf5-280a2b813a0b	05c894d8-502e-4e36-be45-fee805b83e9a	Phase2 Smoke Test Portfolio 1773084531_10008718	Test Broker	GBP	ISA	t	2026-03-09 19:28:51.418669+00
e500f71b-1c0d-4430-b112-5508c24e8503	05c894d8-502e-4e36-be45-fee805b83e9a	Phase2 Smoke Test Portfolio 1773084566_10022190	Test Broker	GBP	ISA	t	2026-03-09 19:29:26.854392+00
4f9b4ee9-95b3-429c-b7a4-c08e62a93e2f	05c894d8-502e-4e36-be45-fee805b83e9a	Phase2 Smoke Test Portfolio 1773085396_10020244	Test Broker	GBP	ISA	t	2026-03-09 19:43:16.639791+00
82dfd269-ecff-436c-8d56-d45ad59fcf94	05c894d8-502e-4e36-be45-fee805b83e9a	Phase2 Smoke Test Portfolio 1773085666_10032499	Test Broker	GBP	ISA	t	2026-03-09 19:47:46.543082+00
7acd1500-bb55-4838-b462-772edce6eadf	05c894d8-502e-4e36-be45-fee805b83e9a	Phase2 Smoke Test Portfolio 1773085738_10001083	Test Broker	GBP	ISA	t	2026-03-09 19:48:58.976005+00
31dd31f5-a304-49dc-828d-c21c812a0f9c	05c894d8-502e-4e36-be45-fee805b83e9a	Phase2 Smoke Test Portfolio 1773086222_10009407	Test Broker	GBP	ISA	t	2026-03-09 19:57:02.744211+00
c2fff561-da19-4164-b97e-18d66cf1ab3f	05c894d8-502e-4e36-be45-fee805b83e9a	Phase2 Smoke Test Portfolio 1773096004_10000733	Test Broker	GBP	ISA	t	2026-03-09 22:40:04.407515+00
e675105a-f954-4553-b993-fb77527d620f	05c894d8-502e-4e36-be45-fee805b83e9a	Phase2 Smoke Test Portfolio 1773096710_10010360	Test Broker	GBP	ISA	t	2026-03-09 22:51:50.781041+00
e5fa701e-6756-4a03-ac4f-052407357964	05c894d8-502e-4e36-be45-fee805b83e9a	Phase2 Smoke Test Portfolio 1773096813_10018103	Test Broker	GBP	ISA	t	2026-03-09 22:53:33.880426+00
6d0579fe-3d73-484b-843c-ec30733e270c	a8b5dcc3-6178-4868-aa31-bebb613140e2	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 18:53:38.07912+00
0332f290-ab02-4ed8-beac-30292d85c959	e7823a62-30c3-4632-a063-11c534d11d67	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 18:53:38.116696+00
7aab19f6-ce72-493b-9f44-8b35338401e8	fe25ddf8-7970-424f-bdd0-eb1d05149f85	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 18:53:38.170861+00
484bb1bf-e98d-4d59-9591-dd236d9acf79	bde794f6-c3c2-438c-9a5c-0c002f6cf3ae	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 18:53:38.196671+00
0953691a-0c74-4f2c-bd2d-c7123d2d847a	682531d6-b925-4292-9f54-6cc5badac794	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 18:53:38.226737+00
57d17ec3-dff1-4566-98fe-66870d390834	e1c31a56-6764-401a-a41a-edde0987838c	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 19:09:49.048555+00
03dc8184-7957-4423-a49f-d597b6060511	c1b4c536-21f6-4656-8b8c-5b4a6632f17e	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 19:09:49.08843+00
cf3465de-eb7d-4a8e-a6b5-6588919bb632	3368d156-fe11-4a27-becb-654d13a1ccbb	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 19:09:49.138417+00
5c2367af-893f-473d-8a09-3cddac469689	08ac6bdc-41d7-47a6-8d52-029a5784e44a	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 19:09:49.15862+00
ee2c0dd8-ead5-42ed-9e7e-5a2bb38ce91e	13233645-cc3b-4775-a084-531a085eda91	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 19:09:49.186706+00
79571e3e-7fb1-4462-8f78-f4994182be58	b3f19468-c33c-4123-83ed-fc388d61d7a6	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 19:17:00.302696+00
5bb022ad-ced5-438c-8eac-9c306fbdf77c	aa4e1960-7d43-46b6-ae8d-b184cdb470bd	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 19:17:48.2555+00
b87f27e6-b395-4604-b8f3-8c7967ef2583	286a21d8-bda0-45dc-aaf1-40da26b918e4	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 19:17:48.330413+00
f215e7c6-9ca2-477d-8576-103a9dbdbb5b	0842f730-0598-4271-93d5-6766297f29b1	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 19:17:48.366107+00
aed673d6-c6d4-4d43-a8e2-b07340d8ad41	1420911d-1722-4d2f-a969-6343dbfb6d1a	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 19:17:48.396367+00
fbbd734d-8613-4c2d-902c-40826950aa55	bb694a18-6764-46e4-9179-5e4abed2e56c	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 19:17:48.444238+00
9e4d07a1-d275-4fa6-b499-85dc02627033	4ce26850-3328-4740-bf90-af1ab619843a	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 19:17:48.484085+00
7fb0b5ce-109d-4337-92a8-2195afef1bff	26f38a7d-33c8-4aa7-b67e-8c3cc0a73d34	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 19:17:48.510111+00
9b4870ec-6f2d-4d93-9a3e-dc5d730b7327	617d97e3-47de-4f17-a9b4-36a0c79cb98f	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 19:17:48.538102+00
c7966280-fb24-4816-ac89-8f57d94252ae	2d5b130b-0af0-4add-a686-030d576ca9d2	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 19:17:48.566106+00
0af60105-8d65-46ba-9e1b-0a432690ed3b	15589ed0-c73f-476a-9e00-d383b1e29033	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 19:17:48.598105+00
91797da6-97ee-4762-a110-772aedf0f225	74883a77-453c-47db-bbb9-ead741b63dad	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 19:17:48.632091+00
c8dd35af-2322-480c-ad23-1218b017b6c4	947892d1-2fa4-45a6-92ca-f3c6202434ae	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 19:17:56.180136+00
41694260-5bc3-4c21-a896-2f8c05a5061c	5f2e082d-713d-4bd8-8cf3-233cb981b87d	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 19:17:56.212244+00
65a5083e-27e1-4213-b6fc-b956991d4aa8	0ba79a21-fded-4124-8d03-2da6f294590b	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 19:17:56.274364+00
7badea17-cfb5-4fb5-a613-333c7f79b06c	3f96613f-61c5-4d15-b756-932765288c88	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 19:17:56.304332+00
c712bacf-99af-4ace-ace5-3659b98f6ade	940f7d38-5414-46af-9cfd-9a7e78b43795	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 19:17:56.336228+00
442751d4-2ed9-4874-a474-4ca686ce88c5	18f8a6d4-7795-4380-9ebf-6ba112d8f799	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 19:17:56.36214+00
4176c31c-6f31-4f4b-b9d9-273a24ed87d4	d35f101b-7748-4535-b571-43a0e0e274d1	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 19:17:56.410215+00
ac3876c8-859f-4cbd-aebf-59248d4e9e42	3cca1d39-faa3-4a3d-9a6a-25302a708b28	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 19:17:56.4462+00
5643df5b-1190-410a-8613-fe281ed78219	319b1561-136d-4601-a951-26d74f7a14ac	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 19:17:56.492373+00
48eb442a-9521-4d87-a013-fae87f350831	ea2b69fc-f81a-4a08-bef2-943e826a5b81	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 19:17:56.542223+00
a7f50004-2806-4dcd-abdd-92f7b3f3b0a4	b966bdd3-4afb-4b49-96d8-1d380c788597	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 19:17:56.582332+00
1672e066-3d21-42a3-aa25-9e55e83afd53	90060e1e-dd0b-4800-b269-6443db2fcc4a	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 19:17:56.610226+00
61af205c-fd68-4a54-8115-7c8cf5346c22	4bfbb8a0-d061-4c0d-88d3-965a3075226f	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 19:17:56.636516+00
f7239388-dbeb-4814-a3d8-266a389f9684	4c88a3a8-6115-4cb5-a7f2-ea357fc60567	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 19:17:56.674388+00
0ea34e7a-7f36-4075-bc18-6d57a70dd200	b9cd736b-7715-41a1-8627-9cd7a458c6cf	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 19:17:56.710525+00
ad7e990c-4832-498b-a1c8-ce99cc20c609	e4050dcc-060b-4ef8-aa5e-e3f1c6a976b7	Test Portfolio	Test Broker	GBP	ISA	t	2026-03-11 19:17:56.752334+00
\.


--
-- TOC entry 3684 (class 0 OID 18443)
-- Dependencies: 226
-- Data for Name: portfolio_constituent; Type: TABLE DATA; Schema: public; Owner: ta_app
--

COPY public.portfolio_constituent (portfolio_id, listing_id, sleeve_code, is_monitored, created_at) FROM stdin;
79571e3e-7fb1-4462-8f78-f4994182be58	b7afe429-366b-4867-bf1d-27db61e75a5e	CORE	t	2026-03-11 19:17:00.306774+00
5bb022ad-ced5-438c-8eac-9c306fbdf77c	c4a7f2e2-ec50-4e5f-8979-cb68132d7c40	CORE	t	2026-03-11 19:17:48.26101+00
b87f27e6-b395-4604-b8f3-8c7967ef2583	86b1126a-dee0-4462-a36e-36a189b0ebe8	CORE	t	2026-03-11 19:17:48.332319+00
f215e7c6-9ca2-477d-8576-103a9dbdbb5b	d2e70ea0-a318-4841-b0bd-09d031c299c4	CORE	t	2026-03-11 19:17:48.368101+00
aed673d6-c6d4-4d43-a8e2-b07340d8ad41	a06d5744-bc1c-45d4-b0aa-40b6d418ae24	CORE	t	2026-03-11 19:17:48.400452+00
fbbd734d-8613-4c2d-902c-40826950aa55	00134054-20cc-4d4c-adb1-5ef072edd566	CORE	t	2026-03-11 19:17:48.448369+00
ab138600-660c-45e9-b493-e77304994189	1c918015-04cd-4bd4-aa2f-4480a02e6947	CORE	t	2026-03-11 12:25:32.375332+00
236a92b2-c836-4d1f-9de0-db72ebfb4060	bb678d70-3ece-4993-a5b6-e8e46fb8839f	CORE	t	2026-03-11 12:25:32.438408+00
9e4d07a1-d275-4fa6-b499-85dc02627033	c7873b37-3f77-4dae-b6fc-957142bfe184	CORE	t	2026-03-11 19:17:48.486297+00
bc0599c2-8237-4c77-a790-25ae1a82d167	3539aef7-0437-4e3f-b37f-80dda26cc9d7	CORE	t	2026-03-11 12:25:32.494426+00
7cac4b10-da63-4987-bfb4-97096834da03	a7842a56-dc37-454c-9c3a-107952ee261c	CORE	t	2026-03-11 12:25:32.522435+00
ce01de34-afad-4263-927a-242136e9c35c	f6cd2b7c-2f02-43ac-9b94-9e6749f9c4fc	CORE	t	2026-03-11 12:25:32.572635+00
ea02c07f-f850-4338-8443-5e1a294fef63	596b1610-f65a-415e-8656-2c5a352ff2ad	CORE	t	2026-03-11 12:25:45.498353+00
84ae3a73-9fb5-4ef7-b7fd-8cf42a4b784a	d9dd3f6e-ce4d-4a18-b8ca-a822969dc063	CORE	t	2026-03-11 12:25:45.555653+00
7fb0b5ce-109d-4337-92a8-2195afef1bff	4553346d-9a15-47c4-8b16-8acb63d626eb	CORE	t	2026-03-11 19:17:48.51216+00
ec44019e-fb66-4dbe-a9c6-cc0a98904723	dcff1c03-4fc0-4559-b200-6c605e1d1c92	CORE	t	2026-03-11 12:25:45.619777+00
543893c3-b8b5-4cc9-9c94-20cbcb019cb6	5d90d841-aef2-42b7-ad7c-5bad03ab7ea6	CORE	t	2026-03-11 12:25:45.645908+00
5ad7b426-a154-4154-bdf2-0f7b8dcb6aad	899de085-b827-439f-bfa1-c3636ee086c3	CORE	t	2026-03-11 12:25:45.680169+00
f66550c0-77db-4a8e-99ea-531219da8660	36af5a06-bc52-43fb-9ee4-6a4450a185a9	CORE	t	2026-03-11 12:27:45.847642+00
5cab396c-3c49-426b-8f4a-71e04f26e8c8	c2897d7d-1236-4406-9fbc-77aaf21561f5	CORE	t	2026-03-11 12:27:45.892914+00
9b4870ec-6f2d-4d93-9a3e-dc5d730b7327	a19cf7bc-0558-4461-a267-b6fee1a26365	CORE	t	2026-03-11 19:17:48.540127+00
259792b1-c894-403a-b988-06ca5af3c2c5	6902ae71-dfb5-4e25-be73-a15222bd6f14	CORE	t	2026-03-11 12:27:45.944817+00
a03981eb-5cc2-4483-85c4-c2b284a6dfae	25b9cd05-6def-48ce-9a48-6e585cc2d740	CORE	t	2026-03-11 12:27:45.968836+00
6a0db12e-51d9-45b7-8905-77059fd448db	4b2f562a-7984-4295-925d-80542e676925	CORE	t	2026-03-11 12:27:45.994728+00
a05c52ad-02fe-49c9-aae3-326eab43299a	48ac994e-6fee-43c7-b2b0-0bab8a296bb9	CORE	t	2026-03-11 12:43:01.965678+00
4ec95e47-148d-4e8a-853c-a6fab32f873c	68ef3f7c-c933-4c3c-8d10-04335cce4fdb	CORE	t	2026-03-11 12:43:02.016528+00
c7966280-fb24-4816-ac89-8f57d94252ae	0ae33f3b-3935-4718-80d3-102afea2950f	CORE	t	2026-03-11 19:17:48.568058+00
335990e2-b794-4049-b8b1-80b917284039	ce39ec61-2d85-4aae-b695-25c17093590b	CORE	t	2026-03-11 12:43:02.083214+00
527ba4f9-7b40-4ab0-8629-9d5fc7b341f0	a3756424-5fb7-4449-b3e0-5562f8bc8156	CORE	t	2026-03-11 12:43:02.11343+00
b7ff47bd-d423-46bd-833e-3ccfd03e6069	45460de0-0548-4f73-a70b-86c8f617b821	CORE	t	2026-03-11 12:43:02.146558+00
f562d51c-79bd-4e05-ae8c-7478b494d740	3c9b012a-34c2-4951-9438-7b93a32ecfc0	CORE	t	2026-03-11 13:21:30.086074+00
8f28a33d-94b8-43d8-bc95-26167611cda8	76e9c2df-0e54-4093-80dd-36a4de93cc4e	CORE	t	2026-03-11 13:21:30.135809+00
0af60105-8d65-46ba-9e1b-0a432690ed3b	9ed0f8bd-f6dd-479e-b00a-4775a4b7832c	CORE	t	2026-03-11 19:17:48.600013+00
53680ec9-db2d-462a-b930-a8e2d9f30dfc	98475941-6ee0-404e-ba86-31a20ed1d91c	CORE	t	2026-03-11 13:21:30.189576+00
f80e196d-6218-4f8c-a211-894e298418af	497f93df-ca41-4977-8417-eee7e47ce21d	CORE	t	2026-03-11 13:21:30.213629+00
a023d249-926d-476e-8538-9d7a59f0cf97	ec93526b-d2dd-4c0b-ae46-9e4cf14a2163	CORE	t	2026-03-11 13:21:30.241571+00
91797da6-97ee-4762-a110-772aedf0f225	b6f17b59-241b-4b6f-9bb5-7319310a0649	CORE	t	2026-03-11 19:17:48.634019+00
11443291-4e86-4a9c-9ea4-c9f7040ae16e	88535377-562e-4c57-86af-3113c6acf175	CORE	t	2026-03-09 18:29:50.93351+00
bfd7a816-4df3-4f8f-a74a-33a3b2882170	3f68fc52-2b2a-450d-a9f1-35953182f0bf	CORE	t	2026-03-09 18:48:56.448141+00
da0c605a-aed7-4228-800b-43184fd12d6f	c45ba9ad-d86c-4c03-af24-2f7a3d2838af	CORE	t	2026-03-09 18:50:03.530573+00
49f8a40e-9511-410f-8a25-61bf7e8c52e4	866c545a-69e7-496b-b8a1-ebe684435d7e	CORE	t	2026-03-09 19:11:15.50817+00
3d86658c-3e03-4a9a-887a-257df689b7ce	3478c924-17e9-4ee6-b279-0a52e6c240e3	CORE	t	2026-03-09 19:11:34.590025+00
680276db-f023-4080-acf5-280a2b813a0b	d5e2cbdb-80fa-4c69-be09-0890e0922436	CORE	t	2026-03-09 19:28:51.43567+00
e500f71b-1c0d-4430-b112-5508c24e8503	d4d321dd-4a54-49bf-856e-974153886506	CORE	t	2026-03-09 19:29:26.870874+00
4f9b4ee9-95b3-429c-b7a4-c08e62a93e2f	c28427b9-8315-4ede-8827-ee3cf6796fac	CORE	t	2026-03-09 19:43:16.658555+00
82dfd269-ecff-436c-8d56-d45ad59fcf94	1f7ef26a-acbf-4164-b0c3-ce0c28439dfe	CORE	t	2026-03-09 19:47:46.558323+00
7acd1500-bb55-4838-b462-772edce6eadf	4fbbf0de-6b55-476e-b8cf-15e2e67525dd	CORE	t	2026-03-09 19:48:58.995398+00
31dd31f5-a304-49dc-828d-c21c812a0f9c	c3927a82-1029-4cdc-a114-50f0f298f57d	CORE	t	2026-03-09 19:57:02.760217+00
c2fff561-da19-4164-b97e-18d66cf1ab3f	1f4880c2-cdb8-4068-8f3d-0df11f4e07ed	CORE	t	2026-03-09 22:40:04.423046+00
e675105a-f954-4553-b993-fb77527d620f	ce1530ec-4916-4b5d-9530-ef47e0bf8b8d	CORE	t	2026-03-09 22:51:50.795727+00
e5fa701e-6756-4a03-ac4f-052407357964	a9fb309f-bb1e-41c1-a9c9-808807038195	CORE	t	2026-03-09 22:53:33.895575+00
0dbb642d-ce67-4752-b6e3-6242d8c69d72	8f574494-d8c0-4ce7-979a-1c058718e609	CORE	t	2026-03-11 17:50:02.008947+00
0dbb642d-ce67-4752-b6e3-6242d8c69d72	d18e6625-f801-4b20-b29a-531c5a54015f	CORE	t	2026-03-11 17:50:02.008947+00
0dbb642d-ce67-4752-b6e3-6242d8c69d72	1bc182b8-7410-4026-9d64-c628a13c4836	CORE	t	2026-03-11 17:50:02.008947+00
c8dd35af-2322-480c-ad23-1218b017b6c4	d9cc5049-e2d5-45c6-9814-d914745fde4e	CORE	t	2026-03-11 19:17:56.182162+00
41694260-5bc3-4c21-a896-2f8c05a5061c	367dd67e-d09b-43e7-b8fd-1a12d511eb99	CORE	t	2026-03-11 19:17:56.216277+00
65a5083e-27e1-4213-b6fc-b956991d4aa8	e71e4cb1-19ca-4bcd-9fe2-dfe30620d927	CORE	t	2026-03-11 19:17:56.27828+00
7badea17-cfb5-4fb5-a613-333c7f79b06c	6f112061-1c1e-48be-8eed-339f20b2dd84	CORE	t	2026-03-11 19:17:56.308424+00
c712bacf-99af-4ace-ace5-3659b98f6ade	c25c7532-d987-4b00-9330-16d0e3bd0d63	CORE	t	2026-03-11 19:17:56.33833+00
6d0579fe-3d73-484b-843c-ec30733e270c	862a38b7-806e-4386-b73e-ea7dcd228863	CORE	t	2026-03-11 18:53:38.083119+00
0332f290-ab02-4ed8-beac-30292d85c959	9021c8ed-7543-43c5-b6ac-d59ad36ac5ae	CORE	t	2026-03-11 18:53:38.118658+00
442751d4-2ed9-4874-a474-4ca686ce88c5	9b93e41a-88ca-49c4-9382-808f327eb605	CORE	t	2026-03-11 19:17:56.364248+00
7aab19f6-ce72-493b-9f44-8b35338401e8	5395a9dd-5279-4648-aba4-f95eb0d8fd4f	CORE	t	2026-03-11 18:53:38.174829+00
484bb1bf-e98d-4d59-9591-dd236d9acf79	2a82dbfc-f5c1-45d5-9694-796df3892432	CORE	t	2026-03-11 18:53:38.199078+00
0953691a-0c74-4f2c-bd2d-c7123d2d847a	971d0982-1019-44c0-a32a-3e01b7333ca3	CORE	t	2026-03-11 18:53:38.228833+00
4176c31c-6f31-4f4b-b9d9-273a24ed87d4	aec7239d-f20a-4eca-9c77-fa4ec1184c3d	CORE	t	2026-03-11 19:17:56.412088+00
ac3876c8-859f-4cbd-aebf-59248d4e9e42	005274d7-7dfc-422b-bc07-be64beca35cc	CORE	t	2026-03-11 19:17:56.448642+00
5643df5b-1190-410a-8613-fe281ed78219	fc7cd6eb-a2b5-4ded-9c1e-ebae590f8159	CORE	t	2026-03-11 19:17:56.496466+00
48eb442a-9521-4d87-a013-fae87f350831	48480b7a-d4b7-4105-aeea-1adb045fda27	CORE	t	2026-03-11 19:17:56.544176+00
a7f50004-2806-4dcd-abdd-92f7b3f3b0a4	c3ad6f84-41b6-4f42-9b38-b60c7685a840	CORE	t	2026-03-11 19:17:56.586526+00
1672e066-3d21-42a3-aa25-9e55e83afd53	e27a37b0-0800-48ae-b5e8-e49bc0647c37	CORE	t	2026-03-11 19:17:56.612224+00
61af205c-fd68-4a54-8115-7c8cf5346c22	f0487728-4884-47f6-ac0d-20a48addb1c7	CORE	t	2026-03-11 19:17:56.640558+00
f7239388-dbeb-4814-a3d8-266a389f9684	1250ffcd-241e-43b5-ac73-84b7c238561f	CORE	t	2026-03-11 19:17:56.678404+00
0ea34e7a-7f36-4075-bc18-6d57a70dd200	9e41de7e-17c9-4cd6-9029-be58779811d1	CORE	t	2026-03-11 19:17:56.714416+00
ad7e990c-4832-498b-a1c8-ce99cc20c609	d93da6f3-3331-45de-86ae-1f7dfc26fe9d	CORE	t	2026-03-11 19:17:56.756615+00
57d17ec3-dff1-4566-98fe-66870d390834	4e29d977-39af-44cd-b533-dac0b92d70c4	CORE	t	2026-03-11 19:09:49.050813+00
03dc8184-7957-4423-a49f-d597b6060511	c1f931e3-af3c-424e-812b-98f01a5e2838	CORE	t	2026-03-11 19:09:49.090539+00
cf3465de-eb7d-4a8e-a6b5-6588919bb632	ab776410-be94-432c-be51-a6a771ba4b43	CORE	t	2026-03-11 19:09:49.140494+00
5c2367af-893f-473d-8a09-3cddac469689	05e5a45e-d599-4bb8-80a9-66f07244532d	CORE	t	2026-03-11 19:09:49.160431+00
ee2c0dd8-ead5-42ed-9e7e-5a2bb38ce91e	006db63e-62b0-462e-8d59-e75e1b7bacbb	CORE	t	2026-03-11 19:09:49.190614+00
\.


--
-- TOC entry 3694 (class 0 OID 26371)
-- Dependencies: 236
-- Data for Name: portfolio_policy_allocations; Type: TABLE DATA; Schema: public; Owner: ta_app
--

COPY public.portfolio_policy_allocations (portfolio_policy_allocation_id, portfolio_id, listing_id, ticker, sleeve_code, policy_role, target_weight_pct, priority_rank, policy_hash, created_at) FROM stdin;
3e093446-62aa-45b3-b275-86ef7cd29fa5	ab138600-660c-45e9-b493-e77304994189	1c918015-04cd-4bd4-aa2f-4480a02e6947	TSTD3B5	CORE	STRATEGIC	35.00000000	1	policy-bbf0659e	2026-03-11 12:25:32.399141+00
e66306f5-43f9-428b-8631-ab1ece30a35e	236a92b2-c836-4d1f-9de0-db72ebfb4060	bb678d70-3ece-4993-a5b6-e8e46fb8839f	TST9BFA	CORE	STRATEGIC	35.00000000	1	policy-56b30340	2026-03-11 12:25:32.44244+00
5a60afc7-a633-4e7d-8836-06919cfcf8c9	bc0599c2-8237-4c77-a790-25ae1a82d167	3539aef7-0437-4e3f-b37f-80dda26cc9d7	TST2563	CORE	STRATEGIC	35.00000000	1	policy-8c3b7e50	2026-03-11 12:25:32.497793+00
aa95388c-684a-48e4-b533-5985427c0da5	7cac4b10-da63-4987-bfb4-97096834da03	a7842a56-dc37-454c-9c3a-107952ee261c	TST5D9B	CORE	STRATEGIC	35.00000000	1	policy-77e989a7	2026-03-11 12:25:32.526056+00
2887ff49-e4f0-48a7-bf60-7f17f1d2c255	ce01de34-afad-4263-927a-242136e9c35c	f6cd2b7c-2f02-43ac-9b94-9e6749f9c4fc	TSTA99F	CORE	STRATEGIC	35.00000000	1	policy-6f51a1ef	2026-03-11 12:25:32.576946+00
f7c1a3ea-33bd-4554-89b7-a829e9ab0a00	ea02c07f-f850-4338-8443-5e1a294fef63	596b1610-f65a-415e-8656-2c5a352ff2ad	TSTAC00	CORE	STRATEGIC	35.00000000	1	policy-82f80f40	2026-03-11 12:25:45.506044+00
faef6972-e688-4c04-832e-0c3efda0f6d1	84ae3a73-9fb5-4ef7-b7fd-8cf42a4b784a	d9dd3f6e-ce4d-4a18-b8ca-a822969dc063	TST07D8	CORE	STRATEGIC	35.00000000	1	policy-9ee9989a	2026-03-11 12:25:45.559667+00
aa7f49a2-83be-479f-b0e6-479c2733817d	ec44019e-fb66-4dbe-a9c6-cc0a98904723	dcff1c03-4fc0-4559-b200-6c605e1d1c92	TST9B0F	CORE	STRATEGIC	35.00000000	1	policy-1b6365f6	2026-03-11 12:25:45.62357+00
b1e1ce8f-1f4f-4067-a2ec-69d439b96010	543893c3-b8b5-4cc9-9c94-20cbcb019cb6	5d90d841-aef2-42b7-ad7c-5bad03ab7ea6	TST5AB6	CORE	STRATEGIC	35.00000000	1	policy-e7bf1c09	2026-03-11 12:25:45.650189+00
8354ef38-41c3-4c56-82f7-9f1d005eb94b	5ad7b426-a154-4154-bdf2-0f7b8dcb6aad	899de085-b827-439f-bfa1-c3636ee086c3	TST9C85	CORE	STRATEGIC	35.00000000	1	policy-dbb9ab07	2026-03-11 12:25:45.686158+00
9ab67ecb-ec96-49c3-92db-380c01995b50	0dbb642d-ce67-4752-b6e3-6242d8c69d72	d18e6625-f801-4b20-b29a-531c5a54015f	VWRP	core	INVESTED_ASSET	35.00000000	1	manifesto_v1.0.0	2026-03-11 12:27:26.138398+00
80b4237b-7a9c-4098-b1ea-aa6ceb2bb674	0dbb642d-ce67-4752-b6e3-6242d8c69d72	59976aac-caa6-4e73-b57b-2483c47d5c56	SEMI	semis	INVESTED_ASSET	35.00000000	2	manifesto_v1.0.0	2026-03-11 12:27:26.138398+00
97064f5a-8874-4f2b-9fae-8a5ffaee2917	0dbb642d-ce67-4752-b6e3-6242d8c69d72	427a4690-316c-462d-add9-199e0c71de0d	XWES	energy	INVESTED_ASSET	10.00000000	3	manifesto_v1.0.0	2026-03-11 12:27:26.138398+00
2f135684-63c5-40ed-951e-372d0c35585d	0dbb642d-ce67-4752-b6e3-6242d8c69d72	1bc182b8-7410-4026-9d64-c628a13c4836	XWHS	healthcare	INVESTED_ASSET	10.00000000	4	manifesto_v1.0.0	2026-03-11 12:27:26.138398+00
f10ed806-caf5-4bc6-96a9-857d30c73bcd	0dbb642d-ce67-4752-b6e3-6242d8c69d72	8f574494-d8c0-4ce7-979a-1c058718e609	WLDS	small_cap	INVESTED_ASSET	5.00000000	5	manifesto_v1.0.0	2026-03-11 12:27:26.138398+00
444660c0-2c31-44dd-aee6-cab1fd48f31e	0dbb642d-ce67-4752-b6e3-6242d8c69d72	44c9f233-ded8-44e5-8dda-f467827fe671	IGL5	short_gilts	INVESTED_ASSET	5.00000000	6	manifesto_v1.0.0	2026-03-11 12:27:26.138398+00
d4493e9a-1bb8-4729-88ca-e55fedeee03c	0dbb642d-ce67-4752-b6e3-6242d8c69d72	2775a081-069b-4fa0-a7d9-a52353320dab	CSH2	cash_park	CASH_PARK	\N	7	manifesto_v1.0.0	2026-03-11 12:27:26.138398+00
0d062c43-e59e-4904-8bf4-0201154709b4	f66550c0-77db-4a8e-99ea-531219da8660	36af5a06-bc52-43fb-9ee4-6a4450a185a9	TST5221	CORE	STRATEGIC	35.00000000	1	policy-8cd6cebf	2026-03-11 12:27:45.854601+00
ee468146-5092-45d2-bd1a-a10f28b8bf2d	5cab396c-3c49-426b-8f4a-71e04f26e8c8	c2897d7d-1236-4406-9fbc-77aaf21561f5	TST7B88	CORE	STRATEGIC	35.00000000	1	policy-4bd15b62	2026-03-11 12:27:45.896546+00
441e8d16-3d17-427f-93ba-9f472ea7f3d7	259792b1-c894-403a-b988-06ca5af3c2c5	6902ae71-dfb5-4e25-be73-a15222bd6f14	TST4797	CORE	STRATEGIC	35.00000000	1	policy-a401f9dd	2026-03-11 12:27:45.948408+00
240414f1-f557-4d80-9abc-c30fa1e6ede2	a03981eb-5cc2-4483-85c4-c2b284a6dfae	25b9cd05-6def-48ce-9a48-6e585cc2d740	TSTE559	CORE	STRATEGIC	35.00000000	1	policy-420d29e4	2026-03-11 12:27:45.972635+00
fe3044eb-d736-4e5e-979a-40e05483d91e	6a0db12e-51d9-45b7-8905-77059fd448db	4b2f562a-7984-4295-925d-80542e676925	TST9882	CORE	STRATEGIC	35.00000000	1	policy-0b3b3790	2026-03-11 12:27:45.998219+00
5dbe47eb-b29a-4519-9cd1-cc06dd9458b5	a05c52ad-02fe-49c9-aae3-326eab43299a	48ac994e-6fee-43c7-b2b0-0bab8a296bb9	TST3F82	CORE	STRATEGIC	35.00000000	1	policy-1cf009e6	2026-03-11 12:43:01.974565+00
4253cc7b-00a1-4c95-a03e-a8fb40e8db47	4ec95e47-148d-4e8a-853c-a6fab32f873c	68ef3f7c-c933-4c3c-8d10-04335cce4fdb	TST08FC	CORE	STRATEGIC	35.00000000	1	policy-40f73baf	2026-03-11 12:43:02.020271+00
8f29a8ac-2a0e-453e-bb47-7b6cd51cd103	335990e2-b794-4049-b8b1-80b917284039	ce39ec61-2d85-4aae-b695-25c17093590b	TST11F0	CORE	STRATEGIC	35.00000000	1	policy-64379429	2026-03-11 12:43:02.087895+00
f67a2751-964d-4e68-88b2-9bf0af927fc1	527ba4f9-7b40-4ab0-8629-9d5fc7b341f0	a3756424-5fb7-4449-b3e0-5562f8bc8156	TSTD704	CORE	STRATEGIC	35.00000000	1	policy-2c9d678c	2026-03-11 12:43:02.119085+00
e2ec7293-5ac7-4de5-b05f-a07b108ee91d	b7ff47bd-d423-46bd-833e-3ccfd03e6069	45460de0-0548-4f73-a70b-86c8f617b821	TST28AA	CORE	STRATEGIC	35.00000000	1	policy-7b7908ed	2026-03-11 12:43:02.150373+00
9c8f0885-b064-4e98-8d5c-9367bb3ccd8d	f562d51c-79bd-4e05-ae8c-7478b494d740	3c9b012a-34c2-4951-9438-7b93a32ecfc0	TST96C4	CORE	STRATEGIC	35.00000000	1	policy-0e835d33	2026-03-11 13:21:30.094367+00
eef9c0e1-d61a-45bb-8910-bc710a44b6d9	8f28a33d-94b8-43d8-bc95-26167611cda8	76e9c2df-0e54-4093-80dd-36a4de93cc4e	TSTBDBC	CORE	STRATEGIC	35.00000000	1	policy-7419d948	2026-03-11 13:21:30.139172+00
acc7638a-ca89-49a6-9871-ffc25b916004	53680ec9-db2d-462a-b930-a8e2d9f30dfc	98475941-6ee0-404e-ba86-31a20ed1d91c	TST01F0	CORE	STRATEGIC	35.00000000	1	policy-a2bd4b2d	2026-03-11 13:21:30.192982+00
964286e2-3583-468b-a269-139e71bfc78d	f80e196d-6218-4f8c-a211-894e298418af	497f93df-ca41-4977-8417-eee7e47ce21d	TST0B3A	CORE	STRATEGIC	35.00000000	1	policy-805bd51f	2026-03-11 13:21:30.217181+00
7fe09b8e-d8d0-4530-8dd4-99b424920ebc	a023d249-926d-476e-8538-9d7a59f0cf97	ec93526b-d2dd-4c0b-ae46-9e4cf14a2163	TSTD057	CORE	STRATEGIC	35.00000000	1	policy-5014977d	2026-03-11 13:21:30.245159+00
da846ff1-ada9-4bf7-83b4-a56b2f8df108	6d0579fe-3d73-484b-843c-ec30733e270c	862a38b7-806e-4386-b73e-ea7dcd228863	TST661D	CORE	STRATEGIC	35.00000000	1	policy-8a57711b	2026-03-11 18:53:38.088104+00
adefa294-9f87-45f3-831c-6befcc8870cc	0332f290-ab02-4ed8-beac-30292d85c959	9021c8ed-7543-43c5-b6ac-d59ad36ac5ae	TSTEFC5	CORE	STRATEGIC	35.00000000	1	policy-fb782d3a	2026-03-11 18:53:38.122299+00
bfdda06f-b9e8-45c9-9a9c-06b4cfc70f27	7aab19f6-ce72-493b-9f44-8b35338401e8	5395a9dd-5279-4648-aba4-f95eb0d8fd4f	TST11B0	CORE	STRATEGIC	35.00000000	1	policy-5189a6d1	2026-03-11 18:53:38.178951+00
623bcad0-f2c5-4c4c-8ce9-0865d121600a	484bb1bf-e98d-4d59-9591-dd236d9acf79	2a82dbfc-f5c1-45d5-9694-796df3892432	TST3D96	CORE	STRATEGIC	35.00000000	1	policy-3644f6e6	2026-03-11 18:53:38.203431+00
efb45b90-9abc-4719-9a7c-93ae73dae10d	0953691a-0c74-4f2c-bd2d-c7123d2d847a	971d0982-1019-44c0-a32a-3e01b7333ca3	TST0BA0	CORE	STRATEGIC	35.00000000	1	policy-aa3affd7	2026-03-11 18:53:38.232374+00
242d3daa-03ab-40fa-8dcb-39266ac9c868	57d17ec3-dff1-4566-98fe-66870d390834	4e29d977-39af-44cd-b533-dac0b92d70c4	TSTED0F	CORE	STRATEGIC	35.00000000	1	policy-c210daab	2026-03-11 19:09:49.055375+00
255d72fb-29b9-43b0-a991-def024ffc165	03dc8184-7957-4423-a49f-d597b6060511	c1f931e3-af3c-424e-812b-98f01a5e2838	TSTAFD2	CORE	STRATEGIC	35.00000000	1	policy-15cc9e95	2026-03-11 19:09:49.093913+00
09aa0e31-2031-492b-b466-8ac450e5d8e6	cf3465de-eb7d-4a8e-a6b5-6588919bb632	ab776410-be94-432c-be51-a6a771ba4b43	TST8EA3	CORE	STRATEGIC	35.00000000	1	policy-9a7f7494	2026-03-11 19:09:49.143772+00
829e9d74-cf7d-48ed-b832-808aaf4ac686	5c2367af-893f-473d-8a09-3cddac469689	05e5a45e-d599-4bb8-80a9-66f07244532d	TSTCAC2	CORE	STRATEGIC	35.00000000	1	policy-918d864d	2026-03-11 19:09:49.163817+00
9936f57e-54a5-4a79-a624-92217f601f11	ee2c0dd8-ead5-42ed-9e7e-5a2bb38ce91e	006db63e-62b0-462e-8d59-e75e1b7bacbb	TST7310	CORE	STRATEGIC	35.00000000	1	policy-b03e375c	2026-03-11 19:09:49.194635+00
b56f8e1b-c0fe-419d-b9b7-f4faeeb02975	c8dd35af-2322-480c-ad23-1218b017b6c4	d9cc5049-e2d5-45c6-9814-d914745fde4e	TST4833	CORE	STRATEGIC	35.00000000	1	policy-3153d52c	2026-03-11 19:17:56.186012+00
354c4930-ce12-4ee8-ba17-84cc8693f38e	41694260-5bc3-4c21-a896-2f8c05a5061c	367dd67e-d09b-43e7-b8fd-1a12d511eb99	TST1D3A	CORE	STRATEGIC	35.00000000	1	policy-d6dcdfa2	2026-03-11 19:17:56.22259+00
79b6d0f7-c637-40f5-9460-fddbed7b7a80	65a5083e-27e1-4213-b6fc-b956991d4aa8	e71e4cb1-19ca-4bcd-9fe2-dfe30620d927	TSTE8E3	CORE	STRATEGIC	35.00000000	1	policy-c196cb10	2026-03-11 19:17:56.282635+00
a5df96d9-68d5-4821-a35c-d608037e55b5	7badea17-cfb5-4fb5-a613-333c7f79b06c	6f112061-1c1e-48be-8eed-339f20b2dd84	TST4BB1	CORE	STRATEGIC	35.00000000	1	policy-3e741be9	2026-03-11 19:17:56.312637+00
74d43e45-5c07-4746-bc17-74c736d50e08	c712bacf-99af-4ace-ace5-3659b98f6ade	c25c7532-d987-4b00-9330-16d0e3bd0d63	TST3BC0	CORE	STRATEGIC	35.00000000	1	policy-33903e6f	2026-03-11 19:17:56.341948+00
\.


--
-- TOC entry 3685 (class 0 OID 18466)
-- Dependencies: 227
-- Data for Name: price_points; Type: TABLE DATA; Schema: public; Owner: ta_app
--

COPY public.price_points (price_point_id, listing_id, as_of, price, currency, is_close, source_id, raw, created_at) FROM stdin;
4f7bffb5-0d14-4a85-aae0-72216afbb2b9	1c918015-04cd-4bd4-aa2f-4480a02e6947	2026-03-07 12:00:00+00	101.2500000000	GBP	t	test_engine_inputs_stale	null	2026-03-11 12:25:32.406676+00
b68ba3ef-d26e-4218-9fee-1cdf37b622ae	bb678d70-3ece-4993-a5b6-e8e46fb8839f	2026-03-10 12:00:00+00	102.5000000000	GBP	t	test_engine_inputs_fresh	null	2026-03-11 12:25:32.446397+00
9cc77f47-338a-413d-b94a-43b6743e9914	a7842a56-dc37-454c-9c3a-107952ee261c	2026-03-10 12:00:00+00	103.0000000000	GBP	t	test_engine_inputs_snapshot	null	2026-03-11 12:25:32.530625+00
5e26d3fc-afd4-4f89-a60f-5a4c4475a4df	f6cd2b7c-2f02-43ac-9b94-9e6749f9c4fc	2026-03-10 12:00:00+00	99.9500000000	GBP	t	test_engine_inputs_allocation	null	2026-03-11 12:25:32.580506+00
7abe014a-99f1-40d2-b31d-267f8908a3c4	596b1610-f65a-415e-8656-2c5a352ff2ad	2026-03-07 12:00:00+00	101.2500000000	GBP	t	test_engine_inputs_stale	null	2026-03-11 12:25:45.516221+00
25c0c4c5-cff2-444f-a2f7-3bbf017be957	d9dd3f6e-ce4d-4a18-b8ca-a822969dc063	2026-03-10 12:00:00+00	102.5000000000	GBP	t	test_engine_inputs_fresh	null	2026-03-11 12:25:45.563572+00
e396754d-a114-41a1-b67c-45a9cd9addea	5d90d841-aef2-42b7-ad7c-5bad03ab7ea6	2026-03-10 12:00:00+00	103.0000000000	GBP	t	test_engine_inputs_snapshot	null	2026-03-11 12:25:45.653853+00
d38f80a1-f67b-4a68-ad7c-481f992272ae	899de085-b827-439f-bfa1-c3636ee086c3	2026-03-10 12:00:00+00	99.9500000000	GBP	t	test_engine_inputs_allocation	null	2026-03-11 12:25:45.68982+00
bfc7ec2e-3a62-41c0-91f5-7f04d2f85b24	36af5a06-bc52-43fb-9ee4-6a4450a185a9	2026-03-07 12:00:00+00	101.2500000000	GBP	t	test_engine_inputs_stale	null	2026-03-11 12:27:45.860919+00
ea304185-00bf-4b46-b6c8-a1f240cd1f7a	c2897d7d-1236-4406-9fbc-77aaf21561f5	2026-03-10 12:00:00+00	102.5000000000	GBP	t	test_engine_inputs_fresh	null	2026-03-11 12:27:45.900855+00
e3e9d18d-ae0c-47fb-abe3-08b4115000b6	25b9cd05-6def-48ce-9a48-6e585cc2d740	2026-03-10 12:00:00+00	103.0000000000	GBP	t	test_engine_inputs_snapshot	null	2026-03-11 12:27:45.976834+00
2977ca89-96a0-40c7-81d6-0a6fdda4593f	4b2f562a-7984-4295-925d-80542e676925	2026-03-10 12:00:00+00	99.9500000000	GBP	t	test_engine_inputs_allocation	null	2026-03-11 12:27:46.003399+00
6c80b0bb-b98b-4c21-bf6d-3c799fb6981e	48ac994e-6fee-43c7-b2b0-0bab8a296bb9	2026-03-07 12:00:00+00	101.2500000000	GBP	t	test_engine_inputs_stale	null	2026-03-11 12:43:01.982965+00
37831e1c-ccae-4316-84fa-f14e375013fa	68ef3f7c-c933-4c3c-8d10-04335cce4fdb	2026-03-10 12:00:00+00	102.5000000000	GBP	t	test_engine_inputs_fresh	null	2026-03-11 12:43:02.024889+00
21d32ab1-2eca-46e7-a51a-0f15d3243a8c	a3756424-5fb7-4449-b3e0-5562f8bc8156	2026-03-10 12:00:00+00	103.0000000000	GBP	t	test_engine_inputs_snapshot	null	2026-03-11 12:43:02.122645+00
74e0f8b1-c4a4-471d-9c31-3b49700ef8af	45460de0-0548-4f73-a70b-86c8f617b821	2026-03-10 12:00:00+00	99.9500000000	GBP	t	test_engine_inputs_allocation	null	2026-03-11 12:43:02.154801+00
8d4b8a1a-ab83-44b4-a6d2-8561a144e0bb	3c9b012a-34c2-4951-9438-7b93a32ecfc0	2026-03-07 12:00:00+00	101.2500000000	GBP	t	test_engine_inputs_stale	null	2026-03-11 13:21:30.103771+00
14e372cc-def5-43b1-a592-b1e07c57a4a0	76e9c2df-0e54-4093-80dd-36a4de93cc4e	2026-03-10 12:00:00+00	102.5000000000	GBP	t	test_engine_inputs_fresh	null	2026-03-11 13:21:30.143645+00
90cd6073-89bb-4eb4-9f1d-23af0a99c77c	497f93df-ca41-4977-8417-eee7e47ce21d	2026-03-10 12:00:00+00	103.0000000000	GBP	t	test_engine_inputs_snapshot	null	2026-03-11 13:21:30.221671+00
66710090-acf6-4096-ae4d-bf3329654ad4	ec93526b-d2dd-4c0b-ae46-9e4cf14a2163	2026-03-10 12:00:00+00	99.9500000000	GBP	t	test_engine_inputs_allocation	null	2026-03-11 13:21:30.249671+00
71d53f3b-8fee-4206-9ce6-6b77d534fc54	2775a081-069b-4fa0-a7d9-a52353320dab	2026-03-11 00:00:00+00	122540.0000000000	GBp	t	yfinance	{"close": 122540.0, "source": "yfinance", "rows_returned": 5, "resolved_ticker": "CSH2.L"}	2026-03-11 17:39:58.567832+00
4b48b2c9-3524-4a31-876f-efe674a31162	44c9f233-ded8-44e5-8dda-f467827fe671	2026-03-11 00:00:00+00	5.6060000000	GBP	t	yfinance	{"close": 5.605999946594238, "source": "yfinance", "rows_returned": 5, "resolved_ticker": "IGL5.L"}	2026-03-11 17:39:58.567832+00
46e142e3-bbbe-4969-a510-d99dd2dc709d	59976aac-caa6-4e73-b57b-2483c47d5c56	2026-03-11 00:00:00+00	9.7940000000	GBP	t	yfinance	{"close": 9.793999671936035, "source": "yfinance", "rows_returned": 2, "resolved_ticker": "SEMI.L"}	2026-03-11 17:39:58.567832+00
24821b6b-b61a-441b-acbc-5cd870844a5f	d18e6625-f801-4b20-b29a-531c5a54015f	2026-03-11 00:00:00+00	127.6800000000	GBP	t	yfinance	{"close": 127.68000030517578, "source": "yfinance", "rows_returned": 2, "resolved_ticker": "VWRP.L"}	2026-03-11 17:39:58.567832+00
d66e0645-10fa-44ce-b519-c2506c28e587	8f574494-d8c0-4ce7-979a-1c058718e609	2026-03-11 00:00:00+00	7.0070000000	GBP	t	yfinance	{"close": 7.006999969482422, "source": "yfinance", "rows_returned": 2, "resolved_ticker": "WLDS.L"}	2026-03-11 17:39:58.567832+00
53d69559-f5cb-4239-a043-8d54b2f378fb	427a4690-316c-462d-add9-199e0c71de0d	2026-03-11 00:00:00+00	51.2700000000	GBP	t	yfinance	{"close": 51.27000045776367, "source": "yfinance", "rows_returned": 2, "resolved_ticker": "XWES.L"}	2026-03-11 17:39:58.567832+00
e80c876b-d1b0-4acb-8882-59128789674a	1bc182b8-7410-4026-9d64-c628a13c4836	2026-03-11 00:00:00+00	42.9150000000	GBP	t	yfinance	{"close": 42.915000915527344, "source": "yfinance", "rows_returned": 2, "resolved_ticker": "XWHS.L"}	2026-03-11 17:39:58.567832+00
6a099ed1-f311-4273-aec9-5ef1421a2e01	862a38b7-806e-4386-b73e-ea7dcd228863	2026-03-07 12:00:00+00	101.2500000000	GBP	t	test_engine_inputs_stale	null	2026-03-11 18:53:38.095031+00
62c836ce-8394-4149-975a-0609da5ab27c	9021c8ed-7543-43c5-b6ac-d59ad36ac5ae	2026-03-10 12:00:00+00	102.5000000000	GBP	t	test_engine_inputs_fresh	null	2026-03-11 18:53:38.124624+00
6e3218f0-4513-4db0-be98-f2fce39e85f9	2a82dbfc-f5c1-45d5-9694-796df3892432	2026-03-10 12:00:00+00	103.0000000000	GBP	t	test_engine_inputs_snapshot	null	2026-03-11 18:53:38.206852+00
3c65d7c1-9096-4f0b-aad6-44136ff7c288	971d0982-1019-44c0-a32a-3e01b7333ca3	2026-03-10 12:00:00+00	99.9500000000	GBP	t	test_engine_inputs_allocation	null	2026-03-11 18:53:38.236856+00
5947c9aa-0513-4a2d-b081-df20131d8075	ce1530ec-4916-4b5d-9530-ef47e0bf8b8d	2026-03-09 22:51:50.842575+00	72.7600000000	GBP	t	mock	{"mock": true, "anomaly_jump": false, "anomaly_scale": false, "anomaly_stale": false}	2026-03-09 22:51:50.838351+00
238696f4-e2d7-4d95-918e-7845c732fbd6	ce1530ec-4916-4b5d-9530-ef47e0bf8b8d	2026-03-09 22:51:50.842575+00	72.3393000000	GBP	f	mock	{"mock": true, "variance": "0.9942"}	2026-03-09 22:51:50.838351+00
acdc703b-c15c-4505-bab9-6165bc3fb7d1	a9fb309f-bb1e-41c1-a9c9-808807038195	2026-03-09 22:53:33.921385+00	124.8700000000	GBP	t	mock	{"mock": true, "anomaly_jump": false, "anomaly_scale": false, "anomaly_stale": false}	2026-03-09 22:53:33.920301+00
49024092-a1e6-4102-8283-17d93bae6881	a9fb309f-bb1e-41c1-a9c9-808807038195	2026-03-09 22:53:33.921385+00	125.0365000000	GBP	f	mock	{"mock": true, "variance": "1.0013"}	2026-03-09 22:53:33.920301+00
77f2fac0-8a09-4e08-949b-f02344a564e7	88535377-562e-4c57-86af-3113c6acf175	2026-03-11 09:56:16.705182+00	392.3100000000	USD	t	mock	{"mock": true, "anomaly_jump": false, "anomaly_scale": false, "anomaly_stale": false}	2026-03-11 09:56:16.702275+00
93770afa-8275-4bf1-b0e3-f0fe59ede178	88535377-562e-4c57-86af-3113c6acf175	2026-03-11 09:56:16.705182+00	393.1807000000	USD	f	mock	{"mock": true, "variance": "1.0022"}	2026-03-11 09:56:16.702275+00
22d54136-87b3-4930-a201-1593803c2263	88535377-562e-4c57-86af-3113c6acf175	2026-03-11 09:56:17.626513+00	392.3100000000	USD	t	mock	{"mock": true, "anomaly_jump": false, "anomaly_scale": false, "anomaly_stale": false}	2026-03-11 09:56:17.625041+00
184e22ad-5dcf-4fa1-b651-44e3f732084d	88535377-562e-4c57-86af-3113c6acf175	2026-03-11 09:56:17.626513+00	393.1807000000	USD	f	mock	{"mock": true, "variance": "1.0022"}	2026-03-11 09:56:17.625041+00
2c68498c-85ec-4601-bae1-81ab8aee5a64	88535377-562e-4c57-86af-3113c6acf175	2026-03-11 09:56:19.870754+00	392.3100000000	USD	t	mock	{"mock": true, "anomaly_jump": false, "anomaly_scale": false, "anomaly_stale": false}	2026-03-11 09:56:19.869897+00
1f8bcf13-4dd2-421c-8bb5-d18763ad5ac9	88535377-562e-4c57-86af-3113c6acf175	2026-03-11 09:56:19.870754+00	393.1807000000	USD	f	mock	{"mock": true, "variance": "1.0022"}	2026-03-11 09:56:19.869897+00
33ff3823-6dda-4590-8e70-132ef72c5baa	4e29d977-39af-44cd-b533-dac0b92d70c4	2026-03-07 12:00:00+00	101.2500000000	GBP	t	test_engine_inputs_stale	null	2026-03-11 19:09:49.062819+00
6852d39d-3fe8-4cda-9948-76fd2e789406	c1f931e3-af3c-424e-812b-98f01a5e2838	2026-03-10 12:00:00+00	102.5000000000	GBP	t	test_engine_inputs_fresh	null	2026-03-11 19:09:49.096551+00
46f1387f-c44a-4f91-8d72-54dc699a69d4	05e5a45e-d599-4bb8-80a9-66f07244532d	2026-03-10 12:00:00+00	103.0000000000	GBP	t	test_engine_inputs_snapshot	null	2026-03-11 19:09:49.166456+00
4ed58ee8-696d-4b5b-9ba1-892c203b5291	006db63e-62b0-462e-8d59-e75e1b7bacbb	2026-03-10 12:00:00+00	99.9500000000	GBP	t	test_engine_inputs_allocation	null	2026-03-11 19:09:49.198731+00
9cecca56-0d83-4cae-a21f-ab1b78218037	d9cc5049-e2d5-45c6-9814-d914745fde4e	2026-03-07 12:00:00+00	101.2500000000	GBP	t	test_engine_inputs_stale	null	2026-03-11 19:17:56.190348+00
582a8899-5482-455a-8abd-e8d38dfb2bfe	367dd67e-d09b-43e7-b8fd-1a12d511eb99	2026-03-10 12:00:00+00	102.5000000000	GBP	t	test_engine_inputs_fresh	null	2026-03-11 19:17:56.226229+00
05a1b27f-ceb4-4c55-83d9-3fb8eb94a95f	6f112061-1c1e-48be-8eed-339f20b2dd84	2026-03-10 12:00:00+00	103.0000000000	GBP	t	test_engine_inputs_snapshot	null	2026-03-11 19:17:56.316338+00
5de5521d-1500-4932-8547-5e66b8162bfb	c25c7532-d987-4b00-9330-16d0e3bd0d63	2026-03-10 12:00:00+00	99.9500000000	GBP	t	test_engine_inputs_allocation	null	2026-03-11 19:17:56.346271+00
\.


--
-- TOC entry 3697 (class 0 OID 26424)
-- Dependencies: 239
-- Data for Name: recommendation_batches; Type: TABLE DATA; Schema: public; Owner: ta_app
--

COPY public.recommendation_batches (recommendation_batch_id, portfolio_id, status, generated_at, executed_at, ignored_at, closed_by_user_id, execution_summary, run_id, created_at) FROM stdin;
3504883c-b74a-44fe-8f4e-2d708e03cf79	79571e3e-7fb1-4462-8f78-f4994182be58	PENDING	2026-03-11 19:17:00.311446+00	\N	\N	\N	\N	\N	2026-03-11 19:17:00.311446+00
2d214464-ee82-4bb1-b780-6a42af7c5b9d	5bb022ad-ced5-438c-8eac-9c306fbdf77c	EXECUTED	2026-03-11 19:17:48.265682+00	2026-03-11 19:17:48.302884+00	\N	aa4e1960-7d43-46b6-ae8d-b184cdb470bd	{"executed_at": "2026-03-11T19:17:48.302884+00:00", "lines_executed": 1, "entries_created": 1, "ledger_batch_id": "8d8c1173-3d05-48b2-8c19-e8a8dbbd5b11", "total_cash_impact": "-1005.0000000000"}	\N	2026-03-11 19:17:48.265682+00
60a039f2-8d6d-4ce1-868b-d82c9a49ceb7	b87f27e6-b395-4604-b8f3-8c7967ef2583	EXECUTED	2026-03-11 19:17:48.334133+00	2026-03-11 19:17:48.346956+00	\N	286a21d8-bda0-45dc-aaf1-40da26b918e4	{"executed_at": "2026-03-11T19:17:48.346956+00:00", "lines_executed": 1, "entries_created": 1, "ledger_batch_id": "7915c416-8379-4b43-aaab-941b948dc656", "total_cash_impact": "-1005.0000000000"}	\N	2026-03-11 19:17:48.334133+00
82b3c0bb-df5b-48e1-9335-13be89ef0559	f215e7c6-9ca2-477d-8576-103a9dbdbb5b	EXECUTED	2026-03-11 19:17:48.370137+00	2026-03-11 19:17:48.381056+00	\N	0842f730-0598-4271-93d5-6766297f29b1	{"executed_at": "2026-03-11T19:17:48.381056+00:00", "lines_executed": 1, "entries_created": 1, "ledger_batch_id": "10587a54-c7f1-42fa-b690-3ece0796c693", "total_cash_impact": "-528.0000000000"}	\N	2026-03-11 19:17:48.370137+00
d5b8d681-efee-4303-b5d7-6ad325a5ef8b	aed673d6-c6d4-4d43-a8e2-b07340d8ad41	EXECUTED	2026-03-11 19:17:48.402393+00	2026-03-11 19:17:48.419847+00	\N	1420911d-1722-4d2f-a969-6343dbfb6d1a	{"executed_at": "2026-03-11T19:17:48.419847+00:00", "lines_executed": 1, "entries_created": 1, "ledger_batch_id": "7c868f57-db7a-4ccf-adc2-4aeaae3d6fb4", "total_cash_impact": "-1005.0000000000"}	\N	2026-03-11 19:17:48.402393+00
21277236-2a86-4561-ab04-6aa6a9579c92	fbbd734d-8613-4c2d-902c-40826950aa55	EXECUTED	2026-03-11 19:17:48.450381+00	2026-03-11 19:17:48.465161+00	\N	bb694a18-6764-46e4-9179-5e4abed2e56c	{"executed_at": "2026-03-11T19:17:48.465161+00:00", "lines_executed": 1, "entries_created": 1, "ledger_batch_id": "154a38eb-bf8a-495b-9572-75196fa7e951", "total_cash_impact": "-1005.0000000000"}	\N	2026-03-11 19:17:48.450381+00
40166ea7-2f7c-4227-82db-40a888a1b6ee	9e4d07a1-d275-4fa6-b499-85dc02627033	PENDING	2026-03-11 19:17:48.487986+00	\N	\N	\N	\N	\N	2026-03-11 19:17:48.487986+00
99aa2655-4f35-4fb5-86f6-4e31f06d5332	7fb0b5ce-109d-4337-92a8-2195afef1bff	IGNORED	2026-03-11 19:17:48.514122+00	\N	2026-03-11 19:17:48.521506+00	26f38a7d-33c8-4aa7-b67e-8c3cc0a73d34	{"reason": "Market conditions changed", "ignored_at": "2026-03-11T19:17:48.521506+00:00", "ignored_by": "26f38a7d-33c8-4aa7-b67e-8c3cc0a73d34"}	\N	2026-03-11 19:17:48.514122+00
cecee63f-f85e-4cd3-8d41-2db2b2e00934	9b4870ec-6f2d-4d93-9a3e-dc5d730b7327	IGNORED	2026-03-11 19:17:48.54203+00	\N	2026-03-11 19:17:48.549919+00	617d97e3-47de-4f17-a9b4-36a0c79cb98f	{"reason": "Deferred to next month", "ignored_at": "2026-03-11T19:17:48.549919+00:00", "ignored_by": "617d97e3-47de-4f17-a9b4-36a0c79cb98f"}	\N	2026-03-11 19:17:48.54203+00
bddc1b16-bfe4-48f0-838d-c1a6be8b9931	c7966280-fb24-4816-ac89-8f57d94252ae	IGNORED	2026-03-11 19:17:48.570142+00	\N	2026-03-11 19:17:48.578192+00	2d5b130b-0af0-4add-a686-030d576ca9d2	{"reason": "Testing ignore", "ignored_at": "2026-03-11T19:17:48.578192+00:00", "ignored_by": "2d5b130b-0af0-4add-a686-030d576ca9d2"}	\N	2026-03-11 19:17:48.570142+00
27a16e3a-9c18-410b-a584-717dff91ca98	0af60105-8d65-46ba-9e1b-0a432690ed3b	IGNORED	2026-03-11 19:17:48.602097+00	\N	2026-03-11 19:17:48.611753+00	15589ed0-c73f-476a-9e00-d383b1e29033	{"reason": null, "ignored_at": "2026-03-11T19:17:48.611753+00:00", "ignored_by": "15589ed0-c73f-476a-9e00-d383b1e29033"}	\N	2026-03-11 19:17:48.602097+00
a6ad2470-0283-4327-8660-3a67d38ba888	91797da6-97ee-4762-a110-772aedf0f225	EXECUTED	2026-03-11 19:17:48.636014+00	2026-03-11 19:17:48.64696+00	\N	74883a77-453c-47db-bbb9-ead741b63dad	{"executed_at": "2026-03-11T19:17:48.646960+00:00", "lines_executed": 1, "entries_created": 1, "ledger_batch_id": "6056aaa4-bfb0-44d3-80a7-acec763262a5", "total_cash_impact": "-1005.0000000000"}	\N	2026-03-11 19:17:48.636014+00
be4adaf9-c48d-43c6-918c-a49ac6d06607	442751d4-2ed9-4874-a474-4ca686ce88c5	EXECUTED	2026-03-11 19:17:56.366148+00	2026-03-11 19:17:56.390491+00	\N	18f8a6d4-7795-4380-9ebf-6ba112d8f799	{"executed_at": "2026-03-11T19:17:56.390491+00:00", "lines_executed": 1, "entries_created": 1, "ledger_batch_id": "82a8f598-f95f-482d-bc03-a6c7cd8960db", "total_cash_impact": "-1005.0000000000"}	\N	2026-03-11 19:17:56.366148+00
9444313c-6c5d-4c0c-b2a1-e846c97e30cc	4176c31c-6f31-4f4b-b9d9-273a24ed87d4	EXECUTED	2026-03-11 19:17:56.414158+00	2026-03-11 19:17:56.429093+00	\N	d35f101b-7748-4535-b571-43a0e0e274d1	{"executed_at": "2026-03-11T19:17:56.429093+00:00", "lines_executed": 1, "entries_created": 1, "ledger_batch_id": "47ad61ff-28d0-45ba-903b-d4ae3fd26ede", "total_cash_impact": "-1005.0000000000"}	\N	2026-03-11 19:17:56.414158+00
c86bbff6-32c6-406d-9092-3dce49af9ec2	ac3876c8-859f-4cbd-aebf-59248d4e9e42	EXECUTED	2026-03-11 19:17:56.452659+00	2026-03-11 19:17:56.472097+00	\N	3cca1d39-faa3-4a3d-9a6a-25302a708b28	{"executed_at": "2026-03-11T19:17:56.472097+00:00", "lines_executed": 1, "entries_created": 1, "ledger_batch_id": "fd87adbd-6be2-494b-a63c-32b778b613aa", "total_cash_impact": "-528.0000000000"}	\N	2026-03-11 19:17:56.452659+00
44493dfb-9139-4bca-a0b5-3b28461b9961	5643df5b-1190-410a-8613-fe281ed78219	EXECUTED	2026-03-11 19:17:56.498375+00	2026-03-11 19:17:56.518204+00	\N	319b1561-136d-4601-a951-26d74f7a14ac	{"executed_at": "2026-03-11T19:17:56.518204+00:00", "lines_executed": 1, "entries_created": 1, "ledger_batch_id": "908a3f8f-c04d-47e7-bdf8-acfe91d01da7", "total_cash_impact": "-1005.0000000000"}	\N	2026-03-11 19:17:56.498375+00
2e729c0d-a28c-490b-a739-fd9642942543	48eb442a-9521-4d87-a013-fae87f350831	EXECUTED	2026-03-11 19:17:56.546272+00	2026-03-11 19:17:56.560965+00	\N	ea2b69fc-f81a-4a08-bef2-943e826a5b81	{"executed_at": "2026-03-11T19:17:56.560965+00:00", "lines_executed": 1, "entries_created": 1, "ledger_batch_id": "a9f86105-cdd5-4fd8-9381-6319a0a66575", "total_cash_impact": "-1005.0000000000"}	\N	2026-03-11 19:17:56.546272+00
b80ce9b7-c668-4a2b-be31-8ae7d77819d5	a7f50004-2806-4dcd-abdd-92f7b3f3b0a4	PENDING	2026-03-11 19:17:56.588497+00	\N	\N	\N	\N	\N	2026-03-11 19:17:56.588497+00
7f25f489-614a-48f4-a5f3-02da9053ffbe	1672e066-3d21-42a3-aa25-9e55e83afd53	IGNORED	2026-03-11 19:17:56.614235+00	\N	2026-03-11 19:17:56.619799+00	90060e1e-dd0b-4800-b269-6443db2fcc4a	{"reason": "Market conditions changed", "ignored_at": "2026-03-11T19:17:56.619799+00:00", "ignored_by": "90060e1e-dd0b-4800-b269-6443db2fcc4a"}	\N	2026-03-11 19:17:56.614235+00
dff7a2d7-4737-43ae-9ce7-c5be26dc6bcc	61af205c-fd68-4a54-8115-7c8cf5346c22	IGNORED	2026-03-11 19:17:56.644553+00	\N	2026-03-11 19:17:56.655417+00	4bfbb8a0-d061-4c0d-88d3-965a3075226f	{"reason": "Deferred to next month", "ignored_at": "2026-03-11T19:17:56.655417+00:00", "ignored_by": "4bfbb8a0-d061-4c0d-88d3-965a3075226f"}	\N	2026-03-11 19:17:56.644553+00
ba387719-5e48-49f6-b525-56302be3b829	f7239388-dbeb-4814-a3d8-266a389f9684	IGNORED	2026-03-11 19:17:56.680273+00	\N	2026-03-11 19:17:56.690505+00	4c88a3a8-6115-4cb5-a7f2-ea357fc60567	{"reason": "Testing ignore", "ignored_at": "2026-03-11T19:17:56.690505+00:00", "ignored_by": "4c88a3a8-6115-4cb5-a7f2-ea357fc60567"}	\N	2026-03-11 19:17:56.680273+00
e11a5e94-ee8b-49e3-b82e-726764e3194d	0ea34e7a-7f36-4075-bc18-6d57a70dd200	IGNORED	2026-03-11 19:17:56.716452+00	\N	2026-03-11 19:17:56.730484+00	b9cd736b-7715-41a1-8627-9cd7a458c6cf	{"reason": null, "ignored_at": "2026-03-11T19:17:56.730484+00:00", "ignored_by": "b9cd736b-7715-41a1-8627-9cd7a458c6cf"}	\N	2026-03-11 19:17:56.716452+00
99f3937f-6ea3-474d-b895-3d19ee20f269	ad7e990c-4832-498b-a1c8-ce99cc20c609	EXECUTED	2026-03-11 19:17:56.760423+00	2026-03-11 19:17:56.779682+00	\N	e4050dcc-060b-4ef8-aa5e-e3f1c6a976b7	{"executed_at": "2026-03-11T19:17:56.779682+00:00", "lines_executed": 1, "entries_created": 1, "ledger_batch_id": "ef6b92dd-180e-4fde-a615-685954e197f2", "total_cash_impact": "-1005.0000000000"}	\N	2026-03-11 19:17:56.760423+00
\.


--
-- TOC entry 3698 (class 0 OID 26452)
-- Dependencies: 240
-- Data for Name: recommendation_lines; Type: TABLE DATA; Schema: public; Owner: ta_app
--

COPY public.recommendation_lines (recommendation_line_id, recommendation_batch_id, listing_id, action, proposed_quantity, proposed_price_gbp, proposed_value_gbp, proposed_fee_gbp, status, executed_quantity, executed_price_gbp, executed_value_gbp, executed_fee_gbp, ledger_entry_id, execution_note, created_at) FROM stdin;
52142ab3-21b6-4e3e-ad53-6a4a61e1666f	3504883c-b74a-44fe-8f4e-2d708e03cf79	b7afe429-366b-4867-bf1d-27db61e75a5e	BUY	100.0000000000	10.0000000000	1000.0000000000	5.0000000000	PROPOSED	\N	\N	\N	\N	\N	\N	2026-03-11 19:17:00.318784+00
0029308c-6943-49fe-94f4-e3de3d895232	2d214464-ee82-4bb1-b780-6a42af7c5b9d	c4a7f2e2-ec50-4e5f-8979-cb68132d7c40	BUY	100.0000000000	10.0000000000	1000.0000000000	5.0000000000	EXECUTED	100.0000000000	10.0000000000	1000.0000000000	5.0000000000	dcf898b3-e35e-4bad-8c12-ac2a0722653f	\N	2026-03-11 19:17:48.270972+00
4b79b05a-a347-4480-9064-299536f48469	60a039f2-8d6d-4ce1-868b-d82c9a49ceb7	86b1126a-dee0-4462-a36e-36a189b0ebe8	BUY	100.0000000000	10.0000000000	1000.0000000000	5.0000000000	EXECUTED	100.0000000000	10.0000000000	1000.0000000000	5.0000000000	61907652-3698-4713-ada5-0346fdc9c0f7	\N	2026-03-11 19:17:48.3363+00
11191133-4097-43da-8196-0a002f9a2e14	82b3c0bb-df5b-48e1-9335-13be89ef0559	d2e70ea0-a318-4841-b0bd-09d031c299c4	BUY	100.0000000000	10.0000000000	1000.0000000000	5.0000000000	EXECUTED	50.0000000000	10.5000000000	525.0000000000	3.0000000000	6863ffd6-fd85-4710-a834-22b1c483a18a	Test execution note	2026-03-11 19:17:48.372143+00
9c8cac26-abda-435c-b013-2ff1b421083b	d5b8d681-efee-4303-b5d7-6ad325a5ef8b	a06d5744-bc1c-45d4-b0aa-40b6d418ae24	BUY	100.0000000000	10.0000000000	1000.0000000000	5.0000000000	EXECUTED	100.0000000000	10.0000000000	1000.0000000000	5.0000000000	729da3df-200d-48d2-93ac-9d71934a6e03	\N	2026-03-11 19:17:48.406336+00
a9748414-f26f-4e86-8e2b-7f5b34029d0a	21277236-2a86-4561-ab04-6aa6a9579c92	00134054-20cc-4d4c-adb1-5ef072edd566	BUY	100.0000000000	10.0000000000	1000.0000000000	5.0000000000	EXECUTED	100.0000000000	10.0000000000	1000.0000000000	5.0000000000	560e79e8-eef0-4975-b8de-64f07a15d736	\N	2026-03-11 19:17:48.454328+00
e2f5dafb-215f-4de3-acd0-7e6bc33baaa7	40166ea7-2f7c-4227-82db-40a888a1b6ee	c7873b37-3f77-4dae-b6fc-957142bfe184	BUY	100.0000000000	10.0000000000	1000.0000000000	5.0000000000	PROPOSED	\N	\N	\N	\N	\N	\N	2026-03-11 19:17:48.49026+00
a7d2c2e9-2784-4f48-80e4-a40663c9edd3	99aa2655-4f35-4fb5-86f6-4e31f06d5332	4553346d-9a15-47c4-8b16-8acb63d626eb	BUY	100.0000000000	10.0000000000	1000.0000000000	5.0000000000	IGNORED	\N	\N	\N	\N	\N	Market conditions changed	2026-03-11 19:17:48.516265+00
59be6b32-171f-4a31-9ea8-6fd1ccd05444	cecee63f-f85e-4cd3-8d41-2db2b2e00934	a19cf7bc-0558-4461-a267-b6fee1a26365	BUY	100.0000000000	10.0000000000	1000.0000000000	5.0000000000	IGNORED	\N	\N	\N	\N	\N	Deferred to next month	2026-03-11 19:17:48.544282+00
892a53e5-f3ab-4d99-b2f8-b24424149b18	bddc1b16-bfe4-48f0-838d-c1a6be8b9931	0ae33f3b-3935-4718-80d3-102afea2950f	BUY	100.0000000000	10.0000000000	1000.0000000000	5.0000000000	IGNORED	\N	\N	\N	\N	\N	Testing ignore	2026-03-11 19:17:48.57231+00
cd13b9a2-23d2-42fd-a12f-1f4e81964cbc	27a16e3a-9c18-410b-a584-717dff91ca98	9ed0f8bd-f6dd-479e-b00a-4775a4b7832c	BUY	100.0000000000	10.0000000000	1000.0000000000	5.0000000000	IGNORED	\N	\N	\N	\N	\N	\N	2026-03-11 19:17:48.604212+00
08747a95-614c-4bc4-89ed-9efb142ba333	a6ad2470-0283-4327-8660-3a67d38ba888	b6f17b59-241b-4b6f-9bb5-7319310a0649	BUY	100.0000000000	10.0000000000	1000.0000000000	5.0000000000	EXECUTED	100.0000000000	10.0000000000	1000.0000000000	5.0000000000	746f496b-ef34-4957-9e44-f60ef7c9c2cd	\N	2026-03-11 19:17:48.638004+00
6a523156-1320-4140-8833-bd9f513bf3d6	be4adaf9-c48d-43c6-918c-a49ac6d06607	9b93e41a-88ca-49c4-9382-808f327eb605	BUY	100.0000000000	10.0000000000	1000.0000000000	5.0000000000	EXECUTED	100.0000000000	10.0000000000	1000.0000000000	5.0000000000	c2a5a70c-679f-45c1-bc25-5fd202a4b67e	\N	2026-03-11 19:17:56.370617+00
238c25b8-abce-483d-ad63-b81e44e4b958	9444313c-6c5d-4c0c-b2a1-e846c97e30cc	aec7239d-f20a-4eca-9c77-fa4ec1184c3d	BUY	100.0000000000	10.0000000000	1000.0000000000	5.0000000000	EXECUTED	100.0000000000	10.0000000000	1000.0000000000	5.0000000000	185c81dc-ad03-4f21-888a-76b163d9d7d7	\N	2026-03-11 19:17:56.416223+00
2aa619c5-fc57-4e61-8c7a-337a1b48ba9a	c86bbff6-32c6-406d-9092-3dce49af9ec2	005274d7-7dfc-422b-bc07-be64beca35cc	BUY	100.0000000000	10.0000000000	1000.0000000000	5.0000000000	EXECUTED	50.0000000000	10.5000000000	525.0000000000	3.0000000000	27003e76-bf2c-4cab-919c-5437e723d335	Test execution note	2026-03-11 19:17:56.456259+00
fe062078-e7e8-4ff9-be6d-610ecacf64aa	44493dfb-9139-4bca-a0b5-3b28461b9961	fc7cd6eb-a2b5-4ded-9c1e-ebae590f8159	BUY	100.0000000000	10.0000000000	1000.0000000000	5.0000000000	EXECUTED	100.0000000000	10.0000000000	1000.0000000000	5.0000000000	6d515285-1f46-4e49-8291-155fc1cb7764	\N	2026-03-11 19:17:56.502516+00
2cc8f940-9360-41c0-a5fa-2b433148ee1b	2e729c0d-a28c-490b-a739-fd9642942543	48480b7a-d4b7-4105-aeea-1adb045fda27	BUY	100.0000000000	10.0000000000	1000.0000000000	5.0000000000	EXECUTED	100.0000000000	10.0000000000	1000.0000000000	5.0000000000	68f85e57-a6f0-43fe-9416-21fc40606705	\N	2026-03-11 19:17:56.550178+00
59a475e1-fa45-40e7-8a13-653c5f49e142	b80ce9b7-c668-4a2b-be31-8ae7d77819d5	c3ad6f84-41b6-4f42-9b38-b60c7685a840	BUY	100.0000000000	10.0000000000	1000.0000000000	5.0000000000	PROPOSED	\N	\N	\N	\N	\N	\N	2026-03-11 19:17:56.592201+00
55cc3c43-8bc3-4730-ac7e-b92e2cd4f57c	7f25f489-614a-48f4-a5f3-02da9053ffbe	e27a37b0-0800-48ae-b5e8-e49bc0647c37	BUY	100.0000000000	10.0000000000	1000.0000000000	5.0000000000	IGNORED	\N	\N	\N	\N	\N	Market conditions changed	2026-03-11 19:17:56.616254+00
11137973-7667-47e0-9cc3-0453792ed4b5	dff7a2d7-4737-43ae-9ce7-c5be26dc6bcc	f0487728-4884-47f6-ac0d-20a48addb1c7	BUY	100.0000000000	10.0000000000	1000.0000000000	5.0000000000	IGNORED	\N	\N	\N	\N	\N	Deferred to next month	2026-03-11 19:17:56.648445+00
56c96e0d-d8db-4d2a-a2c3-2e52fa25ab47	ba387719-5e48-49f6-b525-56302be3b829	1250ffcd-241e-43b5-ac73-84b7c238561f	BUY	100.0000000000	10.0000000000	1000.0000000000	5.0000000000	IGNORED	\N	\N	\N	\N	\N	Testing ignore	2026-03-11 19:17:56.684311+00
a0b6a64e-8fc8-41e9-a039-4e51b1dc52e7	e11a5e94-ee8b-49e3-b82e-726764e3194d	9e41de7e-17c9-4cd6-9029-be58779811d1	BUY	100.0000000000	10.0000000000	1000.0000000000	5.0000000000	IGNORED	\N	\N	\N	\N	\N	\N	2026-03-11 19:17:56.720473+00
27cc4f7f-3bf0-4157-9ef0-4495c7ec2128	99f3937f-6ea3-474d-b895-3d19ee20f269	d93da6f3-3331-45de-86ae-1f7dfc26fe9d	BUY	100.0000000000	10.0000000000	1000.0000000000	5.0000000000	EXECUTED	100.0000000000	10.0000000000	1000.0000000000	5.0000000000	a5f7c4e6-40ed-41d1-8d1e-6fb76d1a9b8e	\N	2026-03-11 19:17:56.764274+00
\.


--
-- TOC entry 3689 (class 0 OID 18533)
-- Dependencies: 231
-- Data for Name: run_input_snapshots; Type: TABLE DATA; Schema: public; Owner: ta_app
--

COPY public.run_input_snapshots (run_id, input_json, input_hash, created_at) FROM stdin;
8b8207b3-ab54-4264-8b6b-ffa7b6e3b6c8	{"job_id": "cda4f96b-1886-4194-a825-088e06f1f6ce", "listings": [], "provider": "mock", "dq_config": {"require_close": true, "fx_stale_max_days": 3, "jump_threshold_pct": 10.0, "stale_max_days_close": 3, "stale_max_minutes_intraday": 30}, "fx_quotes": [], "task_kind": "PRICE_REFRESH", "portfolio_id": "a9136ac7-2cd4-43db-be99-f4fb545b5ec1", "price_quotes": []}		2026-02-28 00:55:43.005728+00
3f0887cb-e86e-4a9d-90bb-c7b6a8ed6316	{"job_id": "d91f941a-54a4-4f8a-9301-b9a11763e60a", "listings": ["ce1530ec-4916-4b5d-9530-ef47e0bf8b8d"], "provider": "mock", "dq_config": {"require_close": true, "fx_stale_max_days": 3, "jump_threshold_pct": 10.0, "stale_max_days_close": 3, "stale_max_minutes_intraday": 30}, "fx_quotes": [], "task_kind": "PRICE_REFRESH", "portfolio_id": "e675105a-f954-4553-b993-fb77527d620f", "price_quotes": [{"as_of": "2026-03-09T22:51:50.842575+00:00", "price": "72.7600", "currency": "GBP", "is_close": true, "listing_id": "ce1530ec-4916-4b5d-9530-ef47e0bf8b8d"}, {"as_of": "2026-03-09T22:51:50.842575+00:00", "price": "72.3393", "currency": "GBP", "is_close": false, "listing_id": "ce1530ec-4916-4b5d-9530-ef47e0bf8b8d"}]}		2026-03-09 22:51:50.838351+00
b3519ea4-baac-44f4-a9ae-3d051c9a8866	{"job_id": "fd7e73ad-5666-44a2-b2ce-c18c77d40c4d", "listings": ["a9fb309f-bb1e-41c1-a9c9-808807038195"], "provider": "mock", "dq_config": {"require_close": true, "fx_stale_max_days": 3, "jump_threshold_pct": 10.0, "stale_max_days_close": 3, "stale_max_minutes_intraday": 30}, "fx_quotes": [], "task_kind": "PRICE_REFRESH", "portfolio_id": "e5fa701e-6756-4a03-ac4f-052407357964", "price_quotes": [{"as_of": "2026-03-09T22:53:33.921385+00:00", "price": "124.8700", "currency": "GBP", "is_close": true, "listing_id": "a9fb309f-bb1e-41c1-a9c9-808807038195"}, {"as_of": "2026-03-09T22:53:33.921385+00:00", "price": "125.0365", "currency": "GBP", "is_close": false, "listing_id": "a9fb309f-bb1e-41c1-a9c9-808807038195"}]}		2026-03-09 22:53:33.920301+00
c0f1461a-7cf8-4f66-b735-c7f93702c323	{"job_id": "0b1ea7b5-c49e-474d-96e1-6a73bafc78de", "listings": ["88535377-562e-4c57-86af-3113c6acf175"], "provider": "mock", "dq_config": {"require_close": true, "fx_stale_max_days": 3, "jump_threshold_pct": 10.0, "stale_max_days_close": 3, "stale_max_minutes_intraday": 30}, "fx_quotes": [], "task_kind": "PRICE_REFRESH", "portfolio_id": "11443291-4e86-4a9c-9ea4-c9f7040ae16e", "price_quotes": [{"as_of": "2026-03-11T09:56:16.705182+00:00", "price": "392.3100", "currency": "USD", "is_close": true, "listing_id": "88535377-562e-4c57-86af-3113c6acf175"}, {"as_of": "2026-03-11T09:56:16.705182+00:00", "price": "393.1807", "currency": "USD", "is_close": false, "listing_id": "88535377-562e-4c57-86af-3113c6acf175"}]}		2026-03-11 09:56:16.722027+00
853a95f5-2694-4989-ae1c-eb07229a54ab	{"job_id": "abd412c4-0ba8-4381-8bf5-0e887bd53122", "listings": ["88535377-562e-4c57-86af-3113c6acf175"], "provider": "mock", "dq_config": {"require_close": true, "fx_stale_max_days": 3, "jump_threshold_pct": 10.0, "stale_max_days_close": 3, "stale_max_minutes_intraday": 30}, "fx_quotes": [], "task_kind": "PRICE_REFRESH", "portfolio_id": "11443291-4e86-4a9c-9ea4-c9f7040ae16e", "price_quotes": [{"as_of": "2026-03-11T09:56:17.626513+00:00", "price": "392.3100", "currency": "USD", "is_close": true, "listing_id": "88535377-562e-4c57-86af-3113c6acf175"}, {"as_of": "2026-03-11T09:56:17.626513+00:00", "price": "393.1807", "currency": "USD", "is_close": false, "listing_id": "88535377-562e-4c57-86af-3113c6acf175"}]}		2026-03-11 09:56:17.625041+00
ba37f47d-ef20-47fc-8158-044c21c534a8	{"job_id": "ca0df5c0-f660-402e-9278-6ce183cb87f7", "listings": ["88535377-562e-4c57-86af-3113c6acf175"], "provider": "mock", "dq_config": {"require_close": true, "fx_stale_max_days": 3, "jump_threshold_pct": 10.0, "stale_max_days_close": 3, "stale_max_minutes_intraday": 30}, "fx_quotes": [], "task_kind": "PRICE_REFRESH", "portfolio_id": "11443291-4e86-4a9c-9ea4-c9f7040ae16e", "price_quotes": [{"as_of": "2026-03-11T09:56:19.870754+00:00", "price": "392.3100", "currency": "USD", "is_close": true, "listing_id": "88535377-562e-4c57-86af-3113c6acf175"}, {"as_of": "2026-03-11T09:56:19.870754+00:00", "price": "393.1807", "currency": "USD", "is_close": false, "listing_id": "88535377-562e-4c57-86af-3113c6acf175"}]}		2026-03-11 09:56:19.869897+00
dff304c4-13ce-453d-a361-27996afa6a20	{"job_id": "cc65cfb0-86e6-4ae2-8641-35bb9e6c6a1b", "listings": [], "provider": "mock", "dq_config": {"require_close": true, "fx_stale_max_days": 3, "jump_threshold_pct": 10.0, "stale_max_days_close": 3, "stale_max_minutes_intraday": 30}, "fx_quotes": [], "task_kind": "PRICE_REFRESH", "portfolio_id": "0dbb642d-ce67-4752-b6e3-6242d8c69d72", "price_quotes": []}		2026-03-11 13:31:23.295827+00
ba09fe8f-dcc7-4693-8c41-ee6ad794b888	{"job_id": "dac506a2-3859-43d2-980c-e25dc3ff9d35", "listings": [], "provider": "mock", "dq_config": {"require_close": true, "fx_stale_max_days": 3, "jump_threshold_pct": 10.0, "stale_max_days_close": 3, "stale_max_minutes_intraday": 30}, "fx_quotes": [], "task_kind": "PRICE_REFRESH", "portfolio_id": "0dbb642d-ce67-4752-b6e3-6242d8c69d72", "price_quotes": []}		2026-03-11 13:31:24.334098+00
fec47a6b-d82e-49d0-8986-15e16ccba297	{"job_id": "2b228f7e-ce2b-484b-8923-0089cc9d0769", "listings": [], "provider": "mock", "dq_config": {"require_close": true, "fx_stale_max_days": 3, "jump_threshold_pct": 10.0, "stale_max_days_close": 3, "stale_max_minutes_intraday": 30}, "fx_quotes": [], "task_kind": "PRICE_REFRESH", "portfolio_id": "0dbb642d-ce67-4752-b6e3-6242d8c69d72", "price_quotes": []}		2026-03-11 13:31:25.08826+00
9451ad69-bcda-4a78-9e3a-27ad028434b7	{"job_id": "5a224fd2-1bba-4906-a6d9-9969bcb9dd6b", "listings": [], "provider": "mock", "dq_config": {"require_close": true, "fx_stale_max_days": 3, "jump_threshold_pct": 10.0, "stale_max_days_close": 3, "stale_max_minutes_intraday": 30}, "fx_quotes": [], "task_kind": "PRICE_REFRESH", "portfolio_id": "0dbb642d-ce67-4752-b6e3-6242d8c69d72", "price_quotes": []}		2026-03-11 17:30:26.337757+00
3e74ba72-be8a-47e1-a708-0657f537f8a7	{"job_id": "ace686e3-ac52-4886-bb11-02f4be23096e", "listings": [], "provider": "mock", "dq_config": {"require_close": true, "fx_stale_max_days": 3, "jump_threshold_pct": 10.0, "stale_max_days_close": 3, "stale_max_minutes_intraday": 30}, "fx_quotes": [], "task_kind": "PRICE_REFRESH", "portfolio_id": "0dbb642d-ce67-4752-b6e3-6242d8c69d72", "price_quotes": []}		2026-03-11 17:30:37.353841+00
9832986c-482e-4232-a1fc-92993fcee336	{"job_id": "542a315d-0a22-4375-9ca8-3be5017bcdf6", "listings": [], "provider": "mock", "dq_config": {"require_close": true, "fx_stale_max_days": 3, "jump_threshold_pct": 10.0, "stale_max_days_close": 3, "stale_max_minutes_intraday": 30}, "fx_quotes": [], "task_kind": "PRICE_REFRESH", "portfolio_id": "0dbb642d-ce67-4752-b6e3-6242d8c69d72", "price_quotes": []}		2026-03-11 17:30:38.310546+00
bf8cff12-5430-4400-862d-fb1e1e44a185	{"job_id": "9319270f-7b17-4442-9d60-e351f732b838", "listings": [], "provider": "mock", "dq_config": {"require_close": true, "fx_stale_max_days": 3, "jump_threshold_pct": 10.0, "stale_max_days_close": 3, "stale_max_minutes_intraday": 30}, "fx_quotes": [], "task_kind": "PRICE_REFRESH", "portfolio_id": "0dbb642d-ce67-4752-b6e3-6242d8c69d72", "price_quotes": []}		2026-03-11 17:32:11.840909+00
b8810725-8081-45e9-a9ce-560280f8778c	{"job_id": "08254f4e-c461-48a5-a63c-26c32a9b2ee2", "listings": [], "provider": "mock", "dq_config": {"require_close": true, "fx_stale_max_days": 3, "jump_threshold_pct": 10.0, "stale_max_days_close": 3, "stale_max_minutes_intraday": 30}, "fx_quotes": [], "task_kind": "PRICE_REFRESH", "portfolio_id": "0dbb642d-ce67-4752-b6e3-6242d8c69d72", "price_quotes": []}		2026-03-11 17:41:28.576671+00
f19cbe3c-c0f5-4b1b-a1f3-66943abc688e	{"job_id": "68c344ce-0a70-4840-b7ac-8ae2cff41d37", "listings": [], "provider": "mock", "dq_config": {"require_close": true, "fx_stale_max_days": 3, "jump_threshold_pct": 10.0, "stale_max_days_close": 3, "stale_max_minutes_intraday": 30}, "fx_quotes": [], "task_kind": "PRICE_REFRESH", "portfolio_id": "0dbb642d-ce67-4752-b6e3-6242d8c69d72", "price_quotes": []}		2026-03-11 17:41:29.908492+00
b4a5e210-f9ff-402d-87f6-e76f1cdba9a9	{"job_id": "95b6c7ba-794d-46ce-a06f-319c17150621", "listings": [], "provider": "mock", "dq_config": {"require_close": true, "fx_stale_max_days": 3, "jump_threshold_pct": 10.0, "stale_max_days_close": 3, "stale_max_minutes_intraday": 30}, "fx_quotes": [], "task_kind": "PRICE_REFRESH", "portfolio_id": "0dbb642d-ce67-4752-b6e3-6242d8c69d72", "price_quotes": []}		2026-03-11 17:41:30.630899+00
82b11ef7-63d6-4a5c-bb98-1b30f384af39	{"job_id": "e57a8a9a-6b4e-449f-81de-1077ca6694ac", "listings": [], "provider": "mock", "dq_config": {"require_close": true, "fx_stale_max_days": 3, "jump_threshold_pct": 10.0, "stale_max_days_close": 3, "stale_max_minutes_intraday": 30}, "fx_quotes": [], "task_kind": "PRICE_REFRESH", "portfolio_id": "0dbb642d-ce67-4752-b6e3-6242d8c69d72", "price_quotes": []}		2026-03-11 17:41:31.155865+00
83229c20-4fb5-47e7-bad6-12a94f0c1551	{"job_id": "419779ea-8d24-41ab-acbb-2886dce18950", "listings": [], "provider": "mock", "dq_config": {"require_close": true, "fx_stale_max_days": 3, "jump_threshold_pct": 10.0, "stale_max_days_close": 3, "stale_max_minutes_intraday": 30}, "fx_quotes": [], "task_kind": "PRICE_REFRESH", "portfolio_id": "0dbb642d-ce67-4752-b6e3-6242d8c69d72", "price_quotes": []}		2026-03-11 17:41:31.373088+00
82667c5c-9922-42bd-b374-40b43533a7c0	{"job_id": "0fde592e-5a83-4770-bf67-a1e65f534176", "listings": [], "provider": "mock", "dq_config": {"require_close": true, "fx_stale_max_days": 3, "jump_threshold_pct": 10.0, "stale_max_days_close": 3, "stale_max_minutes_intraday": 30}, "fx_quotes": [], "task_kind": "PRICE_REFRESH", "portfolio_id": "0dbb642d-ce67-4752-b6e3-6242d8c69d72", "price_quotes": []}		2026-03-11 17:41:31.564564+00
4b909e88-81ac-4a2f-83dc-4d9291311428	{"job_id": "f82fa981-6311-438b-8b3d-84a956fb91fe", "listings": [], "provider": "mock", "dq_config": {"require_close": true, "fx_stale_max_days": 3, "jump_threshold_pct": 10.0, "stale_max_days_close": 3, "stale_max_minutes_intraday": 30}, "fx_quotes": [], "task_kind": "PRICE_REFRESH", "portfolio_id": "0dbb642d-ce67-4752-b6e3-6242d8c69d72", "price_quotes": []}		2026-03-11 17:42:22.254628+00
2c9080d4-9d4d-45d9-8b90-be2c4f4f636e	{"job_id": "d7ca3fee-f74c-49ea-a484-0621d26f3c66", "listings": [], "provider": "mock", "dq_config": {"require_close": true, "fx_stale_max_days": 3, "jump_threshold_pct": 10.0, "stale_max_days_close": 3, "stale_max_minutes_intraday": 30}, "fx_quotes": [], "task_kind": "PRICE_REFRESH", "portfolio_id": "0dbb642d-ce67-4752-b6e3-6242d8c69d72", "price_quotes": []}		2026-03-11 17:42:23.410209+00
7aae5bb4-ffc3-4cbe-b5d9-b47fb22f5970	{"job_id": "7852be57-a415-4be1-8199-4a5c2111199e", "listings": [], "provider": "mock", "dq_config": {"require_close": true, "fx_stale_max_days": 3, "jump_threshold_pct": 10.0, "stale_max_days_close": 3, "stale_max_minutes_intraday": 30}, "fx_quotes": [], "task_kind": "PRICE_REFRESH", "portfolio_id": "0dbb642d-ce67-4752-b6e3-6242d8c69d72", "price_quotes": []}		2026-03-11 17:42:23.993296+00
b0d3bf53-fd11-4151-9aba-fa00320a3ef1	{"job_id": "3b49a601-8fe3-4043-a292-b8e7c88d389a", "listings": [], "provider": "mock", "dq_config": {"require_close": true, "fx_stale_max_days": 3, "jump_threshold_pct": 10.0, "stale_max_days_close": 3, "stale_max_minutes_intraday": 30}, "fx_quotes": [], "task_kind": "PRICE_REFRESH", "portfolio_id": "0dbb642d-ce67-4752-b6e3-6242d8c69d72", "price_quotes": []}		2026-03-11 17:42:24.162006+00
6d9dcdc3-5481-48ef-84d9-cc3c84b6ba45	{"job_id": "b3b380b2-e0e9-45e3-87bb-8cea903db6e3", "listings": [], "provider": "mock", "dq_config": {"require_close": true, "fx_stale_max_days": 3, "jump_threshold_pct": 10.0, "stale_max_days_close": 3, "stale_max_minutes_intraday": 30}, "fx_quotes": [], "task_kind": "PRICE_REFRESH", "portfolio_id": "0dbb642d-ce67-4752-b6e3-6242d8c69d72", "price_quotes": []}		2026-03-11 17:42:43.118915+00
0a28acb6-50be-4f80-a73a-ecbaf07ababf	{"job_id": "86b9d583-9537-46e6-9193-abbfa9ba6e92", "listings": [], "provider": "mock", "dq_config": {"require_close": true, "fx_stale_max_days": 3, "jump_threshold_pct": 10.0, "stale_max_days_close": 3, "stale_max_minutes_intraday": 30}, "fx_quotes": [], "task_kind": "PRICE_REFRESH", "portfolio_id": "0dbb642d-ce67-4752-b6e3-6242d8c69d72", "price_quotes": []}		2026-03-11 17:45:10.969083+00
0a4d44a3-def1-46df-948f-8dee2a23013b	{"job_id": "6c2e26ba-0faa-4101-9200-dd50033ed5e4", "listings": [], "provider": "mock", "dq_config": {"require_close": true, "fx_stale_max_days": 3, "jump_threshold_pct": 10.0, "stale_max_days_close": 3, "stale_max_minutes_intraday": 30}, "fx_quotes": [], "task_kind": "PRICE_REFRESH", "portfolio_id": "0dbb642d-ce67-4752-b6e3-6242d8c69d72", "price_quotes": []}		2026-03-11 17:46:52.875102+00
c549f24c-fe46-4b5b-b2a8-54666c7f44ba	{"job_id": "9254be94-1051-47c3-a303-3080bc88b1b4", "listings": [], "provider": "mock", "dq_config": {"require_close": true, "fx_stale_max_days": 3, "jump_threshold_pct": 10.0, "stale_max_days_close": 3, "stale_max_minutes_intraday": 30}, "fx_quotes": [], "task_kind": "PRICE_REFRESH", "portfolio_id": "0dbb642d-ce67-4752-b6e3-6242d8c69d72", "price_quotes": []}		2026-03-11 17:47:05.801423+00
\.


--
-- TOC entry 3679 (class 0 OID 18387)
-- Dependencies: 221
-- Data for Name: sleeves; Type: TABLE DATA; Schema: public; Owner: ta_app
--

COPY public.sleeves (sleeve_code, name) FROM stdin;
CORE	Core Sleeve
\.


--
-- TOC entry 3687 (class 0 OID 18499)
-- Dependencies: 229
-- Data for Name: task_runs; Type: TABLE DATA; Schema: public; Owner: ta_app
--

COPY public.task_runs (run_id, job_id, task_kind, portfolio_id, status, started_at, ended_at, summary) FROM stdin;
466da843-e08e-4ce9-9396-b1c084cc72da	dfe3c4ae-17a0-4ae3-af81-40cffc79b985	PRICE_REFRESH	a9136ac7-2cd4-43db-be99-f4fb545b5ec1	FAILED	2026-02-28 00:54:26.737813+00	2026-02-28 00:54:26.771354+00	{"error": "(psycopg2.errors.ForeignKeyViolation) insert or update on table \\"run_input_snapshots\\" violates foreign key constraint \\"run_input_snapshots_run_id_fkey\\"\\nDETAIL:  Key (run_id)=(466da843-e08e-4ce9-9396-b1c084cc72da) is not present in table \\"task_runs\\".\\n\\n[SQL: INSERT INTO run_input_snapshots (run_id, input_json, input_hash) VALUES (%(run_id)s::UUID, %(input_json)s::JSONB, %(input_hash)s) RETURNING run_input_snapshots.created_at]\\n[parameters: {'run_id': UUID('466da843-e08e-4ce9-9396-b1c084cc72da'), 'input_json': '{\\"portfolio_id\\": \\"a9136ac7-2cd4-43db-be99-f4fb545b5ec1\\", \\"job_id\\": \\"dfe3c4ae-17a0-4ae3-af81-40cffc79b985\\", \\"task_kind\\": \\"PRICE_REFRESH\\", \\"provider\\":  ... (62 characters truncated) ... _max_days_close\\": 3, \\"jump_threshold_pct\\": 10.0, \\"require_close\\": true, \\"fx_stale_max_days\\": 3}, \\"listings\\": [], \\"price_quotes\\": [], \\"fx_quotes\\": []}', 'input_hash': ''}]\\n(Background on this error at: https://sqlalche.me/e/20/gkpj)", "error_type": "IntegrityError"}
8b8207b3-ab54-4264-8b6b-ffa7b6e3b6c8	cda4f96b-1886-4194-a825-088e06f1f6ce	PRICE_REFRESH	a9136ac7-2cd4-43db-be99-f4fb545b5ec1	SUCCESS	2026-02-28 00:55:42.989837+00	2026-02-28 00:55:43.011517+00	{"errors": ["No monitored constituents found"], "fx_fetched": 0, "violations": 0, "fx_inserted": 0, "prices_fetched": 0, "prices_inserted": 0, "critical_violations": 0}
3f0887cb-e86e-4a9d-90bb-c7b6a8ed6316	d91f941a-54a4-4f8a-9301-b9a11763e60a	PRICE_REFRESH	e675105a-f954-4553-b993-fb77527d620f	SUCCESS	2026-03-09 22:51:50.815498+00	2026-03-09 22:51:50.850786+00	{"errors": [], "fx_fetched": 0, "violations": 0, "fx_inserted": 0, "prices_fetched": 2, "prices_inserted": 2, "critical_violations": 0}
b3519ea4-baac-44f4-a9ae-3d051c9a8866	fd7e73ad-5666-44a2-b2ce-c18c77d40c4d	PRICE_REFRESH	e5fa701e-6756-4a03-ac4f-052407357964	SUCCESS	2026-03-09 22:53:33.919442+00	2026-03-09 22:53:33.925081+00	{"errors": [], "fx_fetched": 0, "violations": 0, "fx_inserted": 0, "prices_fetched": 2, "prices_inserted": 2, "critical_violations": 0}
c0f1461a-7cf8-4f66-b735-c7f93702c323	0b1ea7b5-c49e-474d-96e1-6a73bafc78de	PRICE_REFRESH	11443291-4e86-4a9c-9ea4-c9f7040ae16e	FROZEN	2026-03-11 09:56:16.676005+00	2026-03-11 09:56:16.725833+00	{"errors": [], "fx_fetched": 0, "violations": 1, "fx_inserted": 0, "prices_fetched": 2, "prices_inserted": 2, "critical_violations": 1}
853a95f5-2694-4989-ae1c-eb07229a54ab	abd412c4-0ba8-4381-8bf5-0e887bd53122	PRICE_REFRESH	11443291-4e86-4a9c-9ea4-c9f7040ae16e	FROZEN	2026-03-11 09:56:17.624349+00	2026-03-11 09:56:17.631818+00	{"errors": [], "fx_fetched": 0, "violations": 1, "fx_inserted": 0, "prices_fetched": 2, "prices_inserted": 2, "critical_violations": 1}
ba37f47d-ef20-47fc-8158-044c21c534a8	ca0df5c0-f660-402e-9278-6ce183cb87f7	PRICE_REFRESH	11443291-4e86-4a9c-9ea4-c9f7040ae16e	FROZEN	2026-03-11 09:56:19.869064+00	2026-03-11 09:56:19.874385+00	{"errors": [], "fx_fetched": 0, "violations": 1, "fx_inserted": 0, "prices_fetched": 2, "prices_inserted": 2, "critical_violations": 1}
dff304c4-13ce-453d-a361-27996afa6a20	cc65cfb0-86e6-4ae2-8641-35bb9e6c6a1b	PRICE_REFRESH	0dbb642d-ce67-4752-b6e3-6242d8c69d72	SUCCESS	2026-03-11 13:31:23.268795+00	2026-03-11 13:31:23.30192+00	{"errors": ["No monitored constituents found"], "fx_fetched": 0, "violations": 0, "fx_inserted": 0, "prices_fetched": 0, "prices_inserted": 0, "critical_violations": 0}
ba09fe8f-dcc7-4693-8c41-ee6ad794b888	dac506a2-3859-43d2-980c-e25dc3ff9d35	PRICE_REFRESH	0dbb642d-ce67-4752-b6e3-6242d8c69d72	SUCCESS	2026-03-11 13:31:24.333182+00	2026-03-11 13:31:24.336098+00	{"errors": ["No monitored constituents found"], "fx_fetched": 0, "violations": 0, "fx_inserted": 0, "prices_fetched": 0, "prices_inserted": 0, "critical_violations": 0}
fec47a6b-d82e-49d0-8986-15e16ccba297	2b228f7e-ce2b-484b-8923-0089cc9d0769	PRICE_REFRESH	0dbb642d-ce67-4752-b6e3-6242d8c69d72	SUCCESS	2026-03-11 13:31:25.087598+00	2026-03-11 13:31:25.090469+00	{"errors": ["No monitored constituents found"], "fx_fetched": 0, "violations": 0, "fx_inserted": 0, "prices_fetched": 0, "prices_inserted": 0, "critical_violations": 0}
9451ad69-bcda-4a78-9e3a-27ad028434b7	5a224fd2-1bba-4906-a6d9-9969bcb9dd6b	PRICE_REFRESH	0dbb642d-ce67-4752-b6e3-6242d8c69d72	SUCCESS	2026-03-11 17:30:26.314371+00	2026-03-11 17:30:26.341894+00	{"errors": ["No monitored constituents found"], "fx_fetched": 0, "violations": 0, "fx_inserted": 0, "prices_fetched": 0, "prices_inserted": 0, "critical_violations": 0}
3e74ba72-be8a-47e1-a708-0657f537f8a7	ace686e3-ac52-4886-bb11-02f4be23096e	PRICE_REFRESH	0dbb642d-ce67-4752-b6e3-6242d8c69d72	SUCCESS	2026-03-11 17:30:37.352971+00	2026-03-11 17:30:37.356368+00	{"errors": ["No monitored constituents found"], "fx_fetched": 0, "violations": 0, "fx_inserted": 0, "prices_fetched": 0, "prices_inserted": 0, "critical_violations": 0}
9832986c-482e-4232-a1fc-92993fcee336	542a315d-0a22-4375-9ca8-3be5017bcdf6	PRICE_REFRESH	0dbb642d-ce67-4752-b6e3-6242d8c69d72	SUCCESS	2026-03-11 17:30:38.309952+00	2026-03-11 17:30:38.312886+00	{"errors": ["No monitored constituents found"], "fx_fetched": 0, "violations": 0, "fx_inserted": 0, "prices_fetched": 0, "prices_inserted": 0, "critical_violations": 0}
bf8cff12-5430-4400-862d-fb1e1e44a185	9319270f-7b17-4442-9d60-e351f732b838	PRICE_REFRESH	0dbb642d-ce67-4752-b6e3-6242d8c69d72	SUCCESS	2026-03-11 17:32:11.840196+00	2026-03-11 17:32:11.842425+00	{"errors": ["No monitored constituents found"], "fx_fetched": 0, "violations": 0, "fx_inserted": 0, "prices_fetched": 0, "prices_inserted": 0, "critical_violations": 0}
b8810725-8081-45e9-a9ce-560280f8778c	08254f4e-c461-48a5-a63c-26c32a9b2ee2	PRICE_REFRESH	0dbb642d-ce67-4752-b6e3-6242d8c69d72	SUCCESS	2026-03-11 17:41:28.576074+00	2026-03-11 17:41:28.579019+00	{"errors": ["No monitored constituents found"], "fx_fetched": 0, "violations": 0, "fx_inserted": 0, "prices_fetched": 0, "prices_inserted": 0, "critical_violations": 0}
f19cbe3c-c0f5-4b1b-a1f3-66943abc688e	68c344ce-0a70-4840-b7ac-8ae2cff41d37	PRICE_REFRESH	0dbb642d-ce67-4752-b6e3-6242d8c69d72	SUCCESS	2026-03-11 17:41:29.907795+00	2026-03-11 17:41:29.910611+00	{"errors": ["No monitored constituents found"], "fx_fetched": 0, "violations": 0, "fx_inserted": 0, "prices_fetched": 0, "prices_inserted": 0, "critical_violations": 0}
b4a5e210-f9ff-402d-87f6-e76f1cdba9a9	95b6c7ba-794d-46ce-a06f-319c17150621	PRICE_REFRESH	0dbb642d-ce67-4752-b6e3-6242d8c69d72	SUCCESS	2026-03-11 17:41:30.630295+00	2026-03-11 17:41:30.633121+00	{"errors": ["No monitored constituents found"], "fx_fetched": 0, "violations": 0, "fx_inserted": 0, "prices_fetched": 0, "prices_inserted": 0, "critical_violations": 0}
82b11ef7-63d6-4a5c-bb98-1b30f384af39	e57a8a9a-6b4e-449f-81de-1077ca6694ac	PRICE_REFRESH	0dbb642d-ce67-4752-b6e3-6242d8c69d72	SUCCESS	2026-03-11 17:41:31.155094+00	2026-03-11 17:41:31.158912+00	{"errors": ["No monitored constituents found"], "fx_fetched": 0, "violations": 0, "fx_inserted": 0, "prices_fetched": 0, "prices_inserted": 0, "critical_violations": 0}
83229c20-4fb5-47e7-bad6-12a94f0c1551	419779ea-8d24-41ab-acbb-2886dce18950	PRICE_REFRESH	0dbb642d-ce67-4752-b6e3-6242d8c69d72	SUCCESS	2026-03-11 17:41:31.372165+00	2026-03-11 17:41:31.375093+00	{"errors": ["No monitored constituents found"], "fx_fetched": 0, "violations": 0, "fx_inserted": 0, "prices_fetched": 0, "prices_inserted": 0, "critical_violations": 0}
82667c5c-9922-42bd-b374-40b43533a7c0	0fde592e-5a83-4770-bf67-a1e65f534176	PRICE_REFRESH	0dbb642d-ce67-4752-b6e3-6242d8c69d72	SUCCESS	2026-03-11 17:41:31.563792+00	2026-03-11 17:41:31.566115+00	{"errors": ["No monitored constituents found"], "fx_fetched": 0, "violations": 0, "fx_inserted": 0, "prices_fetched": 0, "prices_inserted": 0, "critical_violations": 0}
4b909e88-81ac-4a2f-83dc-4d9291311428	f82fa981-6311-438b-8b3d-84a956fb91fe	PRICE_REFRESH	0dbb642d-ce67-4752-b6e3-6242d8c69d72	SUCCESS	2026-03-11 17:42:22.229655+00	2026-03-11 17:42:22.259052+00	{"errors": ["No monitored constituents found"], "fx_fetched": 0, "violations": 0, "fx_inserted": 0, "prices_fetched": 0, "prices_inserted": 0, "critical_violations": 0}
2c9080d4-9d4d-45d9-8b90-be2c4f4f636e	d7ca3fee-f74c-49ea-a484-0621d26f3c66	PRICE_REFRESH	0dbb642d-ce67-4752-b6e3-6242d8c69d72	SUCCESS	2026-03-11 17:42:23.409455+00	2026-03-11 17:42:23.412564+00	{"errors": ["No monitored constituents found"], "fx_fetched": 0, "violations": 0, "fx_inserted": 0, "prices_fetched": 0, "prices_inserted": 0, "critical_violations": 0}
7aae5bb4-ffc3-4cbe-b5d9-b47fb22f5970	7852be57-a415-4be1-8199-4a5c2111199e	PRICE_REFRESH	0dbb642d-ce67-4752-b6e3-6242d8c69d72	SUCCESS	2026-03-11 17:42:23.992311+00	2026-03-11 17:42:23.995563+00	{"errors": ["No monitored constituents found"], "fx_fetched": 0, "violations": 0, "fx_inserted": 0, "prices_fetched": 0, "prices_inserted": 0, "critical_violations": 0}
b0d3bf53-fd11-4151-9aba-fa00320a3ef1	3b49a601-8fe3-4043-a292-b8e7c88d389a	PRICE_REFRESH	0dbb642d-ce67-4752-b6e3-6242d8c69d72	SUCCESS	2026-03-11 17:42:24.161426+00	2026-03-11 17:42:24.164558+00	{"errors": ["No monitored constituents found"], "fx_fetched": 0, "violations": 0, "fx_inserted": 0, "prices_fetched": 0, "prices_inserted": 0, "critical_violations": 0}
6d9dcdc3-5481-48ef-84d9-cc3c84b6ba45	b3b380b2-e0e9-45e3-87bb-8cea903db6e3	PRICE_REFRESH	0dbb642d-ce67-4752-b6e3-6242d8c69d72	SUCCESS	2026-03-11 17:42:43.118313+00	2026-03-11 17:42:43.121358+00	{"errors": ["No monitored constituents found"], "fx_fetched": 0, "violations": 0, "fx_inserted": 0, "prices_fetched": 0, "prices_inserted": 0, "critical_violations": 0}
0a28acb6-50be-4f80-a73a-ecbaf07ababf	86b9d583-9537-46e6-9193-abbfa9ba6e92	PRICE_REFRESH	0dbb642d-ce67-4752-b6e3-6242d8c69d72	SUCCESS	2026-03-11 17:45:10.968071+00	2026-03-11 17:45:10.971178+00	{"errors": ["No monitored constituents found"], "fx_fetched": 0, "violations": 0, "fx_inserted": 0, "prices_fetched": 0, "prices_inserted": 0, "critical_violations": 0}
0a4d44a3-def1-46df-948f-8dee2a23013b	6c2e26ba-0faa-4101-9200-dd50033ed5e4	PRICE_REFRESH	0dbb642d-ce67-4752-b6e3-6242d8c69d72	SUCCESS	2026-03-11 17:46:52.87413+00	2026-03-11 17:46:52.877417+00	{"errors": ["No monitored constituents found"], "fx_fetched": 0, "violations": 0, "fx_inserted": 0, "prices_fetched": 0, "prices_inserted": 0, "critical_violations": 0}
c549f24c-fe46-4b5b-b2a8-54666c7f44ba	9254be94-1051-47c3-a303-3080bc88b1b4	PRICE_REFRESH	0dbb642d-ce67-4752-b6e3-6242d8c69d72	SUCCESS	2026-03-11 17:47:05.80068+00	2026-03-11 17:47:05.804025+00	{"errors": ["No monitored constituents found"], "fx_fetched": 0, "violations": 0, "fx_inserted": 0, "prices_fetched": 0, "prices_inserted": 0, "critical_violations": 0}
\.


--
-- TOC entry 3677 (class 0 OID 18369)
-- Dependencies: 219
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: ta_app
--

COPY public."user" (user_id, email, password_hash, is_enabled, is_bootstrap_admin, created_at, last_login_at) FROM stdin;
501270c9-28bd-47e5-aaad-329f27096366	test@example.com	hash	t	f	2026-02-28 00:42:35.720158+00	\N
8a813388-0c62-4f17-aa1c-3b602e70092b	test_8bd75087@example.com	hashed_password_for_tests	t	f	2026-03-11 12:27:45.828492+00	\N
3b7976b0-d52c-4cd3-8b98-e5d1ed0e94ea	test_3d2fdc8c@example.com	hashed_password_for_tests	t	f	2026-03-11 12:27:45.880346+00	\N
05c894d8-502e-4e36-be45-fee805b83e9a	admin@example.com	$2b$12$FywNH3d1fvj0OjxHj6QK9e/kWksaaZL8rticsIfpw8XSlbKykQ7Am	t	t	2026-03-09 17:03:57.443557+00	2026-03-11 20:04:54.136488+00
fbc1e175-c1bc-40f4-bba6-71f9e99a3ebd	test_b35ddac0@example.com	hashed_password_for_tests	t	f	2026-03-11 12:27:45.935551+00	\N
9bd76d1b-3e07-4a2f-b936-b79861f5ba91	test_e3e9dfd4@example.com	hashed_password_for_tests	t	f	2026-03-11 12:27:45.958283+00	\N
145ec58c-de7d-40f1-bcbc-b6060dc18040	test_ac25b3fd@example.com	hashed_password_for_tests	t	f	2026-03-11 12:27:45.985074+00	\N
dd9c30f1-b6ad-4a0f-b8f3-8a0719abf03e	test_090f8038@example.com	hashed_password_for_tests	t	f	2026-03-11 12:43:01.941233+00	\N
d65382bc-34fd-479b-b047-14bc22ae7335	test_6e833570@example.com	hashed_password_for_tests	t	f	2026-03-11 12:43:02.00592+00	\N
e9d70044-c427-4ef4-82a4-e721b416f78d	test_820c4c37@example.com	hashed_password_for_tests	t	f	2026-03-11 12:43:02.069763+00	\N
45b4d902-920f-4a91-9744-7f2e1beb5252	test_9fd4e53e@example.com	hashed_password_for_tests	t	f	2026-03-11 12:43:02.102573+00	\N
4247a152-86cc-4a78-a175-2e2f06030fdb	test_20ee72a1@example.com	hashed_password_for_tests	t	f	2026-03-11 12:43:02.136086+00	\N
10200d2b-8409-4d84-8a84-c1a4aafdfa39	test_190f6e9d@example.com	hashed_password_for_tests	t	f	2026-03-11 13:21:30.056461+00	\N
ebd906ba-147e-49c2-87fb-3b1b0a2e1bc4	test_698a50f8@example.com	hashed_password_for_tests	t	f	2026-03-11 13:21:30.12512+00	\N
f2da46a6-3b53-4840-8d7a-ae1412b69ac3	test_1fbc6bc6@example.com	hashed_password_for_tests	t	f	2026-03-11 13:21:30.1785+00	\N
f547834e-70cd-4fad-a15a-55ce979266ae	test_dc38aaeb@example.com	hashed_password_for_tests	t	f	2026-03-11 13:21:30.202678+00	\N
d0e75dfe-af89-45e2-bd7c-68aa041f4e30	test_7594c580@example.com	hashed_password_for_tests	t	f	2026-03-11 12:25:32.34521+00	\N
01762b64-dd4a-448f-8305-e41c8c882947	test_998a0533@example.com	hashed_password_for_tests	t	f	2026-03-11 12:25:32.425001+00	\N
fe586e05-d38d-42d9-8df7-7cecb92e167d	test_87e77d2f@example.com	hashed_password_for_tests	t	f	2026-03-11 13:21:30.231402+00	\N
a8b5dcc3-6178-4868-aa31-bebb613140e2	test_e22717e8@example.com	hashed_password_for_tests	t	f	2026-03-11 18:53:38.067136+00	\N
e7823a62-30c3-4632-a063-11c534d11d67	test_0bbbd8b1@example.com	hashed_password_for_tests	t	f	2026-03-11 18:53:38.109266+00	\N
fe25ddf8-7970-424f-bdd0-eb1d05149f85	test_c3cfa1c2@example.com	hashed_password_for_tests	t	f	2026-03-11 18:53:38.16158+00	\N
4b13ca50-31ae-484c-bc16-3eb9c02262d4	test_ac4ca6a4@example.com	hashed_password_for_tests	t	f	2026-03-11 12:25:32.483173+00	\N
c36e2855-ad1b-4e43-b5e6-ffec0a6daf3d	test_c0c9f123@example.com	hashed_password_for_tests	t	f	2026-03-11 12:25:32.50991+00	\N
d982c71c-2a08-4855-a309-1157db359c67	test_f2bb3667@example.com	hashed_password_for_tests	t	f	2026-03-11 12:25:32.560927+00	\N
bde794f6-c3c2-438c-9a5c-0c002f6cf3ae	test_c76375db@example.com	hashed_password_for_tests	t	f	2026-03-11 18:53:38.189743+00	\N
682531d6-b925-4292-9f54-6cc5badac794	test_c21bc884@example.com	hashed_password_for_tests	t	f	2026-03-11 18:53:38.217607+00	\N
2beaeb07-e3ff-4dcd-b93a-f67e5b9e4add	test_60b7937d@example.com	hashed_password_for_tests	t	f	2026-03-11 12:25:45.477506+00	\N
c9d85c7f-d8e1-42ec-a7cf-1736eea278f3	test_7b3e9d68@example.com	hashed_password_for_tests	t	f	2026-03-11 12:25:45.542261+00	\N
435adf4b-defe-4dd1-9be6-7169282c53a4	test_ee04b6b9@example.com	hashed_password_for_tests	t	f	2026-03-11 12:25:45.606522+00	\N
997a016a-b28b-4cbb-a992-5039a61f5f8c	test_656a55ec@example.com	hashed_password_for_tests	t	f	2026-03-11 12:25:45.635018+00	\N
8b9ad148-a867-44ef-b41f-708d8cd35bae	test_fbe47f29@example.com	hashed_password_for_tests	t	f	2026-03-11 12:25:45.667934+00	\N
e1c31a56-6764-401a-a41a-edde0987838c	test_522fee42@example.com	hashed_password_for_tests	t	f	2026-03-11 19:09:49.040345+00	\N
c1b4c536-21f6-4656-8b8c-5b4a6632f17e	test_28120fdd@example.com	hashed_password_for_tests	t	f	2026-03-11 19:09:49.080069+00	\N
3368d156-fe11-4a27-becb-654d13a1ccbb	test_f85b7409@example.com	hashed_password_for_tests	t	f	2026-03-11 19:09:49.131063+00	\N
08ac6bdc-41d7-47a6-8d52-029a5784e44a	test_7f1637e0@example.com	hashed_password_for_tests	t	f	2026-03-11 19:09:49.152074+00	\N
13233645-cc3b-4775-a084-531a085eda91	test_5ebccf8f@example.com	hashed_password_for_tests	t	f	2026-03-11 19:09:49.174935+00	\N
b3f19468-c33c-4123-83ed-fc388d61d7a6	test_e6911b13@example.com	hashed_password_for_tests	t	f	2026-03-11 19:17:00.285439+00	\N
aa4e1960-7d43-46b6-ae8d-b184cdb470bd	test_8b5b2459@example.com	hashed_password_for_tests	t	f	2026-03-11 19:17:48.228741+00	\N
286a21d8-bda0-45dc-aaf1-40da26b918e4	test_b50c9db3@example.com	hashed_password_for_tests	t	f	2026-03-11 19:17:48.321446+00	\N
0842f730-0598-4271-93d5-6766297f29b1	test_47048a37@example.com	hashed_password_for_tests	t	f	2026-03-11 19:17:48.357705+00	\N
1420911d-1722-4d2f-a969-6343dbfb6d1a	test_f7b7a641@example.com	hashed_password_for_tests	t	f	2026-03-11 19:17:48.389445+00	\N
bb694a18-6764-46e4-9179-5e4abed2e56c	test_f3fe45ea@example.com	hashed_password_for_tests	t	f	2026-03-11 19:17:48.436339+00	\N
4ce26850-3328-4740-bf90-af1ab619843a	test_6b1257ee@example.com	hashed_password_for_tests	t	f	2026-03-11 19:17:48.47551+00	\N
26f38a7d-33c8-4aa7-b67e-8c3cc0a73d34	test_17841efe@example.com	hashed_password_for_tests	t	f	2026-03-11 19:17:48.501139+00	\N
617d97e3-47de-4f17-a9b4-36a0c79cb98f	test_814c8388@example.com	hashed_password_for_tests	t	f	2026-03-11 19:17:48.529233+00	\N
2d5b130b-0af0-4add-a686-030d576ca9d2	test_523777c0@example.com	hashed_password_for_tests	t	f	2026-03-11 19:17:48.558326+00	\N
15589ed0-c73f-476a-9e00-d383b1e29033	test_9862d139@example.com	hashed_password_for_tests	t	f	2026-03-11 19:17:48.588378+00	\N
74883a77-453c-47db-bbb9-ead741b63dad	test_e2ef630e@example.com	hashed_password_for_tests	t	f	2026-03-11 19:17:48.623684+00	\N
947892d1-2fa4-45a6-92ca-f3c6202434ae	test_e9de1d60@example.com	hashed_password_for_tests	t	f	2026-03-11 19:17:56.17162+00	\N
5f2e082d-713d-4bd8-8cf3-233cb981b87d	test_8107bcae@example.com	hashed_password_for_tests	t	f	2026-03-11 19:17:56.2036+00	\N
0ba79a21-fded-4124-8d03-2da6f294590b	test_e8a33c22@example.com	hashed_password_for_tests	t	f	2026-03-11 19:17:56.265369+00	\N
3f96613f-61c5-4d15-b756-932765288c88	test_b926a730@example.com	hashed_password_for_tests	t	f	2026-03-11 19:17:56.294817+00	\N
940f7d38-5414-46af-9cfd-9a7e78b43795	test_ae426c31@example.com	hashed_password_for_tests	t	f	2026-03-11 19:17:56.32878+00	\N
18f8a6d4-7795-4380-9ebf-6ba112d8f799	test_01fb6f2a@example.com	hashed_password_for_tests	t	f	2026-03-11 19:17:56.354866+00	\N
d35f101b-7748-4535-b571-43a0e0e274d1	test_5f666143@example.com	hashed_password_for_tests	t	f	2026-03-11 19:17:56.401066+00	\N
3cca1d39-faa3-4a3d-9a6a-25302a708b28	test_fdf603bf@example.com	hashed_password_for_tests	t	f	2026-03-11 19:17:56.437699+00	\N
319b1561-136d-4601-a951-26d74f7a14ac	test_07d6efc7@example.com	hashed_password_for_tests	t	f	2026-03-11 19:17:56.483828+00	\N
ea2b69fc-f81a-4a08-bef2-943e826a5b81	test_a9f4663c@example.com	hashed_password_for_tests	t	f	2026-03-11 19:17:56.533009+00	\N
b966bdd3-4afb-4b49-96d8-1d380c788597	test_4b7e79ca@example.com	hashed_password_for_tests	t	f	2026-03-11 19:17:56.573005+00	\N
90060e1e-dd0b-4800-b269-6443db2fcc4a	test_3178ef8c@example.com	hashed_password_for_tests	t	f	2026-03-11 19:17:56.603301+00	\N
4bfbb8a0-d061-4c0d-88d3-965a3075226f	test_11ac0972@example.com	hashed_password_for_tests	t	f	2026-03-11 19:17:56.628115+00	\N
4c88a3a8-6115-4cb5-a7f2-ea357fc60567	test_5719cef7@example.com	hashed_password_for_tests	t	f	2026-03-11 19:17:56.665588+00	\N
b9cd736b-7715-41a1-8627-9cd7a458c6cf	test_8fbe3c72@example.com	hashed_password_for_tests	t	f	2026-03-11 19:17:56.700419+00	\N
e4050dcc-060b-4ef8-aa5e-e3f1c6a976b7	test_f201411f@example.com	hashed_password_for_tests	t	f	2026-03-11 19:17:56.74441+00	\N
\.


--
-- TOC entry 3675 (class 0 OID 16397)
-- Dependencies: 217
-- Data for Name: portfolios; Type: TABLE DATA; Schema: ta; Owner: ta_app
--

COPY ta.portfolios (portfolio_id, owner_user_id, name, base_currency, created_at) FROM stdin;
\.


--
-- TOC entry 3674 (class 0 OID 16386)
-- Dependencies: 216
-- Data for Name: users; Type: TABLE DATA; Schema: ta; Owner: ta_app
--

COPY ta.users (user_id, email, is_enabled, created_at) FROM stdin;
\.


--
-- TOC entry 3420 (class 2606 OID 16419)
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- TOC entry 3446 (class 2606 OID 18488)
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (alert_id);


--
-- TOC entry 3489 (class 2606 OID 26486)
-- Name: audit_events audit_events_pkey; Type: CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.audit_events
    ADD CONSTRAINT audit_events_pkey PRIMARY KEY (audit_event_id);


--
-- TOC entry 3464 (class 2606 OID 26333)
-- Name: cash_snapshots cash_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.cash_snapshots
    ADD CONSTRAINT cash_snapshots_pkey PRIMARY KEY (portfolio_id);


--
-- TOC entry 3477 (class 2606 OID 26419)
-- Name: execution_logs execution_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.execution_logs
    ADD CONSTRAINT execution_logs_pkey PRIMARY KEY (execution_log_id);


--
-- TOC entry 3450 (class 2606 OID 18517)
-- Name: freeze_states freeze_states_pkey; Type: CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.freeze_states
    ADD CONSTRAINT freeze_states_pkey PRIMARY KEY (freeze_id);


--
-- TOC entry 3430 (class 2606 OID 18401)
-- Name: fx_rates fx_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.fx_rates
    ADD CONSTRAINT fx_rates_pkey PRIMARY KEY (fx_rate_id);


--
-- TOC entry 3466 (class 2606 OID 26353)
-- Name: holding_snapshots holding_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.holding_snapshots
    ADD CONSTRAINT holding_snapshots_pkey PRIMARY KEY (portfolio_id, listing_id);


--
-- TOC entry 3425 (class 2606 OID 18385)
-- Name: instrument instrument_pkey; Type: CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.instrument
    ADD CONSTRAINT instrument_pkey PRIMARY KEY (instrument_id);


--
-- TOC entry 3455 (class 2606 OID 26278)
-- Name: ledger_batches ledger_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.ledger_batches
    ADD CONSTRAINT ledger_batches_pkey PRIMARY KEY (batch_id);


--
-- TOC entry 3462 (class 2606 OID 26299)
-- Name: ledger_entries ledger_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.ledger_entries
    ADD CONSTRAINT ledger_entries_pkey PRIMARY KEY (entry_id);


--
-- TOC entry 3436 (class 2606 OID 18424)
-- Name: listing listing_pkey; Type: CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.listing
    ADD CONSTRAINT listing_pkey PRIMARY KEY (listing_id);


--
-- TOC entry 3473 (class 2606 OID 26400)
-- Name: notification_configs notification_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.notification_configs
    ADD CONSTRAINT notification_configs_pkey PRIMARY KEY (notification_config_id);


--
-- TOC entry 3475 (class 2606 OID 26402)
-- Name: notification_configs notification_configs_portfolio_id_key; Type: CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.notification_configs
    ADD CONSTRAINT notification_configs_portfolio_id_key UNIQUE (portfolio_id);


--
-- TOC entry 3438 (class 2606 OID 18437)
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (notification_id);


--
-- TOC entry 3440 (class 2606 OID 18450)
-- Name: portfolio_constituent portfolio_constituent_pkey; Type: CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.portfolio_constituent
    ADD CONSTRAINT portfolio_constituent_pkey PRIMARY KEY (portfolio_id, listing_id);


--
-- TOC entry 3434 (class 2606 OID 18411)
-- Name: portfolio portfolio_pkey; Type: CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.portfolio
    ADD CONSTRAINT portfolio_pkey PRIMARY KEY (portfolio_id);


--
-- TOC entry 3468 (class 2606 OID 26378)
-- Name: portfolio_policy_allocations portfolio_policy_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.portfolio_policy_allocations
    ADD CONSTRAINT portfolio_policy_allocations_pkey PRIMARY KEY (portfolio_policy_allocation_id);


--
-- TOC entry 3442 (class 2606 OID 18473)
-- Name: price_points price_points_pkey; Type: CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.price_points
    ADD CONSTRAINT price_points_pkey PRIMARY KEY (price_point_id);


--
-- TOC entry 3485 (class 2606 OID 26434)
-- Name: recommendation_batches recommendation_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.recommendation_batches
    ADD CONSTRAINT recommendation_batches_pkey PRIMARY KEY (recommendation_batch_id);


--
-- TOC entry 3487 (class 2606 OID 26462)
-- Name: recommendation_lines recommendation_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.recommendation_lines
    ADD CONSTRAINT recommendation_lines_pkey PRIMARY KEY (recommendation_line_id);


--
-- TOC entry 3452 (class 2606 OID 18540)
-- Name: run_input_snapshots run_input_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.run_input_snapshots
    ADD CONSTRAINT run_input_snapshots_pkey PRIMARY KEY (run_id);


--
-- TOC entry 3428 (class 2606 OID 18393)
-- Name: sleeves sleeves_pkey; Type: CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.sleeves
    ADD CONSTRAINT sleeves_pkey PRIMARY KEY (sleeve_code);


--
-- TOC entry 3448 (class 2606 OID 18506)
-- Name: task_runs task_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.task_runs
    ADD CONSTRAINT task_runs_pkey PRIMARY KEY (run_id);


--
-- TOC entry 3432 (class 2606 OID 18403)
-- Name: fx_rates uq_fx_rate; Type: CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.fx_rates
    ADD CONSTRAINT uq_fx_rate UNIQUE (base_ccy, quote_ccy, as_of, source_id);


--
-- TOC entry 3444 (class 2606 OID 18475)
-- Name: price_points uq_price_point; Type: CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.price_points
    ADD CONSTRAINT uq_price_point UNIQUE (listing_id, as_of, source_id, is_close);


--
-- TOC entry 3423 (class 2606 OID 18376)
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (user_id);


--
-- TOC entry 3418 (class 2606 OID 16405)
-- Name: portfolios portfolios_pkey; Type: CONSTRAINT; Schema: ta; Owner: ta_app
--

ALTER TABLE ONLY ta.portfolios
    ADD CONSTRAINT portfolios_pkey PRIMARY KEY (portfolio_id);


--
-- TOC entry 3414 (class 2606 OID 16396)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: ta; Owner: ta_app
--

ALTER TABLE ONLY ta.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 3416 (class 2606 OID 16394)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: ta; Owner: ta_app
--

ALTER TABLE ONLY ta.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- TOC entry 3490 (class 1259 OID 26500)
-- Name: ix_audit_events_actor; Type: INDEX; Schema: public; Owner: ta_app
--

CREATE INDEX ix_audit_events_actor ON public.audit_events USING btree (actor_user_id, occurred_at DESC);


--
-- TOC entry 3491 (class 1259 OID 26499)
-- Name: ix_audit_events_entity; Type: INDEX; Schema: public; Owner: ta_app
--

CREATE INDEX ix_audit_events_entity ON public.audit_events USING btree (entity_type, entity_id, occurred_at DESC);


--
-- TOC entry 3492 (class 1259 OID 26497)
-- Name: ix_audit_events_event_type; Type: INDEX; Schema: public; Owner: ta_app
--

CREATE INDEX ix_audit_events_event_type ON public.audit_events USING btree (event_type);


--
-- TOC entry 3493 (class 1259 OID 26498)
-- Name: ix_audit_events_portfolio_occurred; Type: INDEX; Schema: public; Owner: ta_app
--

CREATE INDEX ix_audit_events_portfolio_occurred ON public.audit_events USING btree (portfolio_id, occurred_at DESC);


--
-- TOC entry 3478 (class 1259 OID 26420)
-- Name: ix_execution_logs_job_name; Type: INDEX; Schema: public; Owner: ta_app
--

CREATE INDEX ix_execution_logs_job_name ON public.execution_logs USING btree (job_name);


--
-- TOC entry 3479 (class 1259 OID 26422)
-- Name: ix_execution_logs_job_started; Type: INDEX; Schema: public; Owner: ta_app
--

CREATE INDEX ix_execution_logs_job_started ON public.execution_logs USING btree (job_name, started_at DESC);


--
-- TOC entry 3480 (class 1259 OID 26421)
-- Name: ix_execution_logs_status; Type: INDEX; Schema: public; Owner: ta_app
--

CREATE INDEX ix_execution_logs_status ON public.execution_logs USING btree (status);


--
-- TOC entry 3481 (class 1259 OID 26423)
-- Name: ix_execution_logs_status_started; Type: INDEX; Schema: public; Owner: ta_app
--

CREATE INDEX ix_execution_logs_status_started ON public.execution_logs USING btree (status, started_at DESC);


--
-- TOC entry 3426 (class 1259 OID 18386)
-- Name: ix_instrument_isin; Type: INDEX; Schema: public; Owner: ta_app
--

CREATE UNIQUE INDEX ix_instrument_isin ON public.instrument USING btree (isin);


--
-- TOC entry 3453 (class 1259 OID 26289)
-- Name: ix_ledger_batches_portfolio_created; Type: INDEX; Schema: public; Owner: ta_app
--

CREATE INDEX ix_ledger_batches_portfolio_created ON public.ledger_batches USING btree (portfolio_id, created_at) WHERE (portfolio_id IS NOT NULL);


--
-- TOC entry 3457 (class 1259 OID 26321)
-- Name: ix_ledger_entries_batch; Type: INDEX; Schema: public; Owner: ta_app
--

CREATE INDEX ix_ledger_entries_batch ON public.ledger_entries USING btree (batch_id);


--
-- TOC entry 3458 (class 1259 OID 26320)
-- Name: ix_ledger_entries_portfolio_effective; Type: INDEX; Schema: public; Owner: ta_app
--

CREATE INDEX ix_ledger_entries_portfolio_effective ON public.ledger_entries USING btree (portfolio_id, effective_at);


--
-- TOC entry 3459 (class 1259 OID 26322)
-- Name: ix_ledger_entries_portfolio_listing; Type: INDEX; Schema: public; Owner: ta_app
--

CREATE INDEX ix_ledger_entries_portfolio_listing ON public.ledger_entries USING btree (portfolio_id, listing_id, effective_at);


--
-- TOC entry 3460 (class 1259 OID 26323)
-- Name: ix_ledger_entries_reversal; Type: INDEX; Schema: public; Owner: ta_app
--

CREATE INDEX ix_ledger_entries_reversal ON public.ledger_entries USING btree (reversal_of_entry_id);


--
-- TOC entry 3470 (class 1259 OID 26409)
-- Name: ix_notification_configs_is_active; Type: INDEX; Schema: public; Owner: ta_app
--

CREATE INDEX ix_notification_configs_is_active ON public.notification_configs USING btree (is_active);


--
-- TOC entry 3471 (class 1259 OID 26408)
-- Name: ix_notification_configs_portfolio_id; Type: INDEX; Schema: public; Owner: ta_app
--

CREATE UNIQUE INDEX ix_notification_configs_portfolio_id ON public.notification_configs USING btree (portfolio_id);


--
-- TOC entry 3482 (class 1259 OID 26451)
-- Name: ix_recommendation_batches_generated; Type: INDEX; Schema: public; Owner: ta_app
--

CREATE INDEX ix_recommendation_batches_generated ON public.recommendation_batches USING btree (generated_at DESC);


--
-- TOC entry 3483 (class 1259 OID 26450)
-- Name: ix_recommendation_batches_portfolio_status; Type: INDEX; Schema: public; Owner: ta_app
--

CREATE INDEX ix_recommendation_batches_portfolio_status ON public.recommendation_batches USING btree (portfolio_id, status);


--
-- TOC entry 3421 (class 1259 OID 18377)
-- Name: ix_user_email; Type: INDEX; Schema: public; Owner: ta_app
--

CREATE UNIQUE INDEX ix_user_email ON public."user" USING btree (email);


--
-- TOC entry 3456 (class 1259 OID 26290)
-- Name: uq_ledger_batch_idempotency; Type: INDEX; Schema: public; Owner: ta_app
--

CREATE UNIQUE INDEX uq_ledger_batch_idempotency ON public.ledger_batches USING btree (portfolio_id, idempotency_key) WHERE (idempotency_key IS NOT NULL);


--
-- TOC entry 3469 (class 1259 OID 26389)
-- Name: uq_policy_allocation; Type: INDEX; Schema: public; Owner: ta_app
--

CREATE UNIQUE INDEX uq_policy_allocation ON public.portfolio_policy_allocations USING btree (portfolio_id, policy_hash, listing_id);


--
-- TOC entry 3502 (class 2606 OID 18494)
-- Name: alerts alerts_listing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES public.listing(listing_id);


--
-- TOC entry 3503 (class 2606 OID 18489)
-- Name: alerts alerts_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES public.portfolio(portfolio_id);


--
-- TOC entry 3529 (class 2606 OID 26492)
-- Name: audit_events audit_events_actor_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.audit_events
    ADD CONSTRAINT audit_events_actor_user_id_fkey FOREIGN KEY (actor_user_id) REFERENCES public."user"(user_id);


--
-- TOC entry 3530 (class 2606 OID 26487)
-- Name: audit_events audit_events_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.audit_events
    ADD CONSTRAINT audit_events_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES public.portfolio(portfolio_id);


--
-- TOC entry 3515 (class 2606 OID 26339)
-- Name: cash_snapshots cash_snapshots_last_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.cash_snapshots
    ADD CONSTRAINT cash_snapshots_last_entry_id_fkey FOREIGN KEY (last_entry_id) REFERENCES public.ledger_entries(entry_id);


--
-- TOC entry 3516 (class 2606 OID 26334)
-- Name: cash_snapshots cash_snapshots_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.cash_snapshots
    ADD CONSTRAINT cash_snapshots_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES public.portfolio(portfolio_id);


--
-- TOC entry 3505 (class 2606 OID 18528)
-- Name: freeze_states freeze_states_cleared_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.freeze_states
    ADD CONSTRAINT freeze_states_cleared_by_user_id_fkey FOREIGN KEY (cleared_by_user_id) REFERENCES public."user"(user_id);


--
-- TOC entry 3506 (class 2606 OID 18518)
-- Name: freeze_states freeze_states_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.freeze_states
    ADD CONSTRAINT freeze_states_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES public.portfolio(portfolio_id);


--
-- TOC entry 3507 (class 2606 OID 18523)
-- Name: freeze_states freeze_states_reason_alert_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.freeze_states
    ADD CONSTRAINT freeze_states_reason_alert_id_fkey FOREIGN KEY (reason_alert_id) REFERENCES public.alerts(alert_id);


--
-- TOC entry 3517 (class 2606 OID 26364)
-- Name: holding_snapshots holding_snapshots_last_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.holding_snapshots
    ADD CONSTRAINT holding_snapshots_last_entry_id_fkey FOREIGN KEY (last_entry_id) REFERENCES public.ledger_entries(entry_id);


--
-- TOC entry 3518 (class 2606 OID 26359)
-- Name: holding_snapshots holding_snapshots_listing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.holding_snapshots
    ADD CONSTRAINT holding_snapshots_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES public.listing(listing_id);


--
-- TOC entry 3519 (class 2606 OID 26354)
-- Name: holding_snapshots holding_snapshots_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.holding_snapshots
    ADD CONSTRAINT holding_snapshots_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES public.portfolio(portfolio_id);


--
-- TOC entry 3509 (class 2606 OID 26279)
-- Name: ledger_batches ledger_batches_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.ledger_batches
    ADD CONSTRAINT ledger_batches_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES public.portfolio(portfolio_id);


--
-- TOC entry 3510 (class 2606 OID 26284)
-- Name: ledger_batches ledger_batches_submitted_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.ledger_batches
    ADD CONSTRAINT ledger_batches_submitted_by_user_id_fkey FOREIGN KEY (submitted_by_user_id) REFERENCES public."user"(user_id);


--
-- TOC entry 3511 (class 2606 OID 26300)
-- Name: ledger_entries ledger_entries_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.ledger_entries
    ADD CONSTRAINT ledger_entries_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.ledger_batches(batch_id);


--
-- TOC entry 3512 (class 2606 OID 26310)
-- Name: ledger_entries ledger_entries_listing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.ledger_entries
    ADD CONSTRAINT ledger_entries_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES public.listing(listing_id);


--
-- TOC entry 3513 (class 2606 OID 26305)
-- Name: ledger_entries ledger_entries_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.ledger_entries
    ADD CONSTRAINT ledger_entries_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES public.portfolio(portfolio_id);


--
-- TOC entry 3514 (class 2606 OID 26315)
-- Name: ledger_entries ledger_entries_reversal_of_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.ledger_entries
    ADD CONSTRAINT ledger_entries_reversal_of_entry_id_fkey FOREIGN KEY (reversal_of_entry_id) REFERENCES public.ledger_entries(entry_id);


--
-- TOC entry 3496 (class 2606 OID 18425)
-- Name: listing listing_instrument_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.listing
    ADD CONSTRAINT listing_instrument_id_fkey FOREIGN KEY (instrument_id) REFERENCES public.instrument(instrument_id);


--
-- TOC entry 3522 (class 2606 OID 26403)
-- Name: notification_configs notification_configs_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.notification_configs
    ADD CONSTRAINT notification_configs_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES public.portfolio(portfolio_id);


--
-- TOC entry 3497 (class 2606 OID 18438)
-- Name: notifications notifications_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public."user"(user_id);


--
-- TOC entry 3498 (class 2606 OID 18456)
-- Name: portfolio_constituent portfolio_constituent_listing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.portfolio_constituent
    ADD CONSTRAINT portfolio_constituent_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES public.listing(listing_id);


--
-- TOC entry 3499 (class 2606 OID 18451)
-- Name: portfolio_constituent portfolio_constituent_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.portfolio_constituent
    ADD CONSTRAINT portfolio_constituent_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES public.portfolio(portfolio_id);


--
-- TOC entry 3500 (class 2606 OID 18461)
-- Name: portfolio_constituent portfolio_constituent_sleeve_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.portfolio_constituent
    ADD CONSTRAINT portfolio_constituent_sleeve_code_fkey FOREIGN KEY (sleeve_code) REFERENCES public.sleeves(sleeve_code);


--
-- TOC entry 3495 (class 2606 OID 18412)
-- Name: portfolio portfolio_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.portfolio
    ADD CONSTRAINT portfolio_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public."user"(user_id);


--
-- TOC entry 3520 (class 2606 OID 26384)
-- Name: portfolio_policy_allocations portfolio_policy_allocations_listing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.portfolio_policy_allocations
    ADD CONSTRAINT portfolio_policy_allocations_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES public.listing(listing_id);


--
-- TOC entry 3521 (class 2606 OID 26379)
-- Name: portfolio_policy_allocations portfolio_policy_allocations_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.portfolio_policy_allocations
    ADD CONSTRAINT portfolio_policy_allocations_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES public.portfolio(portfolio_id);


--
-- TOC entry 3501 (class 2606 OID 18476)
-- Name: price_points price_points_listing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.price_points
    ADD CONSTRAINT price_points_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES public.listing(listing_id);


--
-- TOC entry 3523 (class 2606 OID 26440)
-- Name: recommendation_batches recommendation_batches_closed_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.recommendation_batches
    ADD CONSTRAINT recommendation_batches_closed_by_user_id_fkey FOREIGN KEY (closed_by_user_id) REFERENCES public."user"(user_id);


--
-- TOC entry 3524 (class 2606 OID 26435)
-- Name: recommendation_batches recommendation_batches_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.recommendation_batches
    ADD CONSTRAINT recommendation_batches_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES public.portfolio(portfolio_id);


--
-- TOC entry 3525 (class 2606 OID 26445)
-- Name: recommendation_batches recommendation_batches_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.recommendation_batches
    ADD CONSTRAINT recommendation_batches_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.task_runs(run_id);


--
-- TOC entry 3526 (class 2606 OID 26473)
-- Name: recommendation_lines recommendation_lines_ledger_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.recommendation_lines
    ADD CONSTRAINT recommendation_lines_ledger_entry_id_fkey FOREIGN KEY (ledger_entry_id) REFERENCES public.ledger_entries(entry_id);


--
-- TOC entry 3527 (class 2606 OID 26468)
-- Name: recommendation_lines recommendation_lines_listing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.recommendation_lines
    ADD CONSTRAINT recommendation_lines_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES public.listing(listing_id);


--
-- TOC entry 3528 (class 2606 OID 26463)
-- Name: recommendation_lines recommendation_lines_recommendation_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.recommendation_lines
    ADD CONSTRAINT recommendation_lines_recommendation_batch_id_fkey FOREIGN KEY (recommendation_batch_id) REFERENCES public.recommendation_batches(recommendation_batch_id);


--
-- TOC entry 3508 (class 2606 OID 18541)
-- Name: run_input_snapshots run_input_snapshots_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.run_input_snapshots
    ADD CONSTRAINT run_input_snapshots_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.task_runs(run_id);


--
-- TOC entry 3504 (class 2606 OID 18507)
-- Name: task_runs task_runs_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ta_app
--

ALTER TABLE ONLY public.task_runs
    ADD CONSTRAINT task_runs_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES public.portfolio(portfolio_id);


--
-- TOC entry 3494 (class 2606 OID 16406)
-- Name: portfolios portfolios_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: ta; Owner: ta_app
--

ALTER TABLE ONLY ta.portfolios
    ADD CONSTRAINT portfolios_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES ta.users(user_id);


-- Completed on 2026-03-11 20:10:34 UTC

--
-- PostgreSQL database dump complete
--

\unrestrict 2hIoYGKvwoBzRACeEl11HRTBaSu7mts26umvteS3A6NPGHRnPlU8EvsqxrSQg5q

